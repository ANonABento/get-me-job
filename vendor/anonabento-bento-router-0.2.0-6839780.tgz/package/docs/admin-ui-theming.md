# Admin UI Theming

`BentoRouterAdminPage` renders with the root class `.bento-router-admin`. Basic theming is controlled through CSS custom properties on that root:

```css
.bento-router-admin {
  --bento-router-bg: transparent;
  --bento-router-fg: inherit;
  --bento-router-muted: #64748b;
  --bento-router-border: #d7dee8;
  --bento-router-accent: #2563eb;
  --bento-router-font-sans: ui-sans-serif, system-ui, sans-serif;
  --bento-router-font-mono: ui-monospace, SFMono-Regular, Menlo, monospace;
  --bento-router-radius: 8px;
}
```

The component reads these variables directly for root color, typography, borders, inputs, buttons, focus states, and section frames. The React `style` prop is passed to the root element for last-resort inline overrides.

Stable class hooks use BEM-style names:

- `.bento-router-admin__providers`
- `.bento-router-admin__provider-list`
- `.bento-router-admin__provider`
- `.bento-router-admin__provider-form`
- `.bento-router-admin__provider-actions`
- `.bento-router-admin__list`
- `.bento-router-admin__task`
- `.bento-router-admin__detail`
- `.bento-router-admin__button`
- `.bento-router-admin__validation`

Class hooks are available for advanced host-app overrides, but normal color, spacing radius, and font integration should use the custom properties above.
