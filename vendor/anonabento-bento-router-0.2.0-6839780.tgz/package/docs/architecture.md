# Architecture

BentoRouter is the in-between layer between ANonABento apps and model providers.

```txt
App feature
  -> task ID
  -> BentoRouter runtime
  -> effective policy
  -> budget and guardrail checks
  -> provider/model attempt
  -> retry/fallback/circuit breaker
  -> usage logging
  -> admin API/UI
```

## Deliverables

- reusable runtime package
- provider/model registry with cost metadata
- task registry
- policy resolver
- token and request-cost guardrails
- daily budget checks
- retry and fallback execution
- circuit breaker
- usage store interface
- policy store interface for durable admin changes
- provider config store interface for per-user BYOK keys
- read-only admin/reporting API
- embeddable React admin view
- sample env config
- tests for routing and fallback behavior

## Task Contract

The app contract is a task ID, not a provider model.

```ts
await router.run({
  task: "slothing.listing_description",
  messages,
});
```

The router decides which model is allowed for that task at runtime.

## Dashboard Contract

The admin UI should read task definitions and effective policies from the API facade:

- `listTasks(appId?)`
- `manifest(appId?)`
- `getTask(taskId)`
- `updateTaskPolicy(taskId, policy)`
- `listModels()`
- `listProviders()`
- `listConfiguredProviders(userId)`
- `getConfiguredProvider(userId, id)`
- `addConfiguredProvider(input)`
- `updateConfiguredProvider(userId, id, patch)`
- `removeConfiguredProvider(userId, id)`
- `validateProvider(input)`
- `usageSummary(query)`
- `usageSummaryByUser(userId, range?)`
- `usageEvents(query)`
- `testTask(taskId, messages)`

This facade can be adapted to Next.js routes, Express, Hono, Tauri commands, or another host framework.

When `policyStore` is provided, `updateTaskPolicy` writes durable overrides and BentoRouter reads the latest stored policy before each run:

```ts
const policyStore = new JsonFilePolicyStore(".bento-router/policies.json");

const router = new BentoRouter({
  providerRegistry,
  taskRegistry,
  modelRegistry,
  usageStore,
  policyStore,
});
```

Admin writes can be protected by host auth and audited:

```ts
const api = createBentoRouterApi({
  router,
  taskRegistry,
  modelRegistry,
  providerRegistry,
  usageStore,
  policyStore,
  authorize: async (operation) => operation.type === "read" || user.isAdmin,
  audit: async (event) => auditLog.write(event),
});
```

## Runtime Provider Config

BYOK apps configure a `ProviderConfigStore` alongside the existing registries. Provider configs are scoped by `userId`; single-user installs pass `"default"`.

```ts
const providerConfigStore = new JsonFileProviderConfigStore(".bento-router/providers.json");

const api = createBentoRouterApi({
  router,
  taskRegistry,
  modelRegistry,
  providerRegistry,
  usageStore,
  policyStore,
  providerConfigStore,
  encryption,
});

await api.addConfiguredProvider({
  type: "openai",
  displayName: "Personal OpenAI",
  apiKey: "sk-...",
  userId: "default",
});
```

The store persists `encryptedApiKey` and `encryptionScheme`, but encryption is performed by the embedding app through `EncryptionAdapter`. Without an adapter, BentoRouter warns and stores plaintext for local development.

The fetch-compatible HTTP handler exposes configured provider CRUD at `/api/bento-router/providers` when `userId` is supplied, plus `POST /api/bento-router/providers/validate` for non-persistent key checks.

The task manifest is the static/discovery contract for plug-in pages:

```txt
GET /api/bento-router/manifest?appId=tomodachi
```

It returns task metadata, effective policy, available apps, and optionally model metadata so the provider UI can draw a complete task map without knowing app internals.

For fetch-compatible runtimes, mount `createBentoRouterHttpHandler`:

```ts
const handler = createBentoRouterHttpHandler({ api });

export const GET = handler;
export const POST = handler;
export const PUT = handler;
```

For a standalone Node service, wrap the same handler:

```ts
const service = createBentoRouterService({ handler, host: "0.0.0.0", port: 8787 });
await service.start();
```

Or build the whole runtime from config:

```ts
const runtime = createBentoRouterRuntimeFromConfig({
  providers: [{ id: "openrouter", type: "openrouter" }],
  usage: { type: "json", filePath: ".bento-router/usage.json" },
  policies: { type: "json", filePath: ".bento-router/policies.json" },
  tasks,
  models,
  service: { host: "0.0.0.0", port: 8787 },
});

await runtime.service.start();
```

Health checks are available at:

```txt
GET /api/bento-router/health
```

Usage reports are available as API summaries or CSV exports:

```txt
GET /api/bento-router/usage/report?groupBy=task
GET /api/bento-router/usage/report?groupBy=day
GET /api/bento-router/usage/events.csv
```

Task policies can also restrict eligible models by capability, quality tier, and context size:

```ts
modelRequirements: {
  caps: { json: true, vision: true },
  allowedQualityTiers: ["standard", "premium"],
  minContextTokens: 128000,
}
```

For structured outputs, wrap a normal task run with JSON parsing and validation:

```ts
const parsed = await runBentoJsonTask({
  router,
  input: { task: "slothing.style_tags", messages },
  validate: (value): value is string[] => Array.isArray(value),
});
```

Runtime hooks can redact usage events, reject low-quality outputs, and reuse cached fallback text:

```ts
const router = new BentoRouter({
  providerRegistry,
  redactUsageEvent: (event) => ({ ...event, userId: undefined }),
  outputValidators: {
    "tomodachi.chat_reply": ({ text }) => text.length > 0 || "empty output",
  },
  responseCache,
});
```

Provider adapters can also expose optional streaming, token counting, embeddings, tool calls, and vision message parts. When a provider does not implement streaming, `router.stream()` falls back to one final text chunk from `complete()`.

Usage events can carry `orgId`, `projectId`, and `environment`, which enables customer-level budgets and reporting:

```ts
await router.run({
  task: "tomodachi.chat_reply",
  orgId: "customer_123",
  projectId: "tomodachi",
  environment: "prod",
  messages,
});
```

Premium model approval can be enforced per task:

```ts
approval: {
  requireForQualityTiers: ["premium"],
  approved: false,
}
```

## Service Path

This package is intentionally service-ready but package-first. Promote it to a central service when global real-time budgets, centralized provider keys, or cross-language apps make that worth the operational cost.
