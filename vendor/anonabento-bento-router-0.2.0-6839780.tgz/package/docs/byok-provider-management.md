# BYOK Provider Management

BentoRouter 0.2.0 adds runtime provider configuration for apps where each user brings their own provider key.

## Store Setup

Configure a `ProviderConfigStore` and pass the same store into the API facade:

```ts
import {
  BentoRouter,
  JsonFileProviderConfigStore,
  ProviderRegistry,
  createBentoRouterApi,
} from "@anonabento/bento-router";

const providerRegistry = new ProviderRegistry();
const providerConfigStore = new JsonFileProviderConfigStore(".bento-router/providers.json");

const encryption = {
  scheme: "aes-256-gcm-v1",
  async encrypt(plaintext: string) {
    return encryptWithYourAppKey(plaintext);
  },
  async decrypt(stored: string) {
    return decryptWithYourAppKey(stored);
  },
};

const router = new BentoRouter({
  providerRegistry,
  providerConfigStore,
  encryption,
});

const api = createBentoRouterApi({
  router,
  taskRegistry,
  modelRegistry,
  providerRegistry,
  usageStore,
  policyStore,
  providerConfigStore,
  encryption,
});
```

Stores do not encrypt keys themselves. The embedding app owns key management and supplies an `EncryptionAdapter`. If a store is configured without encryption, BentoRouter logs a strong warning and stores plaintext. That mode is intended only for local development.

## API Operations

Every configured-provider CRUD operation requires `userId`. Single-user installs should pass `"default"`.

```ts
await api.addConfiguredProvider({
  type: "openai",
  displayName: "Personal OpenAI",
  apiKey: "sk-...",
  defaultModel: "openai/gpt-4.1-mini",
  userId: "default",
});

const providers = await api.listConfiguredProviders("default");
await api.updateConfiguredProvider("default", "openai-personal-openai", {
  displayName: "OpenAI",
});
await api.removeConfiguredProvider("default", "openai-personal-openai");
```

Validation does not persist anything:

```ts
const result = await api.validateProvider({
  type: "openrouter",
  apiKey: "sk-or-...",
});
```

The HTTP handler exposes the same surface:

```txt
GET    /api/bento-router/providers?userId=default
POST   /api/bento-router/providers
GET    /api/bento-router/providers/:id?userId=default
PUT    /api/bento-router/providers/:id?userId=default
DELETE /api/bento-router/providers/:id?userId=default
POST   /api/bento-router/providers/validate
```

## Legacy Config Migration

Use `migrateLegacyLLMConfig()` when moving an app from a `{ provider, apiKey, model }` shape:

```ts
const migrated = migrateLegacyLLMConfig(
  { provider: "ollama", model: "llama3", baseUrl: "http://localhost:11434" },
  { userId: "default", taskIds: ["slothing.summary", "slothing.tags"] },
);

if (migrated.provider) {
  await api.addConfiguredProvider(migrated.provider);
}

for (const [taskId, policy] of Object.entries(migrated.taskPolicies)) {
  await api.updateTaskPolicy(taskId, policy);
}
```

When the legacy config has no `apiKey`, the helper returns only task policy patches.

## Decisions From The 0.2 Spec

- Encryption upgrades are app-owned. Store entries carry `encryptionScheme`; apps can implement read-through decrypt and re-encrypt in their adapter workflow.
- Provider validation uses a per-process in-memory token bucket. Apps that expose BentoRouter publicly should add edge or framework-level rate limiting too.
- `defaultModel` never overrides task policies. It is used as a convenience value and for fallback auto-population when a provider is added.
- JSON provider config hot reload is deferred. Restart the process or call `refreshConfiguredProviders()` after external file edits.
- Provider ID collisions return an error. BentoRouter derives the ID from provider type and display name and does not auto-suffix.

