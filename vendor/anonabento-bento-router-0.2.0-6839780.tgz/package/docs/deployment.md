# Deployment Notes

BentoRouter can run embedded in a host app or as a small Node service.

## Embedded

Use this when the app is TypeScript/Node and should own its provider keys:

```ts
const handler = createBentoRouterHttpHandler({ api });
export const GET = handler;
export const POST = handler;
export const PUT = handler;
```

## Central Service

Use this when Python apps or multiple websites should share budgets and provider policy:

```ts
const runtime = createBentoRouterRuntimeFromConfig({
  providers: [{ id: "openrouter", type: "openrouter" }],
  usage: { type: "json", filePath: ".bento-router/usage.json" },
  policies: { type: "json", filePath: ".bento-router/policies.json" },
  tasks,
  models,
  service: { host: "0.0.0.0", port: Number(process.env.PORT ?? 8787) },
});

await runtime.service.start();
```

Set provider keys in the service environment:

```sh
OPENROUTER_API_KEY=...
OPENAI_API_KEY=...
ANTHROPIC_API_KEY=...
```

Non-TypeScript apps call:

```txt
POST https://router.example.com/api/bento-router/run
```

Use a reverse proxy or platform auth in front of write endpoints such as:

```txt
PUT /api/bento-router/tasks/:taskId/policy
```
