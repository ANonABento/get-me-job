# App Integration Notes

Use stable task IDs as the contract between app features and the router. Model choices, fallbacks, budgets, and guardrails belong in task policy.

## Install

For local development next to app repos:

```sh
npm install ../bento-router
```

For portable installs from the private GitHub repo:

```sh
npm install github:ANonABento/bento-router
```

Publishing to npm or GitHub Packages can come later. Until then, GitHub installs keep CI and teammate machines from depending on a sibling `file:` path.

## Slothing

Candidate first call paths:

- `slothing.listing_description`
- `slothing.style_tags`

Register tasks from `examples/slothing.tasks.ts`, then replace direct provider calls with:

```ts
const result = await router.run({
  task: "slothing.listing_description",
  userId,
  messages: [
    { role: "system", content: "Write concise resale listing copy." },
    { role: "user", content: productFacts },
  ],
});
```

If `result.status === "degraded"`, show the returned short/static text and keep the listing editor usable.

## TomodachiAI

Candidate first call paths:

- `tomodachi.chat_reply`
- `tomodachi.memory_summary`

Register tasks from `examples/tomodachi.tasks.ts`, then replace direct chat completion calls with:

```ts
const result = await router.run({
  task: "tomodachi.chat_reply",
  userId,
  messages: conversationMessages,
});
```

If premium chat is unavailable or over budget, the fallback chain keeps the conversation alive. Memory summary can degrade to an empty string so the app skips memory write rather than failing the chat.

For the Flask server, set `BENTO_ROUTER_URL` to a deployed or local BentoRouter HTTP service. The existing `/api/ai` route can then delegate `tomodachi.chat_reply` to:

```txt
POST {BENTO_ROUTER_URL}/api/bento-router/run
```

If the shared router is unavailable, the app should fall back to its local provider adapter so chat remains usable.

## Provider Settings Page

Mount the HTTP handler in the host app:

```ts
const api = createBentoRouterApi({
  router,
  taskRegistry,
  modelRegistry,
  providerRegistry,
  usageStore,
  policyStore,
});

export const GET = createBentoRouterHttpHandler({ api });
export const POST = createBentoRouterHttpHandler({ api });
export const PUT = createBentoRouterHttpHandler({ api });
```

Then render the admin page from the manifest:

```ts
const manifest = await fetch("/api/bento-router/manifest").then((res) => res.json());
```

See `examples/next-route.ts` for a minimal Next.js route handler.
See `examples/flask-client.py` for a minimal Python client.
