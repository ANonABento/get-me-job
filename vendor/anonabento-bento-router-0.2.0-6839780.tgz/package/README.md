# BentoRouter

Task-based AI routing and cost governance for ANonABento apps.

Apps call stable task IDs such as `tomodachi.chat_reply` instead of hardcoding provider/model choices. BentoRouter resolves the effective policy, enforces guardrails and budgets, retries or falls back across providers, records usage attempts, and exposes task/reporting data for an embeddable admin page.

## Quick Start

```ts
import {
  BentoRouter,
  JsonFileProviderConfigStore,
  ProviderRegistry,
  createBentoRouterApi,
  createOpenRouterProvider,
  defineBentoTask,
} from "@anonabento/bento-router";

defineBentoTask({
  id: "tomodachi.chat_reply",
  appId: "tomodachi",
  name: "Character Chat Reply",
  defaultPolicy: {
    primaryModel: "openrouter/anthropic/claude-3.5-sonnet",
    fallbacks: ["openrouter/openai/gpt-4.1-mini", "openrouter/google/gemini-flash"],
    guardrails: {
      maxInputTokens: 6000,
      maxOutputTokens: 900,
      timeoutMs: 18000,
      maxRetries: 1,
      maxRequestCostUsd: 0.03,
    },
    degradation: {
      mode: "short_response",
      message: "AI is temporarily running in limited mode.",
    },
  },
});

const providers = new ProviderRegistry();
providers.register(createOpenRouterProvider({ apiKey: process.env.OPENROUTER_API_KEY ?? "" }));

const router = new BentoRouter({ providerRegistry: providers });

const result = await router.run({
  task: "tomodachi.chat_reply",
  userId: "user_123",
  messages: [{ role: "user", content: "Say hi in character." }],
});
```

### BYOK Runtime Provider Config

Apps that let users bring their own keys can add runtime provider management with a `ProviderConfigStore`. Every CRUD operation is scoped by `userId`; single-user apps pass `"default"`.

```ts
const providerConfigStore = new JsonFileProviderConfigStore(".bento-router/providers.json");

const encryption = {
  scheme: "aes-256-gcm-v1",
  encrypt: async (plaintext: string) => appEncrypt(plaintext),
  decrypt: async (stored: string) => appDecrypt(stored),
};

const router = new BentoRouter({
  providerRegistry: providers,
  providerConfigStore,
  encryption,
});

const api = createBentoRouterApi({
  router,
  taskRegistry,
  modelRegistry,
  providerRegistry: providers,
  usageStore,
  policyStore,
  providerConfigStore,
  encryption,
});

await api.addConfiguredProvider({
  type: "openai",
  displayName: "Personal OpenAI",
  apiKey: "sk-...",
  defaultModel: "openai/gpt-4.1-mini",
  userId: "default",
});
```

Stores never encrypt keys themselves. If `providerConfigStore` is configured without `encryption`, BentoRouter logs a warning and stores plaintext for local development only.

## Admin Embedding

`BentoRouterAdminPage` is a themeable React component. The host app provides tasks from `createBentoRouterApi().listTasks()`.

```tsx
<BentoRouterAdminPage tasks={tasks} selectedTaskId={selectedTaskId} onSelectTask={setSelectedTaskId} />
<BentoRouterUsageTable rows={usageRows} />
```

Style with the documented `--bento-router-*` CSS variables or normal class overrides:

```css
.bento-router-admin {
  --bento-router-bg: var(--background);
  --bento-router-fg: var(--foreground);
  --bento-router-muted: var(--muted-foreground);
  --bento-router-border: var(--border);
  --bento-router-accent: var(--accent);
  --bento-router-font-sans: var(--font-sans);
}
```

## API Mounting

`createBentoRouterApi` exposes framework-neutral operations. `createBentoRouterHttpHandler` wraps that facade for fetch-compatible route handlers:

```ts
const handler = createBentoRouterHttpHandler({ api });
export const GET = handler;
export const POST = handler;
export const PUT = handler;
```

The provider page can discover everything it needs from:

```txt
GET /api/bento-router/manifest
```

Apps in other runtimes can execute through the shared control plane with:

```txt
POST /api/bento-router/run
```

## CLI

```sh
bento-router tasks --config ./router.json
bento-router types --config ./router.json
bento-router test tomodachi.chat_reply --config ./router.json --message "Hello"
bento-router usage --file .bento-router/usage.json
bento-router doctor
```

## Migration Notes

1. Define a stable task ID for each AI feature.
2. Move model/provider choices into `defaultPolicy`.
3. Replace direct provider calls with `router.run({ task, messages })`.
4. Persist usage through `JsonFileUsageStore` or an app-specific `UsageStore` adapter.
5. Add a graceful degradation message for budget exhaustion or provider outage.
6. Add task-specific tests for fallback and cost ceilings.

See [docs/architecture.md](docs/architecture.md) for the full control-plane design.
See [docs/app-integration.md](docs/app-integration.md) for slothing and TomodachiAI migration notes.
See [docs/byok-provider-management.md](docs/byok-provider-management.md) for runtime provider configuration.
See [docs/admin-ui-theming.md](docs/admin-ui-theming.md) for the admin component theming contract.
See [docs/deployment.md](docs/deployment.md) for central service deployment notes.
See [TODO.md](TODO.md) for the current product and engineering roadmap.
