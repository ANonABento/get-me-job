# Changelog

## 0.2.0

- Added per-user BYOK provider configuration stores with memory and JSON-file adapters.
- Added encryption adapter hooks, provider validation, configured-provider CRUD APIs, and HTTP routes.
- Added `migrateLegacyLLMConfig()` for legacy `{ provider, apiKey, model }` migration.
- Extended `BentoRouterAdminPage` with an optional Providers section and documented `--bento-router-*` theming.
- Added user-facing BYOK docs, admin UI theming docs, and architecture notes.

## 0.1.0

- Added task-based BentoRouter runtime.
- Added provider/model registries, policy overrides, guardrails, retry/fallback, circuit breaker, and usage accounting.
- Added JSON-file usage and policy stores.
- Added admin API, HTTP handler, service helper, and React admin components.
- Added usage reporting, CSV export, routing controls, structured JSON helpers, OpenAI-compatible providers, and provider capability primitives.
- Added CLI commands for task discovery, type generation, usage summaries, test runs, and diagnostics.
