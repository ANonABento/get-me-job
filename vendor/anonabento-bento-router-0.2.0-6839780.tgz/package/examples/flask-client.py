import os
import urllib.error
import urllib.request
import json


BENTO_ROUTER_URL = os.getenv("BENTO_ROUTER_URL", "http://localhost:8787").rstrip("/")


def run_bento_task(task: str, messages: list[dict], timeout_seconds: float = 20) -> dict | None:
    request = urllib.request.Request(
        f"{BENTO_ROUTER_URL}/api/bento-router/run",
        data=json.dumps({"task": task, "messages": messages}).encode("utf-8"),
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    try:
        with urllib.request.urlopen(request, timeout=timeout_seconds) as response:
            return json.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError):
        return None


def chat_reply(prompt: str) -> str:
    routed = run_bento_task(
        "tomodachi.chat_reply",
        [
            {"role": "system", "content": "Reply concisely and in character."},
            {"role": "user", "content": prompt},
        ],
    )
    if not routed:
        return "AI is temporarily unavailable."
    return routed.get("text") or "AI is temporarily unavailable."
