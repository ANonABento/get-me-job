import {
  BentoRouter,
  JsonFilePolicyStore,
  JsonFileUsageStore,
  ProviderRegistry,
  TaskRegistry,
  createBentoRouterApi,
  createBentoRouterHttpHandler,
  createDefaultModelRegistry,
  createOpenRouterProvider,
} from "../src/index.js";
import { registerTomodachiAiTasks } from "./tomodachi.tasks.js";

const taskRegistry = new TaskRegistry();
registerTomodachiAiTasks(taskRegistry);
const modelRegistry = createDefaultModelRegistry();

const providerRegistry = new ProviderRegistry();
providerRegistry.register(createOpenRouterProvider({ apiKey: process.env.OPENROUTER_API_KEY ?? "" }));

const usageStore = new JsonFileUsageStore(".bento-router/usage.json");
const policyStore = new JsonFilePolicyStore(".bento-router/policies.json");
const router = new BentoRouter({ taskRegistry, modelRegistry, providerRegistry, usageStore, policyStore });
const api = createBentoRouterApi({
  router,
  taskRegistry,
  modelRegistry,
  providerRegistry,
  usageStore,
  policyStore,
});

const handler = createBentoRouterHttpHandler({ api });

export const GET = handler;
export const POST = handler;
export const PUT = handler;
