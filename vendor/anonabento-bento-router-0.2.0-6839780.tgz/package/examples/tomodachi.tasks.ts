import { defineBentoTask, type TaskRegistry } from "../src/index.js";

export function registerTomodachiAiTasks(registry?: TaskRegistry): void {
  defineBentoTask({
    id: "tomodachi.chat_reply",
    appId: "tomodachi",
    name: "Character Chat Reply",
    category: "Chat",
    description: "Generates in-character replies for active conversations.",
    defaultPolicy: {
      primaryModel: "openrouter/anthropic/claude-3.5-sonnet",
      fallbacks: [
        "openrouter/openai/gpt-4.1-mini",
        "openrouter/google/gemini-flash",
      ],
      guardrails: {
        maxInputTokens: 6000,
        maxOutputTokens: 900,
        timeoutMs: 18000,
        maxRetries: 1,
        maxRequestCostUsd: 0.03,
      },
      budget: {
        dailyTaskBudgetUsd: 12,
        dailyUserBudgetUsd: 1,
      },
      circuitBreaker: {
        failureThreshold: 3,
        cooldownMs: 60000,
      },
      degradation: {
        mode: "short_response",
        message: "I'm having a lighter conversation mode moment. Say that again more simply?",
      },
    },
  }, registry);

  defineBentoTask({
    id: "tomodachi.memory_summary",
    appId: "tomodachi",
    name: "Memory Summary",
    category: "Memory",
    description: "Condenses recent conversation turns into durable character memory.",
    defaultPolicy: {
      primaryModel: "openrouter/openai/gpt-4.1-mini",
      fallbacks: ["openrouter/google/gemini-flash"],
      guardrails: {
        maxInputTokens: 8000,
        maxOutputTokens: 500,
        timeoutMs: 12000,
        maxRetries: 1,
        maxRequestCostUsd: 0.015,
      },
      budget: {
        dailyTaskBudgetUsd: 4,
      },
      degradation: {
        mode: "static_message",
        message: "",
      },
    },
  }, registry);
}
