import { defineBentoTask, type TaskRegistry } from "../src/index.js";

export function registerSlothingAiTasks(registry?: TaskRegistry): void {
  defineBentoTask({
    id: "slothing.listing_description",
    appId: "slothing",
    name: "Listing Description",
    category: "Listings",
    description: "Generates shopper-facing item descriptions from product facts and optional image notes.",
    defaultPolicy: {
      primaryModel: "openrouter/openai/gpt-4.1-mini",
      fallbacks: ["openrouter/google/gemini-flash"],
      guardrails: {
        maxInputTokens: 4000,
        maxOutputTokens: 500,
        timeoutMs: 12000,
        maxRetries: 1,
        maxRequestCostUsd: 0.01,
      },
      budget: {
        dailyTaskBudgetUsd: 5,
      },
      degradation: {
        mode: "short_response",
        message: "Description generation is temporarily limited. Try a shorter product summary.",
      },
    },
  }, registry);

  defineBentoTask({
    id: "slothing.style_tags",
    appId: "slothing",
    name: "Style Tags",
    category: "Listings",
    description: "Extracts searchable style, era, fabric, fit, and vibe tags.",
    defaultPolicy: {
      primaryModel: "openrouter/google/gemini-flash",
      fallbacks: ["openrouter/openai/gpt-4.1-mini"],
      guardrails: {
        maxInputTokens: 2500,
        maxOutputTokens: 200,
        timeoutMs: 8000,
        maxRetries: 1,
        maxRequestCostUsd: 0.003,
      },
      budget: {
        dailyTaskBudgetUsd: 2,
      },
      degradation: {
        mode: "static_message",
        message: "[]",
      },
    },
  }, registry);
}
