import type { PolicyOverrides, TaskPolicy } from "../types.js";
import {
  clonePolicyOverrides,
  mergeTaskPolicyOverride,
  type PolicyStore,
} from "./policyStore.js";

export class MemoryPolicyStore implements PolicyStore {
  private overrides: PolicyOverrides;

  constructor(overrides: PolicyOverrides = {}) {
    this.overrides = clonePolicyOverrides(overrides);
  }

  async read(): Promise<PolicyOverrides> {
    return clonePolicyOverrides(this.overrides);
  }

  async replace(overrides: PolicyOverrides): Promise<void> {
    this.overrides = clonePolicyOverrides(overrides);
  }

  async updateTaskPolicy(taskId: string, policy: Partial<TaskPolicy>): Promise<PolicyOverrides> {
    this.overrides = mergeTaskPolicyOverride(this.overrides, taskId, policy);
    return this.read();
  }
}
