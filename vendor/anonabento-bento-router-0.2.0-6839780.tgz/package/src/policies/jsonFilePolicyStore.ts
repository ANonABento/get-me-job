import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { dirname } from "node:path";
import type { PolicyOverrides, TaskPolicy } from "../types.js";
import {
  clonePolicyOverrides,
  mergeTaskPolicyOverride,
  type PolicyStore,
} from "./policyStore.js";

export class JsonFilePolicyStore implements PolicyStore {
  constructor(private readonly filePath: string) {}

  async read(): Promise<PolicyOverrides> {
    try {
      const content = await readFile(this.filePath, "utf8");
      return clonePolicyOverrides(JSON.parse(content) as PolicyOverrides);
    } catch (error) {
      if (isNotFound(error)) return {};
      throw error;
    }
  }

  async replace(overrides: PolicyOverrides): Promise<void> {
    await this.write(clonePolicyOverrides(overrides));
  }

  async updateTaskPolicy(taskId: string, policy: Partial<TaskPolicy>): Promise<PolicyOverrides> {
    const next = mergeTaskPolicyOverride(await this.read(), taskId, policy);
    await this.write(next);
    return next;
  }

  private async write(overrides: PolicyOverrides): Promise<void> {
    await mkdir(dirname(this.filePath), { recursive: true });
    const tmpPath = `${this.filePath}.${process.pid}.tmp`;
    await writeFile(tmpPath, `${JSON.stringify(overrides, null, 2)}\n`, "utf8");
    await rename(tmpPath, this.filePath);
  }
}

function isNotFound(error: unknown): boolean {
  return typeof error === "object" && error !== null && "code" in error && error.code === "ENOENT";
}
