import type { PolicyOverrides, TaskPolicy } from "../types.js";
import { mergeTaskPolicyOverride, type PolicyStore } from "./policyStore.js";

export type RemotePolicyStoreOptions = {
  baseUrl: string;
  fetchImpl?: typeof fetch;
  headers?: HeadersInit;
};

export class RemotePolicyStore implements PolicyStore {
  private readonly fetchImpl: typeof fetch;
  private readonly baseUrl: string;

  constructor(private readonly options: RemotePolicyStoreOptions) {
    this.fetchImpl = options.fetchImpl ?? fetch;
    this.baseUrl = options.baseUrl.replace(/\/$/, "");
  }

  async read(): Promise<PolicyOverrides> {
    const response = await this.fetchImpl(`${this.baseUrl}/policies`, {
      headers: this.options.headers,
    });
    if (!response.ok) throw new Error(`Remote policy read failed (${response.status})`);
    return response.json() as Promise<PolicyOverrides>;
  }

  async replace(overrides: PolicyOverrides): Promise<void> {
    const response = await this.fetchImpl(`${this.baseUrl}/policies`, {
      method: "PUT",
      headers: { "Content-Type": "application/json", ...this.options.headers },
      body: JSON.stringify(overrides),
    });
    if (!response.ok) throw new Error(`Remote policy replace failed (${response.status})`);
  }

  async updateTaskPolicy(taskId: string, policy: Partial<TaskPolicy>): Promise<PolicyOverrides> {
    const next = mergeTaskPolicyOverride(await this.read(), taskId, policy);
    await this.replace(next);
    return next;
  }
}
