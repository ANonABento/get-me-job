import type { PolicyOverrides, TaskPolicy } from "../types.js";

export type PolicyStore = {
  read(): Promise<PolicyOverrides>;
  replace(overrides: PolicyOverrides): Promise<void>;
  updateTaskPolicy(taskId: string, policy: Partial<TaskPolicy>): Promise<PolicyOverrides>;
};

export function mergePolicyOverrides(...overrides: Array<PolicyOverrides | undefined>): PolicyOverrides {
  const merged: PolicyOverrides = {};

  for (const override of overrides) {
    if (!override) continue;
    if (override.global) merged.global = { ...merged.global, ...override.global };
    if (override.app) merged.app = { ...merged.app, ...override.app };
    if (override.task) merged.task = { ...merged.task, ...override.task };
  }

  return merged;
}

export function clonePolicyOverrides(overrides: PolicyOverrides = {}): PolicyOverrides {
  return {
    global: overrides.global ? clonePolicy(overrides.global) : undefined,
    app: clonePolicyRecord(overrides.app),
    task: clonePolicyRecord(overrides.task),
  };
}

export function validatePolicyOverride(policy: Partial<TaskPolicy>): void {
  if (policy.primaryModel !== undefined && policy.primaryModel.trim() === "") {
    throw new Error("primaryModel cannot be empty");
  }

  if (policy.fallbacks) {
    const duplicate = firstDuplicate(policy.fallbacks);
    if (duplicate) throw new Error(`fallback model is duplicated: ${duplicate}`);
  }

  validateNonNegative(policy.guardrails?.maxInputTokens, "guardrails.maxInputTokens");
  validateNonNegative(policy.guardrails?.maxOutputTokens, "guardrails.maxOutputTokens");
  validateNonNegative(policy.guardrails?.timeoutMs, "guardrails.timeoutMs");
  validateNonNegative(policy.guardrails?.maxRetries, "guardrails.maxRetries");
  validateNonNegative(policy.guardrails?.maxRequestCostUsd, "guardrails.maxRequestCostUsd");
  validateNonNegative(policy.budget?.dailyAppBudgetUsd, "budget.dailyAppBudgetUsd");
  validateNonNegative(policy.budget?.dailyTaskBudgetUsd, "budget.dailyTaskBudgetUsd");
  validateNonNegative(policy.budget?.dailyUserBudgetUsd, "budget.dailyUserBudgetUsd");
  validateNonNegative(policy.budget?.dailyOrgBudgetUsd, "budget.dailyOrgBudgetUsd");
  validateNonNegative(policy.circuitBreaker?.failureThreshold, "circuitBreaker.failureThreshold");
  validateNonNegative(policy.circuitBreaker?.cooldownMs, "circuitBreaker.cooldownMs");
  validateNonNegative(policy.modelRequirements?.minContextTokens, "modelRequirements.minContextTokens");
  validateNonNegative(policy.routing?.canary?.percentage, "routing.canary.percentage");
  validateNonNegative(policy.routing?.rateLimit?.maxRequests, "routing.rateLimit.maxRequests");
  validateNonNegative(policy.routing?.rateLimit?.windowMs, "routing.rateLimit.windowMs");
  validateNonNegative(
    policy.routing?.maxConcurrentProviderRequests,
    "routing.maxConcurrentProviderRequests",
  );
  for (const [modelId, weight] of Object.entries(policy.routing?.weights ?? {})) {
    validateNonNegative(weight, `routing.weights.${modelId}`);
  }
}

export function mergeTaskPolicyOverride(
  overrides: PolicyOverrides,
  taskId: string,
  policy: Partial<TaskPolicy>,
): PolicyOverrides {
  validatePolicyOverride(policy);
  const next = clonePolicyOverrides(overrides);
  next.task = {
    ...next.task,
    [taskId]: mergePartialTaskPolicy(next.task?.[taskId], policy),
  };
  return next;
}

function mergePartialTaskPolicy(
  current: Partial<TaskPolicy> | undefined,
  patch: Partial<TaskPolicy>,
): Partial<TaskPolicy> {
  return {
    ...current,
    ...patch,
    modelRequirements: patch.modelRequirements
      ? {
          ...current?.modelRequirements,
          ...patch.modelRequirements,
          caps: { ...current?.modelRequirements?.caps, ...patch.modelRequirements.caps },
          allowedQualityTiers: patch.modelRequirements.allowedQualityTiers
            ? [...patch.modelRequirements.allowedQualityTiers]
            : current?.modelRequirements?.allowedQualityTiers,
        }
      : current?.modelRequirements,
    routing: patch.routing
      ? {
          ...current?.routing,
          ...patch.routing,
          canary: patch.routing.canary ? { ...patch.routing.canary } : current?.routing?.canary,
          weights: patch.routing.weights ? { ...patch.routing.weights } : current?.routing?.weights,
          rateLimit: patch.routing.rateLimit
            ? { ...patch.routing.rateLimit }
            : current?.routing?.rateLimit,
        }
      : current?.routing,
    approval: patch.approval
      ? {
          ...current?.approval,
          ...patch.approval,
          requireForQualityTiers: patch.approval.requireForQualityTiers
            ? [...patch.approval.requireForQualityTiers]
            : current?.approval?.requireForQualityTiers,
        }
      : current?.approval,
    guardrails: patch.guardrails ? { ...current?.guardrails, ...patch.guardrails } : current?.guardrails,
    budget: patch.budget ? { ...current?.budget, ...patch.budget } : current?.budget,
    circuitBreaker: patch.circuitBreaker
      ? { ...current?.circuitBreaker, ...patch.circuitBreaker }
      : current?.circuitBreaker,
    degradation: patch.degradation ? { ...current?.degradation, ...patch.degradation } : current?.degradation,
    fallbacks: patch.fallbacks ? [...patch.fallbacks] : current?.fallbacks,
  };
}

function clonePolicyRecord(
  record: Record<string, Partial<TaskPolicy>> | undefined,
): Record<string, Partial<TaskPolicy>> | undefined {
  if (!record) return undefined;
  return Object.fromEntries(
    Object.entries(record).map(([key, policy]) => [key, clonePolicy(policy)]),
  );
}

function clonePolicy(policy: Partial<TaskPolicy>): Partial<TaskPolicy> {
  return {
    ...policy,
    fallbacks: policy.fallbacks ? [...policy.fallbacks] : undefined,
    modelRequirements: policy.modelRequirements
      ? {
          ...policy.modelRequirements,
          caps: policy.modelRequirements.caps ? { ...policy.modelRequirements.caps } : undefined,
          allowedQualityTiers: policy.modelRequirements.allowedQualityTiers
            ? [...policy.modelRequirements.allowedQualityTiers]
            : undefined,
        }
      : undefined,
    routing: policy.routing
      ? {
          ...policy.routing,
          canary: policy.routing.canary ? { ...policy.routing.canary } : undefined,
          weights: policy.routing.weights ? { ...policy.routing.weights } : undefined,
          rateLimit: policy.routing.rateLimit ? { ...policy.routing.rateLimit } : undefined,
        }
      : undefined,
    approval: policy.approval
      ? {
          ...policy.approval,
          requireForQualityTiers: policy.approval.requireForQualityTiers
            ? [...policy.approval.requireForQualityTiers]
            : undefined,
        }
      : undefined,
    guardrails: policy.guardrails ? { ...policy.guardrails } : undefined,
    budget: policy.budget ? { ...policy.budget } : undefined,
    circuitBreaker: policy.circuitBreaker ? { ...policy.circuitBreaker } : undefined,
    degradation: policy.degradation ? { ...policy.degradation } : undefined,
  };
}

function validateNonNegative(value: number | undefined, field: string): void {
  if (value === undefined) return;
  if (!Number.isFinite(value) || value < 0) {
    throw new Error(`${field} must be a non-negative number`);
  }
}

function firstDuplicate(values: string[]): string | undefined {
  const seen = new Set<string>();
  for (const value of values) {
    if (seen.has(value)) return value;
    seen.add(value);
  }
  return undefined;
}
