import type { PolicyOverrides, TaskPolicy } from "../types.js";
import { clonePolicyOverrides, mergeTaskPolicyOverride, type PolicyStore } from "./policyStore.js";

export type DatabasePolicyStoreOptions = {
  read: () => Promise<PolicyOverrides | undefined>;
  write: (overrides: PolicyOverrides) => Promise<void>;
};

export class DatabasePolicyStore implements PolicyStore {
  constructor(private readonly options: DatabasePolicyStoreOptions) {}

  async read(): Promise<PolicyOverrides> {
    return clonePolicyOverrides((await this.options.read()) ?? {});
  }

  async replace(overrides: PolicyOverrides): Promise<void> {
    await this.options.write(clonePolicyOverrides(overrides));
  }

  async updateTaskPolicy(taskId: string, policy: Partial<TaskPolicy>): Promise<PolicyOverrides> {
    const next = mergeTaskPolicyOverride(await this.read(), taskId, policy);
    await this.options.write(next);
    return next;
  }
}
