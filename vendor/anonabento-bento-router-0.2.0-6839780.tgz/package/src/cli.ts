#!/usr/bin/env node
import { readFile } from "node:fs/promises";
import { createBentoRouterRuntimeFromConfig, type BentoRouterConfig } from "./config/bentoRouterConfig.js";
import { JsonFileUsageStore } from "./usage/jsonFileUsageStore.js";
import { discoverBentoTasks, generateTaskIdTypes } from "./tasks/taskDiscovery.js";

async function main(argv: string[]): Promise<void> {
  const [command, maybeArg] = argv;

  switch (command) {
    case "tasks": {
      const runtime = createBentoRouterRuntimeFromConfig(await readConfig(argv));
      console.log(JSON.stringify(discoverBentoTasks(runtime.taskRegistry), null, 2));
      return;
    }
    case "types": {
      const runtime = createBentoRouterRuntimeFromConfig(await readConfig(argv));
      console.log(generateTaskIdTypes(runtime.taskRegistry, readFlag(argv, "--name") ?? "BentoTaskId"));
      return;
    }
    case "usage": {
      const file = readFlag(argv, "--file") ?? ".bento-router/usage.json";
      console.log(JSON.stringify(await new JsonFileUsageStore(file).summarize(), null, 2));
      return;
    }
    case "test": {
      if (!maybeArg) throw new Error("Usage: bento-router test <task-id> --config ./router.json");
      const runtime = createBentoRouterRuntimeFromConfig(await readConfig(argv));
      const result = await runtime.router.run({
        task: maybeArg,
        messages: [{ role: "user", content: readFlag(argv, "--message") ?? "Hello" }],
      });
      console.log(JSON.stringify(result, null, 2));
      return;
    }
    case "doctor": {
      console.log(JSON.stringify({
        ok: true,
        node: process.version,
        openRouterConfigured: Boolean(process.env.OPENROUTER_API_KEY),
        openAiConfigured: Boolean(process.env.OPENAI_API_KEY),
        anthropicConfigured: Boolean(process.env.ANTHROPIC_API_KEY),
      }, null, 2));
      return;
    }
    default:
      console.log([
        "Usage: bento-router <command>",
        "",
        "Commands:",
        "  tasks --config ./router.json",
        "  types --config ./router.json [--name BentoTaskId]",
        "  test <task-id> --config ./router.json [--message Hello]",
        "  usage [--file .bento-router/usage.json]",
        "  doctor",
      ].join("\n"));
  }
}

async function readConfig(argv: string[]): Promise<BentoRouterConfig> {
  const path = readFlag(argv, "--config");
  if (!path) return {};
  return JSON.parse(await readFile(path, "utf8")) as BentoRouterConfig;
}

function readFlag(argv: string[], flag: string): string | undefined {
  const index = argv.indexOf(flag);
  return index === -1 ? undefined : argv[index + 1];
}

main(process.argv.slice(2)).catch((error) => {
  console.error(error instanceof Error ? error.message : String(error));
  process.exitCode = 1;
});
