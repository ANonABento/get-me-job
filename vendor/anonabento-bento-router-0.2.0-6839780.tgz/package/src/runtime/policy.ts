import type { PolicyOverrides, TaskDefinition, TaskPolicy } from "../types.js";

export const defaultGlobalPolicy: TaskPolicy = {
  primaryModel: "openrouter/openai/gpt-4.1-mini",
  fallbacks: ["openrouter/google/gemini-flash"],
  guardrails: {
    maxInputTokens: 8000,
    maxOutputTokens: 1000,
    timeoutMs: 15000,
    maxRetries: 1,
    maxRequestCostUsd: 0.02,
  },
  budget: {
    dailyAppBudgetUsd: 10,
  },
  circuitBreaker: {
    failureThreshold: 3,
    cooldownMs: 60000,
  },
  degradation: {
    mode: "short_response",
    message: "AI is temporarily running in a lower-cost mode.",
  },
};

export function resolvePolicy(
  task: TaskDefinition,
  overrides: PolicyOverrides = {},
): TaskPolicy {
  return mergePolicies(
    defaultGlobalPolicy,
    overrides.global,
    overrides.app?.[task.appId],
    task.defaultPolicy,
    overrides.task?.[task.id],
  );
}

export function mergePolicies(...policies: Array<Partial<TaskPolicy> | undefined>): TaskPolicy {
  const merged: TaskPolicy = { ...defaultGlobalPolicy };

  for (const policy of policies) {
    if (!policy) continue;

    if (policy.primaryModel !== undefined) merged.primaryModel = policy.primaryModel;
    if (policy.fallbacks !== undefined) merged.fallbacks = [...policy.fallbacks];
    if (policy.modelRequirements !== undefined) {
      merged.modelRequirements = {
        ...merged.modelRequirements,
        ...policy.modelRequirements,
        caps: {
          ...merged.modelRequirements?.caps,
          ...policy.modelRequirements.caps,
        },
        allowedQualityTiers: policy.modelRequirements.allowedQualityTiers
          ? [...policy.modelRequirements.allowedQualityTiers]
          : merged.modelRequirements?.allowedQualityTiers,
      };
    }
    if (policy.routing !== undefined) {
      merged.routing = {
        ...merged.routing,
        ...policy.routing,
        canary: policy.routing.canary ? { ...policy.routing.canary } : merged.routing?.canary,
        weights: policy.routing.weights ? { ...policy.routing.weights } : merged.routing?.weights,
        rateLimit: policy.routing.rateLimit ? { ...policy.routing.rateLimit } : merged.routing?.rateLimit,
      };
    }
    if (policy.approval !== undefined) {
      merged.approval = {
        ...merged.approval,
        ...policy.approval,
        requireForQualityTiers: policy.approval.requireForQualityTiers
          ? [...policy.approval.requireForQualityTiers]
          : merged.approval?.requireForQualityTiers,
      };
    }
    if (policy.guardrails !== undefined) {
      merged.guardrails = { ...merged.guardrails, ...policy.guardrails };
    }
    if (policy.budget !== undefined) {
      merged.budget = { ...merged.budget, ...policy.budget };
    }
    if (policy.circuitBreaker !== undefined) {
      merged.circuitBreaker = { ...merged.circuitBreaker, ...policy.circuitBreaker };
    }
    if (policy.degradation !== undefined) {
      merged.degradation = { ...merged.degradation, ...policy.degradation };
    }
  }

  return merged;
}
