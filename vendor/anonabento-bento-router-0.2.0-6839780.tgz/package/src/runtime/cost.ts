import type { ModelProfile } from "../types.js";

export function estimateCostUsd(
  model: ModelProfile,
  inputTokens: number,
  outputTokens: number,
): number {
  const inputCost = (inputTokens / 1_000_000) * model.inputCostPerMillionTokens;
  const outputCost = (outputTokens / 1_000_000) * model.outputCostPerMillionTokens;
  return roundUsd(inputCost + outputCost);
}

export function roundUsd(value: number): number {
  return Math.round(value * 1_000_000) / 1_000_000;
}
