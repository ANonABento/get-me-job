import type { BentoRouter } from "./bentoRouter.js";
import type { BentoRouterInput } from "../types.js";

export type StructuredJsonOptions<T> = {
  router: BentoRouter;
  input: BentoRouterInput;
  validate?: (value: unknown) => value is T;
  maxInvalidRetries?: number;
};

export async function runBentoJsonTask<T = unknown>({
  router,
  input,
  validate,
  maxInvalidRetries = 1,
}: StructuredJsonOptions<T>): Promise<T> {
  let lastText = "";

  for (let attempt = 0; attempt <= maxInvalidRetries; attempt += 1) {
    const result = await router.run({
      ...input,
      messages:
        attempt === 0
          ? input.messages
          : [
              ...input.messages,
              {
                role: "user",
                content:
                  "Return only valid JSON matching the requested shape. Do not include markdown.",
              },
            ],
    });
    lastText = result.text;

    try {
      const parsed = JSON.parse(extractJson(result.text)) as unknown;
      if (!validate || validate(parsed)) return parsed as T;
    } catch {
      // Retry with the corrective instruction above.
    }
  }

  throw new Error(`BentoRouter JSON task returned invalid JSON: ${lastText.slice(0, 200)}`);
}

function extractJson(text: string): string {
  const trimmed = text.trim();
  if (!trimmed.startsWith("```")) return trimmed;
  return trimmed
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/\s*```$/, "")
    .trim();
}
