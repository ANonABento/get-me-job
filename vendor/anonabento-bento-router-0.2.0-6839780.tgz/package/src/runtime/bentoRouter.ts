import type {
  BentoRouterInput,
  BentoRouterEmbeddingInput,
  BentoRouterEmbeddingResult,
  BentoRouterResult,
  DegradationMode,
  ModelProfile,
  PolicyOverrides,
  ProviderAdapter,
  TaskPolicy,
  UsageEvent,
  ProviderStreamChunk,
} from "../types.js";
import { ModelRegistry, createDefaultModelRegistry } from "../providers/modelRegistry.js";
import { ProviderRegistry } from "../providers/providerRegistry.js";
import { mergePolicyOverrides, type PolicyStore } from "../policies/policyStore.js";
import { TaskRegistry, defaultTaskRegistry } from "../tasks/taskRegistry.js";
import { MemoryUsageStore } from "../usage/memoryUsageStore.js";
import type { UsageStore } from "../usage/usageStore.js";
import { CircuitBreaker } from "./circuitBreaker.js";
import { estimateCostUsd } from "./cost.js";
import { resolvePolicy } from "./policy.js";
import { estimateMessageTokens } from "./tokenEstimate.js";
import type { ProviderConfigStore } from "../providers/providerConfigStore.js";
import type { EncryptionAdapter } from "../providers/runtimeProviderConfig.js";

export type BentoRouterOptions = {
  taskRegistry?: TaskRegistry;
  modelRegistry?: ModelRegistry;
  providerRegistry: ProviderRegistry;
  usageStore?: UsageStore;
  policyOverrides?: PolicyOverrides;
  policyStore?: PolicyStore;
  providerConfigStore?: ProviderConfigStore;
  encryption?: EncryptionAdapter;
  circuitBreaker?: CircuitBreaker;
  random?: () => number;
  redactUsageEvent?: (event: UsageEvent) => UsageEvent;
  outputValidators?: Record<string, BentoRouterOutputValidator>;
  responseCache?: BentoRouterResponseCache;
};

export type BentoRouterOutputValidator = (output: {
  text: string;
  taskId: string;
  model: string;
  provider: string;
}) => boolean | string | void | Promise<boolean | string | void>;

export type BentoRouterResponseCache = {
  get(taskId: string, userId?: string): Promise<string | undefined> | string | undefined;
  set(taskId: string, text: string, userId?: string): Promise<void> | void;
};

export class BentoRouter {
  private readonly taskRegistry: TaskRegistry;
  private readonly modelRegistry: ModelRegistry;
  private readonly providerRegistry: ProviderRegistry;
  private readonly usageStore: UsageStore;
  private readonly policyOverrides: PolicyOverrides;
  private readonly policyStore?: PolicyStore;
  private readonly circuitBreaker: CircuitBreaker;
  private readonly random: () => number;
  private readonly redactUsageEvent?: (event: UsageEvent) => UsageEvent;
  private readonly outputValidators: Record<string, BentoRouterOutputValidator>;
  private readonly responseCache?: BentoRouterResponseCache;
  private readonly taskRequestTimestamps = new Map<string, number[]>();
  private readonly providerConcurrency = new Map<string, number>();

  constructor(options: BentoRouterOptions) {
    if (options.encryption && !options.providerConfigStore) {
      throw new Error("BentoRouter encryption requires providerConfigStore");
    }
    if (options.providerConfigStore && !options.encryption) {
      console.warn(
        "[BentoRouter] providerConfigStore configured without an EncryptionAdapter. API keys will be stored as plaintext; this is acceptable only for local development.",
      );
    }
    this.taskRegistry = options.taskRegistry ?? defaultTaskRegistry;
    this.modelRegistry = options.modelRegistry ?? createDefaultModelRegistry();
    this.providerRegistry = options.providerRegistry;
    this.usageStore = options.usageStore ?? new MemoryUsageStore();
    this.policyOverrides = options.policyOverrides ?? {};
    this.policyStore = options.policyStore;
    this.circuitBreaker = options.circuitBreaker ?? new CircuitBreaker();
    this.random = options.random ?? Math.random;
    this.redactUsageEvent = options.redactUsageEvent;
    this.outputValidators = options.outputValidators ?? {};
    this.responseCache = options.responseCache;
  }

  async run(input: BentoRouterInput): Promise<BentoRouterResult> {
    const task = this.taskRegistry.require(input.task);
    const policy = resolvePolicy(task, await this.readPolicyOverrides());
    const inputTokens = await this.countInputTokens(input.messages, policy.primaryModel);
    const requestId = input.requestId ?? crypto.randomUUID();
    const maxOutputTokens = policy.guardrails?.maxOutputTokens ?? 1000;
    const context = requestContext(input);

    if (this.isRateLimited(task.id, policy)) {
      return this.blockedResult({
        taskId: task.id,
        appId: task.appId,
        userId: input.userId,
        ...context,
        requestId,
        reason: "task_rate_limited",
        inputTokens,
        degradation: policy.degradation?.mode,
        degradationMessage: policy.degradation?.message,
      });
    }

    if (policy.guardrails?.maxInputTokens && inputTokens > policy.guardrails.maxInputTokens) {
      return this.blockedResult({
        taskId: task.id,
        appId: task.appId,
        userId: input.userId,
        ...context,
        requestId,
        reason: "input_token_ceiling",
        inputTokens,
        degradation: policy.degradation?.mode,
        degradationMessage: policy.degradation?.message,
      });
    }

    const dailyBudgetBlock = await this.checkDailyBudgets(
      task.appId,
      task.id,
      input.userId,
      input.orgId,
      policy,
    );
    if (dailyBudgetBlock) {
      return this.blockedResult({
        taskId: task.id,
        appId: task.appId,
        userId: input.userId,
        ...context,
        requestId,
        reason: dailyBudgetBlock,
        inputTokens,
        degradation: policy.degradation?.mode,
        degradationMessage: policy.degradation?.message,
      });
    }

    this.recordRateLimitHit(task.id, policy);

    const modelChain = selectModelChain(policy, this.random());
    const attempts: UsageEvent[] = [];
    let lastError: unknown;

    for (let fallbackIndex = 0; fallbackIndex < modelChain.length; fallbackIndex += 1) {
      const model = this.modelRegistry.require(modelChain[fallbackIndex]);
      const estimatedCost = estimateCostUsd(model, inputTokens, maxOutputTokens);

      if (requiresApproval(model, policy)) {
        const event = await this.recordAttempt({
          appId: task.appId,
          taskId: task.id,
          userId: input.userId,
          ...context,
          requestId,
          model,
          fallbackIndex,
          inputTokens,
          estimatedCostUsd: estimatedCost,
          status: "blocked",
          latencyMs: 0,
          errorCode: "model_approval_required",
          errorMessage: "Model requires approval for this task",
        });
        attempts.push(event);
        continue;
      }

      const requirementFailure = modelRequirementFailure(model, policy, inputTokens + maxOutputTokens);
      if (requirementFailure) {
        const event = await this.recordAttempt({
          appId: task.appId,
          taskId: task.id,
          userId: input.userId,
          ...context,
          requestId,
          model,
          fallbackIndex,
          inputTokens,
          estimatedCostUsd: estimatedCost,
          status: "skipped",
          latencyMs: 0,
          errorCode: requirementFailure,
          errorMessage: "Model does not satisfy task requirements",
        });
        attempts.push(event);
        continue;
      }

      if (policy.guardrails?.maxRequestCostUsd && estimatedCost > policy.guardrails.maxRequestCostUsd) {
        const event = await this.recordAttempt({
          appId: task.appId,
          taskId: task.id,
          userId: input.userId,
          ...context,
          requestId,
          model,
          fallbackIndex,
          inputTokens,
          estimatedCostUsd: estimatedCost,
          status: "blocked",
          latencyMs: 0,
          errorCode: "request_cost_ceiling",
          errorMessage: `Estimated cost ${estimatedCost} exceeds ${policy.guardrails.maxRequestCostUsd}`,
          degradationUsed: fallbackIndex === modelChain.length - 1 ? policy.degradation?.mode : undefined,
        });
        attempts.push(event);
        continue;
      }

      if (policy.circuitBreaker && !this.circuitBreaker.canAttempt(model.id, policy.circuitBreaker)) {
        const event = await this.recordAttempt({
          appId: task.appId,
          taskId: task.id,
          userId: input.userId,
          ...context,
          requestId,
          model,
          fallbackIndex,
          inputTokens,
          estimatedCostUsd: estimatedCost,
          status: "skipped",
          latencyMs: 0,
          errorCode: "circuit_open",
          errorMessage: "Circuit breaker is open for selected model",
        });
        attempts.push(event);
        continue;
      }

      const retries = policy.guardrails?.maxRetries ?? 0;
      for (let retry = 0; retry <= retries; retry += 1) {
        const provider = this.providerRegistry.require(model.provider);
        if (!this.tryAcquireProvider(provider.id, policy)) {
          const event = await this.recordAttempt({
            appId: task.appId,
            taskId: task.id,
            userId: input.userId,
          ...context,
            requestId,
            model,
            provider,
            fallbackIndex,
            inputTokens,
            estimatedCostUsd: estimatedCost,
            status: "skipped",
            latencyMs: 0,
            errorCode: "provider_concurrency_limited",
            errorMessage: "Provider concurrency limit is reached",
          });
          attempts.push(event);
          continue;
        }
        const startedAt = Date.now();

        try {
          const response = await provider.complete({
            model: model.id,
            messages: input.messages,
            temperature: input.temperature,
            maxOutputTokens,
            timeoutMs: policy.guardrails?.timeoutMs,
            tools: input.metadata?.tools as never,
            toolChoice: input.metadata?.toolChoice as never,
          });
          const latencyMs = Date.now() - startedAt;
          await this.validateOutput({
            text: response.text,
            taskId: task.id,
            model: model.id,
            provider: provider.id,
          });
          const actualInputTokens = response.inputTokens ?? inputTokens;
          const actualOutputTokens = response.outputTokens ?? estimateTextOutputTokens(response.text);
          const actualCostUsd = estimateCostUsd(model, actualInputTokens, actualOutputTokens);

          const event = await this.recordAttempt({
            appId: task.appId,
            taskId: task.id,
            userId: input.userId,
          ...context,
            requestId,
            model,
            provider,
            fallbackIndex,
            inputTokens,
            estimatedCostUsd: estimatedCost,
            actualCostUsd,
            inputTokensActual: actualInputTokens,
            outputTokensActual: actualOutputTokens,
            status: "success",
            latencyMs,
          });
          attempts.push(event);

          if (policy.circuitBreaker) this.circuitBreaker.recordSuccess(model.id);
          await this.responseCache?.set(task.id, response.text, input.userId);

          return {
            status: fallbackIndex === 0 ? "success" : "degraded",
            taskId: task.id,
            model: model.id,
            provider: model.provider,
            text: response.text,
            attempts,
            degraded: fallbackIndex !== 0,
            reason: fallbackIndex === 0 ? undefined : "fallback_used",
          };
        } catch (error) {
          lastError = error;
          const latencyMs = Date.now() - startedAt;
          const event = await this.recordAttempt({
            appId: task.appId,
            taskId: task.id,
            userId: input.userId,
          ...context,
            requestId,
            model,
            provider,
            fallbackIndex,
            inputTokens,
            estimatedCostUsd: estimatedCost,
            status: "failure",
            latencyMs,
            errorCode: error instanceof Error ? error.name : "provider_error",
            errorMessage: error instanceof Error ? error.message : String(error),
          });
          attempts.push(event);

          if (policy.circuitBreaker) this.circuitBreaker.recordFailure(model.id, policy.circuitBreaker);
        } finally {
          this.releaseProvider(provider.id);
        }
      }
    }

    const degraded = await this.degradedTextForTask(
      task.id,
      input.userId,
      policy.degradation?.mode,
      policy.degradation?.message,
    );
    if (degraded) {
      const event = await this.recordAttempt({
        appId: task.appId,
        taskId: task.id,
        userId: input.userId,
          ...context,
        requestId,
        fallbackIndex: modelChain.length,
        inputTokens,
        estimatedCostUsd: 0,
        status: "degraded",
        latencyMs: 0,
        errorCode: "all_models_unavailable",
        errorMessage: lastError instanceof Error ? lastError.message : String(lastError ?? "No model available"),
        degradationUsed: policy.degradation?.mode,
      });
      attempts.push(event);

      return {
        status: "degraded",
        taskId: task.id,
        text: degraded,
        attempts,
        degraded: true,
        reason: "all_models_unavailable",
      };
    }

    return {
      status: "failed",
      taskId: task.id,
      text: "",
      attempts,
      degraded: false,
      reason: lastError instanceof Error ? lastError.message : "No model available",
    };
  }

  async *stream(input: BentoRouterInput): AsyncIterable<ProviderStreamChunk> {
    const task = this.taskRegistry.require(input.task);
    const policy = resolvePolicy(task, await this.readPolicyOverrides());
    const model = this.modelRegistry.require(selectModelChain(policy, this.random())[0]);
    const provider = this.providerRegistry.require(model.provider);
    const request = {
      model: model.id,
      messages: input.messages,
      temperature: input.temperature,
      maxOutputTokens: policy.guardrails?.maxOutputTokens,
      timeoutMs: policy.guardrails?.timeoutMs,
      tools: input.metadata?.tools as never,
      toolChoice: input.metadata?.toolChoice as never,
    };

    if (provider.stream) {
      yield* provider.stream(request);
      return;
    }

    const response = await provider.complete(request);
    yield { text: response.text, raw: response.raw };
  }

  async embed(input: BentoRouterEmbeddingInput): Promise<BentoRouterEmbeddingResult> {
    const task = this.taskRegistry.require(input.task);
    const policy = resolvePolicy(task, await this.readPolicyOverrides());
    const model = this.modelRegistry.require(input.model ?? policy.primaryModel);
    const provider = this.providerRegistry.require(model.provider);
    const requestId = input.requestId ?? crypto.randomUUID();
    const inputTokens = estimateTextOutputTokens(Array.isArray(input.input) ? input.input.join("\n") : input.input);
    const context = requestContext(input);

    if (!provider.embed) {
      const event = await this.recordAttempt({
        appId: task.appId,
        taskId: task.id,
        userId: input.userId,
          ...context,
        requestId,
        model,
        provider,
        fallbackIndex: 0,
        inputTokens,
        estimatedCostUsd: estimateCostUsd(model, inputTokens, 0),
        status: "failure",
        latencyMs: 0,
        errorCode: "embedding_unsupported",
        errorMessage: "Provider does not support embeddings",
      });
      return {
        status: "failed",
        taskId: task.id,
        embeddings: [],
        attempts: [event],
        degraded: false,
        reason: "embedding_unsupported",
      };
    }

    const startedAt = Date.now();
    const response = await provider.embed({
      model: model.id,
      input: input.input,
      timeoutMs: policy.guardrails?.timeoutMs,
    });
    const actualInputTokens = response.inputTokens ?? inputTokens;
    const event = await this.recordAttempt({
      appId: task.appId,
      taskId: task.id,
      userId: input.userId,
          ...context,
      requestId,
      model,
      provider,
      fallbackIndex: 0,
      inputTokens,
      estimatedCostUsd: estimateCostUsd(model, inputTokens, 0),
      actualCostUsd: estimateCostUsd(model, actualInputTokens, 0),
      inputTokensActual: actualInputTokens,
      outputTokensActual: 0,
      status: "success",
      latencyMs: Date.now() - startedAt,
    });

    return {
      status: "success",
      taskId: task.id,
      model: model.id,
      provider: provider.id,
      embeddings: response.embeddings,
      attempts: [event],
      degraded: false,
    };
  }

  private async checkDailyBudgets(
    appId: string,
    taskId: string,
    userId: string | undefined,
    orgId: string | undefined,
    policy: TaskPolicy,
  ): Promise<string | undefined> {
    const since = startOfUtcDay(new Date());
    const budget = policy.budget;
    if (!budget) return undefined;

    if (budget.dailyAppBudgetUsd !== undefined) {
      const summary = await this.usageStore.summarize({ appId, since });
      if (summary.actualCostUsd >= budget.dailyAppBudgetUsd) return "daily_app_budget";
    }

    if (budget.dailyTaskBudgetUsd !== undefined) {
      const summary = await this.usageStore.summarize({ appId, taskId, since });
      if (summary.actualCostUsd >= budget.dailyTaskBudgetUsd) return "daily_task_budget";
    }

    if (budget.dailyUserBudgetUsd !== undefined && userId) {
      const summary = await this.usageStore.summarize({ appId, userId, since });
      if (summary.actualCostUsd >= budget.dailyUserBudgetUsd) return "daily_user_budget";
    }

    if (budget.dailyOrgBudgetUsd !== undefined && orgId) {
      const summary = await this.usageStore.summarize({ appId, orgId, since });
      if (summary.actualCostUsd >= budget.dailyOrgBudgetUsd) return "daily_org_budget";
    }

    return undefined;
  }

  private async readPolicyOverrides(): Promise<PolicyOverrides> {
    if (!this.policyStore) return this.policyOverrides;
    return mergePolicyOverrides(this.policyOverrides, await this.policyStore.read());
  }

  private async countInputTokens(messages: BentoRouterInput["messages"], modelId: string): Promise<number> {
    const model = this.modelRegistry.get(modelId);
    const provider = model ? this.providerRegistry.get(model.provider) : undefined;
    return (await provider?.countTokens?.(messages, modelId)) ?? estimateMessageTokens(messages);
  }

  private isRateLimited(taskId: string, policy: TaskPolicy): boolean {
    const rateLimit = policy.routing?.rateLimit;
    if (!rateLimit) return false;
    const now = Date.now();
    const since = now - rateLimit.windowMs;
    const hits = (this.taskRequestTimestamps.get(taskId) ?? []).filter((hit) => hit >= since);
    this.taskRequestTimestamps.set(taskId, hits);
    return hits.length >= rateLimit.maxRequests;
  }

  private recordRateLimitHit(taskId: string, policy: TaskPolicy): void {
    if (!policy.routing?.rateLimit) return;
    const hits = this.taskRequestTimestamps.get(taskId) ?? [];
    hits.push(Date.now());
    this.taskRequestTimestamps.set(taskId, hits);
  }

  private tryAcquireProvider(providerId: string, policy: TaskPolicy): boolean {
    const max = policy.routing?.maxConcurrentProviderRequests;
    if (!max) return true;
    const current = this.providerConcurrency.get(providerId) ?? 0;
    if (current >= max) return false;
    this.providerConcurrency.set(providerId, current + 1);
    return true;
  }

  private releaseProvider(providerId: string): void {
    const current = this.providerConcurrency.get(providerId) ?? 0;
    if (current <= 1) {
      this.providerConcurrency.delete(providerId);
      return;
    }
    this.providerConcurrency.set(providerId, current - 1);
  }

  private async blockedResult(options: {
    appId: string;
    taskId: string;
    userId?: string;
    orgId?: string;
    projectId?: string;
    environment?: string;
    requestId: string;
    reason: string;
    inputTokens: number;
    degradation?: DegradationMode;
    degradationMessage?: string;
  }): Promise<BentoRouterResult> {
    const text = await this.degradedTextForTask(
      options.taskId,
      options.userId,
      options.degradation,
      options.degradationMessage,
    );
    const event = await this.recordAttempt({
      appId: options.appId,
      taskId: options.taskId,
      userId: options.userId,
      orgId: options.orgId,
      projectId: options.projectId,
      environment: options.environment,
      requestId: options.requestId,
      fallbackIndex: 0,
      inputTokens: options.inputTokens,
      estimatedCostUsd: 0,
      status: text ? "degraded" : "blocked",
      latencyMs: 0,
      errorCode: options.reason,
      errorMessage: options.reason,
      degradationUsed: options.degradation,
    });

    return {
      status: text ? "degraded" : "blocked",
      taskId: options.taskId,
      text,
      attempts: [event],
      degraded: Boolean(text),
      reason: options.reason,
    };
  }

  private degradedText(mode?: DegradationMode, message?: string): string {
    if (!mode || mode === "none" || mode === "cheaper_model") return "";
    return message ?? "AI output is temporarily limited. Please try again later.";
  }

  private async degradedTextForTask(
    taskId: string,
    userId: string | undefined,
    mode?: DegradationMode,
    message?: string,
  ): Promise<string> {
    if (mode === "cached_response") {
      return (await this.responseCache?.get(taskId, userId)) ?? message ?? "";
    }
    return this.degradedText(mode, message);
  }

  private async validateOutput(output: {
    text: string;
    taskId: string;
    model: string;
    provider: string;
  }): Promise<void> {
    const validator = this.outputValidators[output.taskId];
    if (!validator) return;
    const result = await validator(output);
    if (result === false) throw new Error("Output validation failed");
    if (typeof result === "string" && result.length > 0) throw new Error(result);
  }

  private async recordAttempt(options: {
    appId: string;
    taskId: string;
    userId?: string;
    orgId?: string;
    projectId?: string;
    environment?: string;
    requestId: string;
    model?: ModelProfile;
    provider?: ProviderAdapter;
    fallbackIndex: number;
    inputTokens: number;
    estimatedCostUsd: number;
    actualCostUsd?: number;
    inputTokensActual?: number;
    outputTokensActual?: number;
    status: UsageEvent["status"];
    latencyMs: number;
    errorCode?: string;
    errorMessage?: string;
    degradationUsed?: DegradationMode;
  }): Promise<UsageEvent> {
    const event: UsageEvent = {
      id: crypto.randomUUID(),
      timestamp: new Date().toISOString(),
      appId: options.appId,
      taskId: options.taskId,
      userId: options.userId,
      orgId: options.orgId,
      projectId: options.projectId,
      environment: options.environment,
      requestId: options.requestId,
      provider: options.provider?.id ?? options.model?.provider,
      model: options.model?.id,
      status: options.status,
      fallbackIndex: options.fallbackIndex,
      inputTokensEstimated: options.inputTokens,
      inputTokensActual: options.inputTokensActual,
      outputTokensActual: options.outputTokensActual,
      estimatedCostUsd: options.estimatedCostUsd,
      actualCostUsd: options.actualCostUsd,
      latencyMs: options.latencyMs,
      errorCode: options.errorCode,
      errorMessage: options.errorMessage,
      degradationUsed: options.degradationUsed,
      promptId: this.taskRegistry.get(options.taskId)?.prompt?.id,
      promptVersion: this.taskRegistry.get(options.taskId)?.prompt?.version,
    };
    const redacted = this.redactUsageEvent ? this.redactUsageEvent(event) : event;
    await this.usageStore.record(redacted);
    return redacted;
  }
}

function estimateTextOutputTokens(text: string): number {
  return Math.ceil(text.length / 4);
}

function startOfUtcDay(date: Date): Date {
  return new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
}

function requestContext(input: {
  orgId?: string;
  projectId?: string;
  environment?: string;
}): { orgId?: string; projectId?: string; environment?: string } {
  return {
    orgId: input.orgId,
    projectId: input.projectId,
    environment: input.environment,
  };
}

function modelRequirementFailure(
  model: ModelProfile,
  policy: TaskPolicy,
  requestedTokens: number,
): string | undefined {
  const requirements = policy.modelRequirements;
  if (!requirements) return undefined;

  if (
    requirements.allowedQualityTiers &&
    !requirements.allowedQualityTiers.includes(model.qualityTier)
  ) {
    return "model_quality_tier_unsupported";
  }

  if (requirements.minContextTokens && model.maxContextTokens < requirements.minContextTokens) {
    return "model_context_unsupported";
  }

  if (model.maxContextTokens < requestedTokens) {
    return "model_context_too_small";
  }

  for (const [cap, required] of Object.entries(requirements.caps ?? {})) {
    if (required && !model.caps[cap as keyof ModelProfile["caps"]]) {
      return `model_${cap}_unsupported`;
    }
  }

  return undefined;
}

function requiresApproval(model: ModelProfile, policy: TaskPolicy): boolean {
  const approval = policy.approval;
  const requiredTiers = approval?.requireForQualityTiers;
  if (!requiredTiers?.includes(model.qualityTier)) return false;
  return approval?.approved !== true;
}

export function createBentoRouter(options: BentoRouterOptions): BentoRouter {
  return new BentoRouter(options);
}

function selectModelChain(policy: TaskPolicy, random: number): string[] {
  const baseChain = unique([policy.primaryModel, ...(policy.fallbacks ?? [])]);
  const canary = policy.routing?.canary;
  if (canary && random < canary.percentage) {
    return unique([canary.model, ...baseChain]);
  }

  const weights = policy.routing?.weights;
  if (!weights || Object.keys(weights).length === 0) return baseChain;

  const candidates = baseChain.filter((modelId) => (weights[modelId] ?? 0) > 0);
  if (candidates.length === 0) return baseChain;
  const total = candidates.reduce((sum, modelId) => sum + (weights[modelId] ?? 0), 0);
  let cursor = random * total;
  for (const modelId of candidates) {
    cursor -= weights[modelId] ?? 0;
    if (cursor <= 0) return unique([modelId, ...baseChain]);
  }
  return unique([candidates[candidates.length - 1], ...baseChain]);
}

function unique(values: string[]): string[] {
  return [...new Set(values)];
}
