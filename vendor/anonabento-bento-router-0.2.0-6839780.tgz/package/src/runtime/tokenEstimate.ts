import type { ChatMessage } from "../types.js";

export function estimateMessageTokens(messages: ChatMessage[]): number {
  const content = messages.map((message) => `${message.role}: ${contentText(message.content)}`).join("\n");
  return estimateTextTokens(content);
}

export function estimateTextTokens(text: string): number {
  if (!text) return 0;
  return Math.ceil(text.length / 4);
}

function contentText(content: ChatMessage["content"]): string {
  if (typeof content === "string") return content;
  return content
    .map((part) => part.type === "text" ? part.text : part.image_url.url)
    .join("\n");
}
