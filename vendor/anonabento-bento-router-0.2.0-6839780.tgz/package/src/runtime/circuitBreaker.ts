import type { CircuitBreakerPolicy } from "../types.js";

type CircuitState = {
  failures: number;
  openedAt?: number;
};

export class CircuitBreaker {
  private readonly state = new Map<string, CircuitState>();

  canAttempt(key: string, policy: CircuitBreakerPolicy, now = Date.now()): boolean {
    const state = this.state.get(key);
    if (!state?.openedAt) return true;

    if (now - state.openedAt >= policy.cooldownMs) {
      this.state.set(key, { failures: 0 });
      return true;
    }

    return false;
  }

  recordSuccess(key: string): void {
    this.state.set(key, { failures: 0 });
  }

  recordFailure(key: string, policy: CircuitBreakerPolicy, now = Date.now()): void {
    const current = this.state.get(key) ?? { failures: 0 };
    const failures = current.failures + 1;
    this.state.set(key, {
      failures,
      openedAt: failures >= policy.failureThreshold ? now : current.openedAt,
    });
  }

  snapshot(key: string): { failures: number; open: boolean; openedAt?: number } {
    const current = this.state.get(key) ?? { failures: 0 };
    return {
      failures: current.failures,
      open: current.openedAt !== undefined,
      openedAt: current.openedAt,
    };
  }

  snapshotAll(): Record<string, { failures: number; open: boolean; openedAt?: number }> {
    return Object.fromEntries([...this.state.keys()].map((key) => [key, this.snapshot(key)]));
  }
}
