import { useState, type CSSProperties, type FormEvent } from "react";
import type { AddProviderInput } from "../server/createBentoRouterApi.js";
import type { ProviderConfig } from "../providers/providerConfigStore.js";
import type {
  ValidateProviderInput,
  ValidateProviderResult,
} from "../providers/providerValidation.js";

export type BentoTaskAdminSummary = {
  id: string;
  appId: string;
  name: string;
  category?: string;
  effectivePolicy?: {
    primaryModel?: string;
    fallbacks?: string[];
    guardrails?: {
      maxRequestCostUsd?: number;
      timeoutMs?: number;
      maxRetries?: number;
    };
  };
};

export type BentoTaskAdminModelOption = {
  id: string;
  displayName?: string;
};

export type BentoTaskPolicyPatch = {
  primaryModel?: string;
  fallbacks?: string[];
  guardrails?: {
    maxRequestCostUsd?: number;
    timeoutMs?: number;
    maxRetries?: number;
  };
};

export type ProviderConfigSummary = Pick<
  ProviderConfig,
  "id" | "type" | "displayName" | "createdAt" | "baseUrl"
>;

export type BentoRouterAdminPageProps = {
  tasks: BentoTaskAdminSummary[];
  models?: BentoTaskAdminModelOption[];
  providers?: ProviderConfigSummary[];
  userId?: string;
  selectedTaskId?: string;
  onSelectTask?: (taskId: string) => void;
  onPolicyChange?: (taskId: string, policy: BentoTaskPolicyPatch) => void;
  onAddProvider?: (input: AddProviderInput) => Promise<void>;
  onRemoveProvider?: (userId: string, id: string) => Promise<void>;
  onValidateProvider?: (input: ValidateProviderInput) => Promise<ValidateProviderResult>;
  style?: CSSProperties;
};

export function BentoRouterAdminPage({
  tasks,
  models = [],
  providers,
  userId = "default",
  selectedTaskId,
  onSelectTask,
  onPolicyChange,
  onAddProvider,
  onRemoveProvider,
  onValidateProvider,
  style,
}: BentoRouterAdminPageProps) {
  const selectedTask = tasks.find((task) => task.id === selectedTaskId) ?? tasks[0];
  const selectedPolicy = selectedTask?.effectivePolicy;
  const [providerType, setProviderType] = useState<AddProviderInput["type"]>("openai");
  const [displayName, setDisplayName] = useState("");
  const [apiKey, setApiKey] = useState("");
  const [baseUrl, setBaseUrl] = useState("");
  const [defaultModel, setDefaultModel] = useState("");
  const [validationResult, setValidationResult] = useState<ValidateProviderResult | null>(null);
  const [isBusy, setIsBusy] = useState(false);

  async function submitProvider(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!onAddProvider) return;
    setIsBusy(true);
    try {
      await onAddProvider({
        type: providerType,
        displayName,
        apiKey,
        baseUrl: baseUrl || undefined,
        defaultModel: defaultModel || undefined,
        userId,
      });
      setDisplayName("");
      setApiKey("");
      setBaseUrl("");
      setDefaultModel("");
      setValidationResult(null);
    } finally {
      setIsBusy(false);
    }
  }

  async function validateCurrentProvider() {
    if (!onValidateProvider) return;
    setIsBusy(true);
    try {
      setValidationResult(
        await onValidateProvider({
          type: providerType,
          apiKey,
          baseUrl: baseUrl || undefined,
        }),
      );
    } finally {
      setIsBusy(false);
    }
  }

  return (
    <section className="bento-router-admin" style={style}>
      <style>{adminStyles}</style>
      {providers ? (
        <section className="bento-router-admin__providers">
          <header className="bento-router-admin__section-header">
            <h2>Providers</h2>
          </header>
          <div className="bento-router-admin__provider-list">
            {providers.length > 0 ? (
              providers.map((provider) => (
                <div className="bento-router-admin__provider" key={provider.id}>
                  <div>
                    <strong>{provider.displayName}</strong>
                    <span>{provider.type}</span>
                    {provider.baseUrl ? <code>{provider.baseUrl}</code> : null}
                  </div>
                  <button
                    className="bento-router-admin__button"
                    disabled={!onRemoveProvider || isBusy}
                    onClick={() => onRemoveProvider?.(userId, provider.id)}
                    type="button"
                  >
                    Remove
                  </button>
                </div>
              ))
            ) : (
              <p className="bento-router-admin__empty">No providers configured.</p>
            )}
          </div>

          {onAddProvider ? (
            <form className="bento-router-admin__provider-form" onSubmit={submitProvider}>
              <label>
                <span>Provider</span>
                <select
                  value={providerType}
                  onChange={(event) => setProviderType(event.currentTarget.value as AddProviderInput["type"])}
                >
                  <option value="openai">OpenAI</option>
                  <option value="anthropic">Anthropic</option>
                  <option value="openrouter">OpenRouter</option>
                  <option value="openai-compatible">OpenAI-compatible</option>
                </select>
              </label>
              <label>
                <span>Name</span>
                <input
                  required
                  value={displayName}
                  onChange={(event) => setDisplayName(event.currentTarget.value)}
                />
              </label>
              <label>
                <span>API key</span>
                <input
                  required
                  type="password"
                  value={apiKey}
                  onChange={(event) => setApiKey(event.currentTarget.value)}
                />
              </label>
              <label>
                <span>Base URL</span>
                <input
                  value={baseUrl}
                  onChange={(event) => setBaseUrl(event.currentTarget.value)}
                />
              </label>
              <label>
                <span>Default model</span>
                <input
                  value={defaultModel}
                  onChange={(event) => setDefaultModel(event.currentTarget.value)}
                />
              </label>
              <div className="bento-router-admin__provider-actions">
                <button
                  className="bento-router-admin__button"
                  disabled={!onValidateProvider || !apiKey || isBusy}
                  onClick={validateCurrentProvider}
                  type="button"
                >
                  Test
                </button>
                <button className="bento-router-admin__button bento-router-admin__button--primary" disabled={isBusy} type="submit">
                  Add
                </button>
              </div>
              {validationResult ? (
                <p className="bento-router-admin__validation" data-ok={validationResult.ok}>
                  {validationResult.ok
                    ? "Provider validated."
                    : validationResult.error?.message ?? "Provider validation failed."}
                </p>
              ) : null}
            </form>
          ) : null}
        </section>
      ) : null}

      <div className="bento-router-admin__list">
        {tasks.map((task) => (
          <button
            className="bento-router-admin__task"
            key={task.id}
            onClick={() => onSelectTask?.(task.id)}
            type="button"
          >
            <strong>{task.name}</strong>
            <span>{task.id}</span>
          </button>
        ))}
      </div>

      {selectedTask ? (
        <article className="bento-router-admin__detail">
          <h2>{selectedTask.name}</h2>
          <dl>
            <dt>Task</dt>
            <dd>{selectedTask.id}</dd>
            <dt>App</dt>
            <dd>{selectedTask.appId}</dd>
            <dt>Primary model</dt>
            <dd>
              <select
                aria-label="Primary model"
                disabled={!onPolicyChange || models.length === 0}
                value={selectedPolicy?.primaryModel ?? ""}
                onChange={(event) =>
                  onPolicyChange?.(selectedTask.id, { primaryModel: event.currentTarget.value })
                }
              >
                <option value="">Unconfigured</option>
                {models.map((model) => (
                  <option key={model.id} value={model.id}>
                    {model.displayName ?? model.id}
                  </option>
                ))}
              </select>
            </dd>
            <dt>Fallbacks</dt>
            <dd>
              <input
                aria-label="Fallback models"
                disabled={!onPolicyChange}
                value={selectedPolicy?.fallbacks?.join(", ") ?? ""}
                onChange={(event) =>
                  onPolicyChange?.(selectedTask.id, {
                    fallbacks: event.currentTarget.value
                      .split(",")
                      .map((value) => value.trim())
                      .filter(Boolean),
                  })
                }
              />
            </dd>
            <dt>Max request cost</dt>
            <dd>
              <input
                aria-label="Max request cost"
                disabled={!onPolicyChange}
                min="0"
                step="0.001"
                type="number"
                value={selectedPolicy?.guardrails?.maxRequestCostUsd ?? ""}
                onChange={(event) =>
                  onPolicyChange?.(selectedTask.id, {
                    guardrails: {
                      ...selectedPolicy?.guardrails,
                      maxRequestCostUsd: numberOrUndefined(event.currentTarget.value),
                    },
                  })
                }
              />
            </dd>
            <dt>Timeout</dt>
            <dd>
              <input
                aria-label="Timeout"
                disabled={!onPolicyChange}
                min="0"
                step="1000"
                type="number"
                value={selectedPolicy?.guardrails?.timeoutMs ?? ""}
                onChange={(event) =>
                  onPolicyChange?.(selectedTask.id, {
                    guardrails: {
                      ...selectedPolicy?.guardrails,
                      timeoutMs: numberOrUndefined(event.currentTarget.value),
                    },
                  })
                }
              />
            </dd>
            <dt>Retries</dt>
            <dd>
              <input
                aria-label="Retries"
                disabled={!onPolicyChange}
                min="0"
                step="1"
                type="number"
                value={selectedPolicy?.guardrails?.maxRetries ?? ""}
                onChange={(event) =>
                  onPolicyChange?.(selectedTask.id, {
                    guardrails: {
                      ...selectedPolicy?.guardrails,
                      maxRetries: numberOrUndefined(event.currentTarget.value),
                    },
                  })
                }
              />
            </dd>
          </dl>
        </article>
      ) : null}
    </section>
  );
}

function numberOrUndefined(value: string): number | undefined {
  if (value === "") return undefined;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : undefined;
}

const adminStyles = `
.bento-router-admin {
  background: var(--bento-router-bg, transparent);
  color: var(--bento-router-fg, inherit);
  display: grid;
  gap: 16px;
  font-family: var(--bento-router-font-sans, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif);
}

.bento-router-admin *,
.bento-router-admin *::before,
.bento-router-admin *::after {
  box-sizing: border-box;
}

.bento-router-admin__section-header h2,
.bento-router-admin__detail h2 {
  font-size: 1rem;
  line-height: 1.3;
  margin: 0 0 12px;
}

.bento-router-admin__providers,
.bento-router-admin__detail {
  border: 1px solid var(--bento-router-border, #d7dee8);
  border-radius: var(--bento-router-radius, 8px);
  padding: 16px;
}

.bento-router-admin__provider-list,
.bento-router-admin__list {
  display: grid;
  gap: 8px;
}

.bento-router-admin__provider,
.bento-router-admin__task {
  align-items: center;
  background: transparent;
  border: 1px solid var(--bento-router-border, #d7dee8);
  border-radius: var(--bento-router-radius, 8px);
  color: var(--bento-router-fg, inherit);
  display: flex;
  gap: 12px;
  justify-content: space-between;
  min-height: 48px;
  padding: 10px 12px;
  text-align: left;
}

.bento-router-admin__task {
  cursor: pointer;
}

.bento-router-admin__provider strong,
.bento-router-admin__task strong {
  display: block;
}

.bento-router-admin__provider span,
.bento-router-admin__task span,
.bento-router-admin__empty {
  color: var(--bento-router-muted, #64748b);
  font-size: 0.875rem;
}

.bento-router-admin code {
  color: var(--bento-router-muted, #64748b);
  display: block;
  font-family: var(--bento-router-font-mono, ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace);
  font-size: 0.8125rem;
  margin-top: 2px;
}

.bento-router-admin__provider-form,
.bento-router-admin__detail dl {
  display: grid;
  gap: 12px;
  margin: 16px 0 0;
}

.bento-router-admin__provider-form label,
.bento-router-admin__detail dl {
  color: var(--bento-router-muted, #64748b);
  font-size: 0.875rem;
}

.bento-router-admin__provider-form label {
  display: grid;
  gap: 4px;
}

.bento-router-admin__detail dl {
  grid-template-columns: minmax(120px, 0.3fr) minmax(0, 1fr);
}

.bento-router-admin__detail dt {
  color: var(--bento-router-muted, #64748b);
}

.bento-router-admin__detail dd {
  margin: 0;
}

.bento-router-admin input,
.bento-router-admin select {
  background: var(--bento-router-bg, transparent);
  border: 1px solid var(--bento-router-border, #d7dee8);
  border-radius: var(--bento-router-radius, 8px);
  color: var(--bento-router-fg, inherit);
  font: inherit;
  min-height: 36px;
  padding: 6px 8px;
  width: 100%;
}

.bento-router-admin input:focus,
.bento-router-admin select:focus,
.bento-router-admin__button:focus,
.bento-router-admin__task:focus {
  outline: 2px solid var(--bento-router-accent, #2563eb);
  outline-offset: 2px;
}

.bento-router-admin__provider-actions {
  display: flex;
  gap: 8px;
  justify-content: flex-end;
}

.bento-router-admin__button {
  background: transparent;
  border: 1px solid var(--bento-router-border, #d7dee8);
  border-radius: var(--bento-router-radius, 8px);
  color: var(--bento-router-fg, inherit);
  cursor: pointer;
  font: inherit;
  min-height: 36px;
  padding: 6px 12px;
}

.bento-router-admin__button--primary {
  background: var(--bento-router-accent, #2563eb);
  border-color: var(--bento-router-accent, #2563eb);
  color: white;
}

.bento-router-admin__button:disabled,
.bento-router-admin input:disabled,
.bento-router-admin select:disabled {
  cursor: not-allowed;
  opacity: 0.6;
}

.bento-router-admin__validation {
  color: var(--bento-router-muted, #64748b);
  margin: 0;
}

.bento-router-admin__validation[data-ok="true"] {
  color: var(--bento-router-accent, #2563eb);
}

@media (min-width: 760px) {
  .bento-router-admin {
    grid-template-columns: minmax(220px, 0.35fr) minmax(0, 1fr);
  }

  .bento-router-admin__providers {
    grid-column: 1 / -1;
  }
}
`;
