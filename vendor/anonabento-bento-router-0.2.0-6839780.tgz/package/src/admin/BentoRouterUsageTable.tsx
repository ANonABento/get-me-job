import type { CSSProperties } from "react";
import type { UsageReportRow } from "../usage/usageReporting.js";

export type BentoRouterUsageTableProps = {
  rows: UsageReportRow[];
  style?: CSSProperties;
};

export function BentoRouterUsageTable({ rows, style }: BentoRouterUsageTableProps) {
  return (
    <section className="bento-router-usage" style={style}>
      <table>
        <thead>
          <tr>
            <th>Group</th>
            <th>Requests</th>
            <th>Success</th>
            <th>Failures</th>
            <th>Fallback</th>
            <th>Cost</th>
            <th>P95</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.key}>
              <th scope="row">{row.key}</th>
              <td>{row.requestCount}</td>
              <td>{row.successCount}</td>
              <td>{row.failureCount}</td>
              <td>{formatPercent(row.fallbackRate)}</td>
              <td>{formatUsd(row.actualCostUsd)}</td>
              <td>{row.latencyP95Ms}ms</td>
            </tr>
          ))}
        </tbody>
      </table>
    </section>
  );
}

function formatPercent(value: number): string {
  return `${Math.round(value * 100)}%`;
}

function formatUsd(value: number): string {
  return `$${value.toFixed(4)}`;
}
