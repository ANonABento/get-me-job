export type ProviderId = "openrouter" | "openai" | "anthropic" | "local" | string;

export type TaskId = string;

export type QualityTier = "cheap" | "standard" | "premium" | "emergency";

export type ChatRole = "system" | "user" | "assistant" | "tool";

export type ChatContentPart =
  | { type: "text"; text: string }
  | { type: "image_url"; image_url: { url: string; detail?: "low" | "high" | "auto" } };

export type ChatMessage = {
  role: ChatRole;
  content: string | ChatContentPart[];
};

export type ToolDefinition = {
  type: "function";
  function: {
    name: string;
    description?: string;
    parameters?: Record<string, unknown>;
  };
};

export type ToolCall = {
  id: string;
  type: "function";
  function: {
    name: string;
    arguments: string;
  };
};

export type ModelFeatureCaps = {
  json: boolean;
  vision: boolean;
  tools: boolean;
  streaming: boolean;
  embeddings?: boolean;
};

export type ModelProfile = {
  id: string;
  provider: ProviderId;
  displayName: string;
  inputCostPerMillionTokens: number;
  outputCostPerMillionTokens: number;
  maxContextTokens: number;
  qualityTier: QualityTier;
  caps: ModelFeatureCaps;
};

export type TaskDefinition = {
  id: TaskId;
  appId: string;
  name: string;
  category?: string;
  description?: string;
  prompt?: PromptMetadata;
  defaultPolicy: TaskPolicy;
};

export type PromptMetadata = {
  id: string;
  version: string;
};

export type DegradationMode =
  | "none"
  | "cheaper_model"
  | "short_response"
  | "cached_response"
  | "static_message";

export type DegradationPolicy = {
  mode: DegradationMode;
  message?: string;
};

export type CircuitBreakerPolicy = {
  failureThreshold: number;
  cooldownMs: number;
};

export type TaskGuardrails = {
  maxInputTokens?: number;
  maxOutputTokens?: number;
  timeoutMs?: number;
  maxRetries?: number;
  maxRequestCostUsd?: number;
};

export type BudgetPolicy = {
  dailyTaskBudgetUsd?: number;
  dailyAppBudgetUsd?: number;
  dailyUserBudgetUsd?: number;
  dailyOrgBudgetUsd?: number;
};

export type TaskPolicy = {
  primaryModel: string;
  fallbacks?: string[];
  modelRequirements?: ModelRequirements;
  routing?: RoutingPolicy;
  approval?: ApprovalPolicy;
  guardrails?: TaskGuardrails;
  budget?: BudgetPolicy;
  circuitBreaker?: CircuitBreakerPolicy;
  degradation?: DegradationPolicy;
};

export type ApprovalPolicy = {
  requireForQualityTiers?: QualityTier[];
  approved?: boolean;
};

export type ModelRequirements = {
  caps?: Partial<ModelFeatureCaps>;
  allowedQualityTiers?: QualityTier[];
  minContextTokens?: number;
};

export type RoutingPolicy = {
  canary?: {
    model: string;
    percentage: number;
  };
  weights?: Record<string, number>;
  rateLimit?: {
    maxRequests: number;
    windowMs: number;
  };
  maxConcurrentProviderRequests?: number;
};

export type PolicyOverrides = {
  global?: Partial<TaskPolicy>;
  app?: Record<string, Partial<TaskPolicy>>;
  task?: Record<TaskId, Partial<TaskPolicy>>;
};

export type BentoRouterInput = {
  task: TaskId;
  userId?: string;
  orgId?: string;
  projectId?: string;
  environment?: string;
  requestId?: string;
  messages: ChatMessage[];
  temperature?: number;
  metadata?: Record<string, unknown>;
};

export type ProviderRequest = {
  model: string;
  messages: ChatMessage[];
  temperature?: number;
  maxOutputTokens?: number;
  timeoutMs?: number;
  tools?: ToolDefinition[];
  toolChoice?: "auto" | "none" | { type: "function"; function: { name: string } };
};

export type ProviderResponse = {
  text: string;
  inputTokens?: number;
  outputTokens?: number;
  toolCalls?: ToolCall[];
  raw?: unknown;
};

export type ProviderStreamChunk = {
  text?: string;
  toolCall?: ToolCall;
  raw?: unknown;
};

export type EmbeddingRequest = {
  model: string;
  input: string | string[];
  timeoutMs?: number;
};

export type EmbeddingResponse = {
  embeddings: number[][];
  inputTokens?: number;
  raw?: unknown;
};

export type ProviderAdapter = {
  id: ProviderId;
  complete(request: ProviderRequest): Promise<ProviderResponse>;
  stream?(request: ProviderRequest): AsyncIterable<ProviderStreamChunk>;
  embed?(request: EmbeddingRequest): Promise<EmbeddingResponse>;
  countTokens?(messages: ChatMessage[], model?: string): Promise<number> | number;
};

export type RouterStatus =
  | "success"
  | "degraded"
  | "blocked"
  | "failed";

export type BentoRouterResult = {
  status: RouterStatus;
  taskId: TaskId;
  model?: string;
  provider?: ProviderId;
  text: string;
  attempts: UsageEvent[];
  degraded: boolean;
  reason?: string;
};

export type BentoRouterEmbeddingInput = {
  task: TaskId;
  userId?: string;
  orgId?: string;
  projectId?: string;
  environment?: string;
  requestId?: string;
  input: string | string[];
  model?: string;
};

export type BentoRouterEmbeddingResult = {
  status: RouterStatus;
  taskId: TaskId;
  model?: string;
  provider?: ProviderId;
  embeddings: number[][];
  degraded: boolean;
  reason?: string;
  attempts: UsageEvent[];
};

export type UsageStatus =
  | "success"
  | "failure"
  | "blocked"
  | "skipped"
  | "degraded";

export type UsageEvent = {
  id: string;
  timestamp: string;
  appId: string;
  taskId: TaskId;
  userId?: string;
  orgId?: string;
  projectId?: string;
  environment?: string;
  requestId: string;
  provider?: ProviderId;
  model?: string;
  status: UsageStatus;
  fallbackIndex: number;
  inputTokensEstimated: number;
  inputTokensActual?: number;
  outputTokensActual?: number;
  estimatedCostUsd: number;
  actualCostUsd?: number;
  latencyMs: number;
  errorCode?: string;
  errorMessage?: string;
  degradationUsed?: DegradationMode;
  promptId?: string;
  promptVersion?: string;
};

export type UsageQuery = {
  appId?: string;
  taskId?: TaskId;
  userId?: string;
  orgId?: string;
  projectId?: string;
  environment?: string;
  since?: Date;
  until?: Date;
};

export type UsageSummary = {
  requestCount: number;
  successCount: number;
  failureCount: number;
  blockedCount: number;
  estimatedCostUsd: number;
  actualCostUsd: number;
};
