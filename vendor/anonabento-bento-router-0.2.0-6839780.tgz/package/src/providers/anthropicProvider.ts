import type { ProviderAdapter, ProviderRequest, ProviderResponse } from "../types.js";

export type AnthropicProviderOptions = {
  apiKey: string;
  id?: string;
  baseUrl?: string;
  fetchImpl?: typeof fetch;
  version?: string;
};

export function createAnthropicProvider(options: AnthropicProviderOptions): ProviderAdapter {
  const fetchImpl = options.fetchImpl ?? fetch;
  const baseUrl = options.baseUrl ?? "https://api.anthropic.com/v1";
  const version = options.version ?? "2023-06-01";

  return {
    id: options.id ?? "anthropic",
    async complete(request: ProviderRequest): Promise<ProviderResponse> {
      const controller = new AbortController();
      const timeout = request.timeoutMs
        ? setTimeout(() => controller.abort(), request.timeoutMs)
        : undefined;
      const system = request.messages.find((message) => message.role === "system")?.content;
      const messages = request.messages
        .filter((message) => message.role !== "system")
        .map((message) => ({ role: message.role, content: message.content }));

      try {
        const response = await fetchImpl(`${baseUrl}/messages`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "x-api-key": options.apiKey,
            "anthropic-version": version,
          },
          body: JSON.stringify({
            model: stripProviderPrefix(request.model, "anthropic"),
            max_tokens: request.maxOutputTokens,
            temperature: request.temperature,
            system,
            messages,
          }),
          signal: controller.signal,
        });

        if (!response.ok) {
          const message = await response.text();
          throw new Error(`Anthropic request failed (${response.status}): ${message}`);
        }

        const data = (await response.json()) as {
          content?: Array<{ text?: string }>;
          usage?: { input_tokens?: number; output_tokens?: number };
        };

        return {
          text: data.content?.[0]?.text ?? "",
          inputTokens: data.usage?.input_tokens,
          outputTokens: data.usage?.output_tokens,
          raw: data,
        };
      } finally {
        if (timeout) clearTimeout(timeout);
      }
    },
  };
}

function stripProviderPrefix(model: string, provider: string): string {
  const prefix = `${provider}/`;
  return model.startsWith(prefix) ? model.slice(prefix.length) : model;
}
