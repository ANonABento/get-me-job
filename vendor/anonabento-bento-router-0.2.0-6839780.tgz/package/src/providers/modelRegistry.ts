import type { ModelProfile } from "../types.js";

export class ModelRegistry {
  private readonly models = new Map<string, ModelProfile>();

  register(model: ModelProfile): ModelProfile {
    this.models.set(model.id, model);
    return model;
  }

  get(modelId: string): ModelProfile | undefined {
    return this.models.get(modelId);
  }

  require(modelId: string): ModelProfile {
    const model = this.get(modelId);
    if (!model) {
      throw new Error(`Unknown AI model: ${modelId}`);
    }
    return model;
  }

  list(): ModelProfile[] {
    return [...this.models.values()];
  }
}

export function createDefaultModelRegistry(): ModelRegistry {
  const registry = new ModelRegistry();

  registry.register({
    id: "openrouter/openai/gpt-4.1-mini",
    provider: "openrouter",
    displayName: "OpenAI GPT-4.1 Mini via OpenRouter",
    inputCostPerMillionTokens: 0.4,
    outputCostPerMillionTokens: 1.6,
    maxContextTokens: 128000,
    qualityTier: "standard",
    caps: { json: true, vision: true, tools: true, streaming: true },
  });

  registry.register({
    id: "openrouter/google/gemini-flash",
    provider: "openrouter",
    displayName: "Google Gemini Flash via OpenRouter",
    inputCostPerMillionTokens: 0.1,
    outputCostPerMillionTokens: 0.4,
    maxContextTokens: 1000000,
    qualityTier: "cheap",
    caps: { json: true, vision: true, tools: true, streaming: true },
  });

  registry.register({
    id: "openrouter/anthropic/claude-3.5-sonnet",
    provider: "openrouter",
    displayName: "Claude 3.5 Sonnet via OpenRouter",
    inputCostPerMillionTokens: 3,
    outputCostPerMillionTokens: 15,
    maxContextTokens: 200000,
    qualityTier: "premium",
    caps: { json: true, vision: true, tools: true, streaming: true },
  });

  registry.register({
    id: "openai/gpt-4.1-mini",
    provider: "openai",
    displayName: "OpenAI GPT-4.1 Mini",
    inputCostPerMillionTokens: 0.4,
    outputCostPerMillionTokens: 1.6,
    maxContextTokens: 128000,
    qualityTier: "standard",
    caps: { json: true, vision: true, tools: true, streaming: true },
  });

  registry.register({
    id: "anthropic/claude-3.5-sonnet",
    provider: "anthropic",
    displayName: "Claude 3.5 Sonnet",
    inputCostPerMillionTokens: 3,
    outputCostPerMillionTokens: 15,
    maxContextTokens: 200000,
    qualityTier: "premium",
    caps: { json: true, vision: true, tools: true, streaming: true },
  });

  return registry;
}
