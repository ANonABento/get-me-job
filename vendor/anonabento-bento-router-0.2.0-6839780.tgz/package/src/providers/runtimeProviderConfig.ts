import type { ProviderAdapter } from "../types.js";
import { createAnthropicProvider } from "./anthropicProvider.js";
import { createOpenAICompatibleProvider } from "./openAICompatibleProvider.js";
import { createOpenAIProvider } from "./openaiProvider.js";
import { createOpenRouterProvider } from "./openrouterProvider.js";
import type { ProviderConfig } from "./providerConfigStore.js";

export type EncryptionAdapter = {
  encrypt(plaintext: string): Promise<string>;
  decrypt(stored: string): Promise<string>;
  scheme: string;
};

export async function decryptProviderApiKey(
  config: ProviderConfig,
  encryption?: EncryptionAdapter,
): Promise<string> {
  if (!encryption) return config.encryptedApiKey;
  return encryption.decrypt(config.encryptedApiKey);
}

export async function createProviderAdapterFromConfig(
  config: ProviderConfig,
  options: {
    encryption?: EncryptionAdapter;
    fetchImpl?: typeof fetch;
    registerTypeAlias?: boolean;
  } = {},
): Promise<ProviderAdapter[]> {
  const apiKey = await decryptProviderApiKey(config, options.encryption);
  const adapters = [providerAdapter(config, apiKey, options.fetchImpl)];

  if (options.registerTypeAlias && config.id !== config.type) {
    adapters.push(providerAdapter({ ...config, id: config.type }, apiKey, options.fetchImpl));
  }

  return adapters;
}

function providerAdapter(
  config: ProviderConfig,
  apiKey: string,
  fetchImpl?: typeof fetch,
): ProviderAdapter {
  switch (config.type) {
    case "openai":
      return createOpenAIProvider({ id: config.id, apiKey, fetchImpl });
    case "anthropic":
      return createAnthropicProvider({ id: config.id, apiKey, fetchImpl });
    case "openrouter":
      return createOpenRouterProvider({ id: config.id, apiKey, fetchImpl });
    case "openai-compatible":
      if (!config.baseUrl) throw new Error("openai-compatible providers require baseUrl");
      return createOpenAICompatibleProvider({
        id: config.id,
        apiKey,
        baseUrl: config.baseUrl,
        modelPrefix: config.id,
        fetchImpl,
      });
  }
}
