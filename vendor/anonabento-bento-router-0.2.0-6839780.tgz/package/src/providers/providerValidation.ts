import type { ProviderConfigType } from "./providerConfigStore.js";

export type ValidateProviderInput = {
  type: ProviderConfigType;
  apiKey: string;
  baseUrl?: string;
};

export type ValidateProviderResult = {
  ok: boolean;
  latencyMs?: number;
  modelsAvailable?: string[];
  error?: { code: string; message: string };
};

export async function validateProvider(
  input: ValidateProviderInput,
  options: {
    fetchImpl?: typeof fetch;
    timeoutMs?: number;
  } = {},
): Promise<ValidateProviderResult> {
  const fetchImpl = options.fetchImpl ?? fetch;
  const timeoutMs = options.timeoutMs ?? 5000;
  const startedAt = Date.now();

  try {
    const result = await validateProviderWithFetch(input, fetchImpl, timeoutMs);
    return { ...result, latencyMs: Date.now() - startedAt };
  } catch (error) {
    return {
      ok: false,
      latencyMs: Date.now() - startedAt,
      error: providerValidationError(error),
    };
  }
}

async function validateProviderWithFetch(
  input: ValidateProviderInput,
  fetchImpl: typeof fetch,
  timeoutMs: number,
): Promise<ValidateProviderResult> {
  switch (input.type) {
    case "openai":
      return validateModelsEndpoint(fetchImpl, "https://api.openai.com/v1/models", {
        Authorization: `Bearer ${input.apiKey}`,
      }, timeoutMs);
    case "anthropic":
      return validateModelsEndpoint(fetchImpl, "https://api.anthropic.com/v1/models", {
        "x-api-key": input.apiKey,
        "anthropic-version": "2023-06-01",
      }, timeoutMs);
    case "openrouter":
      return validateModelsEndpoint(fetchImpl, "https://openrouter.ai/api/v1/models", {
        Authorization: `Bearer ${input.apiKey}`,
      }, timeoutMs);
    case "openai-compatible":
      if (!input.baseUrl) {
        return {
          ok: false,
          error: { code: "missing_base_url", message: "openai-compatible validation requires baseUrl" },
        };
      }
      return validateOpenAICompatible(fetchImpl, input, timeoutMs);
  }
}

async function validateOpenAICompatible(
  fetchImpl: typeof fetch,
  input: ValidateProviderInput,
  timeoutMs: number,
): Promise<ValidateProviderResult> {
  const baseUrl = input.baseUrl!.replace(/\/$/, "");
  const modelsResponse = await fetchWithTimeout(fetchImpl, `${baseUrl}/models`, {
    method: "GET",
    headers: {
      ...(input.apiKey ? { Authorization: `Bearer ${input.apiKey}` } : {}),
    },
  }, timeoutMs);

  if (modelsResponse.ok) {
    return {
      ok: true,
      modelsAvailable: modelIds(await modelsResponse.json()),
    };
  }

  if (modelsResponse.status !== 404) {
    return failureFromResponse("provider_validation_failed", modelsResponse);
  }

  const completionResponse = await fetchWithTimeout(fetchImpl, `${baseUrl}/chat/completions`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(input.apiKey ? { Authorization: `Bearer ${input.apiKey}` } : {}),
    },
    body: JSON.stringify({
      model: "default",
      messages: [{ role: "user", content: "ping" }],
      max_tokens: 1,
    }),
  }, timeoutMs);

  if (!completionResponse.ok) {
    return failureFromResponse("provider_validation_failed", completionResponse);
  }

  return { ok: true };
}

async function validateModelsEndpoint(
  fetchImpl: typeof fetch,
  url: string,
  headers: Record<string, string>,
  timeoutMs: number,
): Promise<ValidateProviderResult> {
  const response = await fetchWithTimeout(fetchImpl, url, { method: "GET", headers }, timeoutMs);
  if (!response.ok) return failureFromResponse("provider_validation_failed", response);
  return {
    ok: true,
    modelsAvailable: modelIds(await response.json()),
  };
}

async function fetchWithTimeout(
  fetchImpl: typeof fetch,
  input: string,
  init: RequestInit,
  timeoutMs: number,
): Promise<Response> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetchImpl(input, { ...init, signal: controller.signal });
  } finally {
    clearTimeout(timeout);
  }
}

async function failureFromResponse(code: string, response: Response): Promise<ValidateProviderResult> {
  const message = await response.text();
  return {
    ok: false,
    error: {
      code,
      message: message || `Provider validation failed with HTTP ${response.status}`,
    },
  };
}

function modelIds(value: unknown): string[] {
  if (typeof value !== "object" || value === null || !Array.isArray((value as { data?: unknown }).data)) {
    return [];
  }
  return (value as { data: Array<{ id?: unknown }> }).data
    .map((model) => model.id)
    .filter((id): id is string => typeof id === "string");
}

function providerValidationError(error: unknown): { code: string; message: string } {
  if (error instanceof DOMException && error.name === "AbortError") {
    return { code: "provider_validation_timeout", message: "Provider validation timed out" };
  }
  if (error instanceof Error) {
    return { code: "provider_validation_error", message: error.message };
  }
  return { code: "provider_validation_error", message: String(error) };
}
