import type { ProviderAdapter, ProviderId } from "../types.js";

export class ProviderRegistry {
  private readonly providers = new Map<ProviderId, ProviderAdapter>();

  register(provider: ProviderAdapter): ProviderAdapter {
    this.providers.set(provider.id, provider);
    return provider;
  }

  get(providerId: ProviderId): ProviderAdapter | undefined {
    return this.providers.get(providerId);
  }

  unregister(providerId: ProviderId): boolean {
    return this.providers.delete(providerId);
  }

  require(providerId: ProviderId): ProviderAdapter {
    const provider = this.get(providerId);
    if (!provider) {
      throw new Error(`Unknown AI provider: ${providerId}`);
    }
    return provider;
  }

  list(): ProviderAdapter[] {
    return [...this.providers.values()];
  }
}
