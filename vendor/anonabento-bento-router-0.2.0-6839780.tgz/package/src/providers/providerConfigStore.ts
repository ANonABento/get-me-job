import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { dirname } from "node:path";

export type ProviderConfigType = "openai" | "anthropic" | "openrouter" | "openai-compatible";

export type ProviderConfig = {
  id: string;
  type: ProviderConfigType;
  displayName: string;
  encryptedApiKey: string;
  encryptionScheme: string;
  baseUrl?: string;
  defaultModel?: string;
  createdAt: string;
  userId: string;
  metadata?: Record<string, unknown>;
};

export type ProviderConfigPatch = {
  displayName?: string;
  apiKey?: string;
  baseUrl?: string;
  defaultModel?: string;
  metadata?: Record<string, unknown>;
};

export type ProviderConfigStore = {
  list(userId: string): Promise<ProviderConfig[]>;
  get(userId: string, id: string): Promise<ProviderConfig | null>;
  upsert(config: ProviderConfig): Promise<ProviderConfig>;
  delete(userId: string, id: string): Promise<void>;
  listAll(): Promise<ProviderConfig[]>;
};

type JsonProviderConfigFile = {
  version: 1;
  configs: ProviderConfig[];
  writtenAt: string;
};

export class MemoryProviderConfigStore implements ProviderConfigStore {
  private readonly configs = new Map<string, ProviderConfig>();

  constructor(configs: ProviderConfig[] = []) {
    for (const config of configs) {
      this.configs.set(configKey(config.userId, config.id), cloneProviderConfig(config));
    }
  }

  async list(userId: string): Promise<ProviderConfig[]> {
    return [...this.configs.values()]
      .filter((config) => config.userId === userId)
      .map(cloneProviderConfig);
  }

  async get(userId: string, id: string): Promise<ProviderConfig | null> {
    const config = this.configs.get(configKey(userId, id));
    return config ? cloneProviderConfig(config) : null;
  }

  async upsert(config: ProviderConfig): Promise<ProviderConfig> {
    const cloned = cloneProviderConfig(config);
    this.configs.set(configKey(cloned.userId, cloned.id), cloned);
    return cloneProviderConfig(cloned);
  }

  async delete(userId: string, id: string): Promise<void> {
    this.configs.delete(configKey(userId, id));
  }

  async listAll(): Promise<ProviderConfig[]> {
    return [...this.configs.values()].map(cloneProviderConfig);
  }
}

export class JsonFileProviderConfigStore implements ProviderConfigStore {
  private writeQueue: Promise<void> = Promise.resolve();

  constructor(private readonly filePath: string) {}

  async list(userId: string): Promise<ProviderConfig[]> {
    return (await this.readConfigs())
      .filter((config) => config.userId === userId)
      .map(cloneProviderConfig);
  }

  async get(userId: string, id: string): Promise<ProviderConfig | null> {
    const config = (await this.readConfigs()).find(
      (candidate) => candidate.userId === userId && candidate.id === id,
    );
    return config ? cloneProviderConfig(config) : null;
  }

  async upsert(config: ProviderConfig): Promise<ProviderConfig> {
    const cloned = cloneProviderConfig(config);
    await this.enqueueWrite(async () => {
      const configs = await this.readConfigs();
      const index = configs.findIndex(
        (candidate) => candidate.userId === cloned.userId && candidate.id === cloned.id,
      );
      if (index === -1) configs.push(cloned);
      else configs[index] = cloned;
      await this.writeConfigs(configs);
    });
    return cloneProviderConfig(cloned);
  }

  async delete(userId: string, id: string): Promise<void> {
    await this.enqueueWrite(async () => {
      const configs = (await this.readConfigs()).filter(
        (config) => config.userId !== userId || config.id !== id,
      );
      await this.writeConfigs(configs);
    });
  }

  async listAll(): Promise<ProviderConfig[]> {
    return (await this.readConfigs()).map(cloneProviderConfig);
  }

  private async enqueueWrite(write: () => Promise<void>): Promise<void> {
    const next = this.writeQueue.then(write, write);
    this.writeQueue = next.then(
      () => undefined,
      () => undefined,
    );
    await next;
  }

  private async readConfigs(): Promise<ProviderConfig[]> {
    try {
      const content = await readFile(this.filePath, "utf8");
      const parsed = JSON.parse(content) as Partial<JsonProviderConfigFile>;
      if (parsed.version !== 1 || !Array.isArray(parsed.configs)) return [];
      return parsed.configs.filter(isProviderConfig).map(cloneProviderConfig);
    } catch (error) {
      if (isNotFound(error)) return [];
      throw error;
    }
  }

  private async writeConfigs(configs: ProviderConfig[]): Promise<void> {
    await mkdir(dirname(this.filePath), { recursive: true });
    const tmpPath = `${this.filePath}.${process.pid}.tmp`;
    const payload: JsonProviderConfigFile = {
      version: 1,
      configs: configs.map(cloneProviderConfig),
      writtenAt: new Date().toISOString(),
    };
    await writeFile(tmpPath, `${JSON.stringify(payload, null, 2)}\n`, "utf8");
    await rename(tmpPath, this.filePath);
  }
}

export function cloneProviderConfig(config: ProviderConfig): ProviderConfig {
  return {
    ...config,
    metadata: config.metadata ? { ...config.metadata } : undefined,
  };
}

function configKey(userId: string, id: string): string {
  return `${userId}:${id}`;
}

function isProviderConfig(value: unknown): value is ProviderConfig {
  if (typeof value !== "object" || value === null) return false;
  const config = value as ProviderConfig;
  return (
    typeof config.id === "string" &&
    isProviderConfigType(config.type) &&
    typeof config.displayName === "string" &&
    typeof config.encryptedApiKey === "string" &&
    typeof config.encryptionScheme === "string" &&
    typeof config.createdAt === "string" &&
    typeof config.userId === "string"
  );
}

function isProviderConfigType(value: unknown): value is ProviderConfigType {
  return (
    value === "openai" ||
    value === "anthropic" ||
    value === "openrouter" ||
    value === "openai-compatible"
  );
}

function isNotFound(error: unknown): boolean {
  return typeof error === "object" && error !== null && "code" in error && error.code === "ENOENT";
}
