import type { ProviderAdapter, ProviderRequest, ProviderResponse } from "../types.js";

export type OpenAICompatibleProviderOptions = {
  id: string;
  apiKey?: string;
  baseUrl: string;
  modelPrefix?: string;
  fetchImpl?: typeof fetch;
  headers?: Record<string, string>;
};

export function createOpenAICompatibleProvider(
  options: OpenAICompatibleProviderOptions,
): ProviderAdapter {
  const fetchImpl = options.fetchImpl ?? fetch;
  const baseUrl = options.baseUrl.replace(/\/$/, "");

  return {
    id: options.id,
    async complete(request: ProviderRequest): Promise<ProviderResponse> {
      const controller = new AbortController();
      const timeout = request.timeoutMs
        ? setTimeout(() => controller.abort(), request.timeoutMs)
        : undefined;

      try {
        const response = await fetchImpl(`${baseUrl}/chat/completions`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            ...(options.apiKey ? { Authorization: `Bearer ${options.apiKey}` } : {}),
            ...options.headers,
          },
          body: JSON.stringify({
            model: stripProviderPrefix(request.model, options.modelPrefix ?? options.id),
            messages: request.messages,
            temperature: request.temperature,
            max_tokens: request.maxOutputTokens,
            tools: request.tools,
            tool_choice: request.toolChoice,
          }),
          signal: controller.signal,
        });

        if (!response.ok) {
          const message = await response.text();
          throw new Error(`${options.id} request failed (${response.status}): ${message}`);
        }

        const data = (await response.json()) as {
          choices?: Array<{ message?: { content?: string; tool_calls?: ProviderResponse["toolCalls"] } }>;
          usage?: { prompt_tokens?: number; completion_tokens?: number };
        };

        return {
          text: data.choices?.[0]?.message?.content ?? "",
          inputTokens: data.usage?.prompt_tokens,
          outputTokens: data.usage?.completion_tokens,
          toolCalls: data.choices?.[0]?.message?.tool_calls,
          raw: data,
        };
      } finally {
        if (timeout) clearTimeout(timeout);
      }
    },
  };
}

function stripProviderPrefix(model: string, provider: string): string {
  const prefix = `${provider}/`;
  return model.startsWith(prefix) ? model.slice(prefix.length) : model;
}
