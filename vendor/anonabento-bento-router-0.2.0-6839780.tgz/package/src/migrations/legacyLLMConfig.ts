import type { AddProviderInput } from "../server/createBentoRouterApi.js";

export type LegacyLLMConfig = {
  provider: "openai" | "anthropic" | "ollama" | "openrouter";
  apiKey?: string;
  baseUrl?: string;
  model: string;
};

export type MigrationOutput = {
  provider?: AddProviderInput;
  taskPolicies: Record<
    string,
    {
      primaryModel: string;
    }
  >;
};

export function migrateLegacyLLMConfig(
  legacy: LegacyLLMConfig,
  options: { userId: string; taskIds: string[]; displayName?: string },
): MigrationOutput {
  if (!options.userId.trim()) throw new Error("userId is required");
  const primaryModel = migratedModelId(legacy);
  const taskPolicies = Object.fromEntries(
    options.taskIds.map((taskId) => [taskId, { primaryModel }]),
  );

  if (!legacy.apiKey) {
    return { taskPolicies };
  }

  return {
    provider: {
      type: providerType(legacy),
      displayName: options.displayName ?? defaultDisplayName(legacy.provider),
      apiKey: legacy.apiKey,
      baseUrl: legacy.provider === "ollama" ? legacy.baseUrl ?? "http://localhost:11434" : legacy.baseUrl,
      defaultModel: primaryModel,
      userId: options.userId,
    },
    taskPolicies,
  };
}

function migratedModelId(legacy: LegacyLLMConfig): string {
  switch (legacy.provider) {
    case "openai":
      return `openai/${legacy.model}`;
    case "anthropic":
      return `anthropic/${legacy.model}`;
    case "openrouter":
      return legacy.model;
    case "ollama":
      return `local/${legacy.model}`;
  }
}

function providerType(legacy: LegacyLLMConfig): AddProviderInput["type"] {
  switch (legacy.provider) {
    case "openai":
      return "openai";
    case "anthropic":
      return "anthropic";
    case "openrouter":
      return "openrouter";
    case "ollama":
      return "openai-compatible";
  }
}

function defaultDisplayName(provider: LegacyLLMConfig["provider"]): string {
  switch (provider) {
    case "openai":
      return "OpenAI";
    case "anthropic":
      return "Anthropic";
    case "openrouter":
      return "OpenRouter";
    case "ollama":
      return "Ollama";
  }
}
