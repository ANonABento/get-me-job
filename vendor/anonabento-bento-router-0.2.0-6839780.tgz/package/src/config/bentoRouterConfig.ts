import { BentoRouter } from "../runtime/bentoRouter.js";
import { CircuitBreaker } from "../runtime/circuitBreaker.js";
import { JsonFilePolicyStore } from "../policies/jsonFilePolicyStore.js";
import { MemoryPolicyStore } from "../policies/memoryPolicyStore.js";
import type { PolicyStore } from "../policies/policyStore.js";
import { createAnthropicProvider } from "../providers/anthropicProvider.js";
import { ModelRegistry, createDefaultModelRegistry } from "../providers/modelRegistry.js";
import { createOpenAIProvider } from "../providers/openaiProvider.js";
import { createOpenAICompatibleProvider } from "../providers/openAICompatibleProvider.js";
import { createOpenRouterProvider } from "../providers/openrouterProvider.js";
import {
  JsonFileProviderConfigStore,
  MemoryProviderConfigStore,
  type ProviderConfigStore,
} from "../providers/providerConfigStore.js";
import { ProviderRegistry } from "../providers/providerRegistry.js";
import type { EncryptionAdapter } from "../providers/runtimeProviderConfig.js";
import { createBentoRouterApi, type BentoRouterApi } from "../server/createBentoRouterApi.js";
import {
  createBentoRouterHttpHandler,
  type BentoRouterHttpHandler,
} from "../server/createBentoRouterHttpHandler.js";
import { createBentoRouterService, type BentoRouterService } from "../server/createBentoRouterService.js";
import { defineBentoTask } from "../tasks/defineBentoTask.js";
import { TaskRegistry } from "../tasks/taskRegistry.js";
import type { ModelProfile, ProviderAdapter, ProviderId, TaskDefinition } from "../types.js";
import { JsonFileUsageStore } from "../usage/jsonFileUsageStore.js";
import { MemoryUsageStore } from "../usage/memoryUsageStore.js";
import type { UsageStore } from "../usage/usageStore.js";

export type BentoRouterProviderConfig = {
  id: ProviderId;
  type: "openrouter" | "openai" | "anthropic" | "openai-compatible";
  apiKeyEnv?: string;
  baseUrl?: string;
  modelPrefix?: string;
};

export type BentoRouterConfig = {
  providers?: BentoRouterProviderConfig[];
  models?: ModelProfile[];
  tasks?: TaskDefinition[];
  usage?: {
    type: "memory" | "json";
    filePath?: string;
  };
  policies?: {
    type: "memory" | "json";
    filePath?: string;
  };
  providerConfigs?: {
    type: "memory" | "json";
    filePath?: string;
  };
  encryption?: EncryptionAdapter;
  service?: {
    host?: string;
    port?: number;
    basePath?: string;
  };
};

export type BentoRouterRuntime = {
  router: BentoRouter;
  api: BentoRouterApi;
  handler: BentoRouterHttpHandler;
  service: BentoRouterService;
  taskRegistry: TaskRegistry;
  modelRegistry: ModelRegistry;
  providerRegistry: ProviderRegistry;
  usageStore: UsageStore;
  policyStore: PolicyStore;
  providerConfigStore?: ProviderConfigStore;
  circuitBreaker: CircuitBreaker;
};

export function createBentoRouterRuntimeFromConfig(
  config: BentoRouterConfig,
  env: Record<string, string | undefined> = process.env,
): BentoRouterRuntime {
  const taskRegistry = new TaskRegistry();
  for (const task of config.tasks ?? []) {
    defineBentoTask(task, taskRegistry);
  }

  const modelRegistry = createDefaultModelRegistry();
  for (const model of config.models ?? []) {
    modelRegistry.register(model);
  }

  const providerRegistry = new ProviderRegistry();
  for (const provider of config.providers ?? []) {
    providerRegistry.register(providerFromConfig(provider, env));
  }

  const usageStore = usageStoreFromConfig(config.usage);
  const policyStore = policyStoreFromConfig(config.policies);
  const providerConfigStore = providerConfigStoreFromConfig(config.providerConfigs);
  const circuitBreaker = new CircuitBreaker();
  const router = new BentoRouter({
    taskRegistry,
    modelRegistry,
    providerRegistry,
    usageStore,
    policyStore,
    providerConfigStore,
    encryption: config.encryption,
    circuitBreaker,
  });
  const api = createBentoRouterApi({
    router,
    taskRegistry,
    modelRegistry,
    providerRegistry,
    usageStore,
    policyStore,
    providerConfigStore,
    encryption: config.encryption,
    circuitBreaker,
  });
  const handler = createBentoRouterHttpHandler({
    api,
    basePath: config.service?.basePath,
  });
  const service = createBentoRouterService({
    handler,
    host: config.service?.host,
    port: config.service?.port,
  });

  return {
    router,
    api,
    handler,
    service,
    taskRegistry,
    modelRegistry,
    providerRegistry,
    usageStore,
    policyStore,
    providerConfigStore,
    circuitBreaker,
  };
}

function providerFromConfig(
  config: BentoRouterProviderConfig,
  env: Record<string, string | undefined>,
): ProviderAdapter {
  const apiKey = env[config.apiKeyEnv ?? defaultApiKeyEnv(config.type)] ?? "";
  switch (config.type) {
    case "openrouter":
      return createOpenRouterProvider({ apiKey });
    case "openai":
      return createOpenAIProvider({ apiKey });
    case "anthropic":
      return createAnthropicProvider({ apiKey });
    case "openai-compatible":
      if (!config.baseUrl) throw new Error("openai-compatible providers require baseUrl");
      return createOpenAICompatibleProvider({
        id: config.id,
        apiKey,
        baseUrl: config.baseUrl,
        modelPrefix: config.modelPrefix,
      });
  }
}

function usageStoreFromConfig(config: BentoRouterConfig["usage"]): UsageStore {
  if (config?.type === "json") {
    return new JsonFileUsageStore(config.filePath ?? ".bento-router/usage.json");
  }
  return new MemoryUsageStore();
}

function policyStoreFromConfig(config: BentoRouterConfig["policies"]): PolicyStore {
  if (config?.type === "json") {
    return new JsonFilePolicyStore(config.filePath ?? ".bento-router/policies.json");
  }
  return new MemoryPolicyStore();
}

function providerConfigStoreFromConfig(
  config: BentoRouterConfig["providerConfigs"],
): ProviderConfigStore | undefined {
  if (config?.type === "json") {
    return new JsonFileProviderConfigStore(config.filePath ?? ".bento-router/providers.json");
  }
  if (config?.type === "memory") return new MemoryProviderConfigStore();
  return undefined;
}

function defaultApiKeyEnv(type: BentoRouterProviderConfig["type"]): string {
  switch (type) {
    case "openrouter":
      return "OPENROUTER_API_KEY";
    case "openai":
      return "OPENAI_API_KEY";
    case "anthropic":
      return "ANTHROPIC_API_KEY";
    case "openai-compatible":
      return "OPENAI_COMPATIBLE_API_KEY";
  }
}
