export type BentoRouterEnvConfig = {
  enabled: boolean;
  defaultProvider: string;
  usageStore: "memory" | "sqlite" | "postgres";
  usageDatabaseUrl?: string;
  policyStore: "memory" | "json";
  policyFilePath?: string;
  openRouterApiKey?: string;
  openAiApiKey?: string;
  anthropicApiKey?: string;
  defaultMaxRequestCostUsd: number;
  defaultDailyAppBudgetUsd: number;
  defaultTimeoutMs: number;
  defaultMaxRetries: number;
};

export function readBentoRouterEnv(env: Record<string, string | undefined> = process.env): BentoRouterEnvConfig {
  return {
    enabled: parseBoolean(env.BENTO_ROUTER_ENABLED, true),
    defaultProvider: env.BENTO_ROUTER_DEFAULT_PROVIDER ?? "openrouter",
    usageStore: parseUsageStore(env.BENTO_ROUTER_USAGE_STORE),
    usageDatabaseUrl: env.BENTO_ROUTER_USAGE_DATABASE_URL,
    policyStore: parsePolicyStore(env.BENTO_ROUTER_POLICY_STORE),
    policyFilePath: env.BENTO_ROUTER_POLICY_FILE,
    openRouterApiKey: env.OPENROUTER_API_KEY,
    openAiApiKey: env.OPENAI_API_KEY,
    anthropicApiKey: env.ANTHROPIC_API_KEY,
    defaultMaxRequestCostUsd: parseNumber(env.BENTO_ROUTER_DEFAULT_MAX_REQUEST_COST_USD, 0.02),
    defaultDailyAppBudgetUsd: parseNumber(env.BENTO_ROUTER_DEFAULT_DAILY_APP_BUDGET_USD, 10),
    defaultTimeoutMs: parseNumber(env.BENTO_ROUTER_DEFAULT_TIMEOUT_MS, 15000),
    defaultMaxRetries: parseNumber(env.BENTO_ROUTER_DEFAULT_MAX_RETRIES, 1),
  };
}

function parseBoolean(value: string | undefined, fallback: boolean): boolean {
  if (value === undefined) return fallback;
  return ["1", "true", "yes", "on"].includes(value.toLowerCase());
}

function parseNumber(value: string | undefined, fallback: number): number {
  if (value === undefined) return fallback;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function parseUsageStore(value: string | undefined): BentoRouterEnvConfig["usageStore"] {
  if (value === "sqlite" || value === "postgres") return value;
  return "memory";
}

function parsePolicyStore(value: string | undefined): BentoRouterEnvConfig["policyStore"] {
  if (value === "json") return value;
  return "memory";
}
