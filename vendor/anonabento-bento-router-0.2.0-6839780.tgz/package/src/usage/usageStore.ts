import type { UsageEvent, UsageQuery, UsageSummary } from "../types.js";

export interface UsageStore {
  record(event: UsageEvent): Promise<void>;
  list(query?: UsageQuery): Promise<UsageEvent[]>;
  summarize(query?: UsageQuery): Promise<UsageSummary>;
}

export function matchesUsageQuery(event: UsageEvent, query: UsageQuery = {}): boolean {
  if (query.appId && event.appId !== query.appId) return false;
  if (query.taskId && event.taskId !== query.taskId) return false;
  if (query.userId && event.userId !== query.userId) return false;
  if (query.orgId && event.orgId !== query.orgId) return false;
  if (query.projectId && event.projectId !== query.projectId) return false;
  if (query.environment && event.environment !== query.environment) return false;

  const timestamp = new Date(event.timestamp).getTime();
  if (query.since && timestamp < query.since.getTime()) return false;
  if (query.until && timestamp > query.until.getTime()) return false;

  return true;
}

export function summarizeUsage(events: UsageEvent[]): UsageSummary {
  return events.reduce<UsageSummary>(
    (summary, event) => {
      summary.requestCount += event.fallbackIndex === 0 ? 1 : 0;
      summary.successCount += event.status === "success" ? 1 : 0;
      summary.failureCount += event.status === "failure" ? 1 : 0;
      summary.blockedCount += event.status === "blocked" ? 1 : 0;
      summary.estimatedCostUsd += event.estimatedCostUsd;
      summary.actualCostUsd += event.actualCostUsd ?? event.estimatedCostUsd;
      return summary;
    },
    {
      requestCount: 0,
      successCount: 0,
      failureCount: 0,
      blockedCount: 0,
      estimatedCostUsd: 0,
      actualCostUsd: 0,
    },
  );
}
