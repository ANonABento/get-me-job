import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { dirname } from "node:path";
import type { UsageEvent, UsageQuery, UsageSummary } from "../types.js";
import { matchesUsageQuery, summarizeUsage, type UsageStore } from "./usageStore.js";

export class JsonFileUsageStore implements UsageStore {
  constructor(private readonly filePath: string) {}

  async record(event: UsageEvent): Promise<void> {
    const events = await this.readEvents();
    events.push(event);
    await this.writeEvents(events);
  }

  async list(query: UsageQuery = {}): Promise<UsageEvent[]> {
    const events = await this.readEvents();
    return events.filter((event) => matchesUsageQuery(event, query));
  }

  async summarize(query: UsageQuery = {}): Promise<UsageSummary> {
    return summarizeUsage(await this.list(query));
  }

  private async readEvents(): Promise<UsageEvent[]> {
    try {
      const content = await readFile(this.filePath, "utf8");
      const parsed = JSON.parse(content) as unknown;
      return Array.isArray(parsed) ? parsed.filter(isUsageEvent) : [];
    } catch (error) {
      if (isNotFound(error)) return [];
      throw error;
    }
  }

  private async writeEvents(events: UsageEvent[]): Promise<void> {
    await mkdir(dirname(this.filePath), { recursive: true });
    const tmpPath = `${this.filePath}.${process.pid}.tmp`;
    await writeFile(tmpPath, `${JSON.stringify(events, null, 2)}\n`, "utf8");
    await rename(tmpPath, this.filePath);
  }
}

function isUsageEvent(value: unknown): value is UsageEvent {
  return (
    typeof value === "object" &&
    value !== null &&
    typeof (value as UsageEvent).id === "string" &&
    typeof (value as UsageEvent).timestamp === "string" &&
    typeof (value as UsageEvent).appId === "string" &&
    typeof (value as UsageEvent).taskId === "string" &&
    typeof (value as UsageEvent).requestId === "string"
  );
}

function isNotFound(error: unknown): boolean {
  return typeof error === "object" && error !== null && "code" in error && error.code === "ENOENT";
}
