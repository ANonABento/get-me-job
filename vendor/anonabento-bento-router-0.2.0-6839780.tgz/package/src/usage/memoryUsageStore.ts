import type { UsageEvent, UsageQuery, UsageSummary } from "../types.js";
import { matchesUsageQuery, summarizeUsage, type UsageStore } from "./usageStore.js";

export class MemoryUsageStore implements UsageStore {
  private readonly events: UsageEvent[] = [];

  async record(event: UsageEvent): Promise<void> {
    this.events.push(event);
  }

  async list(query: UsageQuery = {}): Promise<UsageEvent[]> {
    return this.events.filter((event) => matchesUsageQuery(event, query));
  }

  async summarize(query: UsageQuery = {}): Promise<UsageSummary> {
    return summarizeUsage(await this.list(query));
  }

  clear(): void {
    this.events.length = 0;
  }
}
