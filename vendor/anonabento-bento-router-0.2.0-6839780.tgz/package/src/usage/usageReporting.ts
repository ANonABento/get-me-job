import type { BudgetPolicy, UsageEvent, UsageSummary } from "../types.js";
import { summarizeUsage } from "./usageStore.js";

export type UsageGroupBy = "app" | "task" | "provider" | "model" | "user" | "org" | "project" | "environment" | "day";

export type UsageReportRow = UsageSummary & {
  key: string;
  fallbackCount: number;
  degradedCount: number;
  fallbackRate: number;
  failureRate: number;
  latencyP50Ms: number;
  latencyP95Ms: number;
};

export type BudgetRemaining = {
  dailyAppBudgetUsd?: number;
  dailyTaskBudgetUsd?: number;
  dailyUserBudgetUsd?: number;
  dailyOrgBudgetUsd?: number;
  appRemainingUsd?: number;
  taskRemainingUsd?: number;
  userRemainingUsd?: number;
  orgRemainingUsd?: number;
};

export type SpendAnomaly = {
  key: string;
  baselineCostUsd: number;
  recentCostUsd: number;
  multiplier: number;
};

export function groupUsage(events: UsageEvent[], by: UsageGroupBy): UsageReportRow[] {
  const groups = new Map<string, UsageEvent[]>();
  for (const event of events) {
    const key = groupKey(event, by);
    groups.set(key, [...(groups.get(key) ?? []), event]);
  }

  return [...groups.entries()]
    .map(([key, groupEvents]) => toReportRow(key, groupEvents))
    .sort((a, b) => a.key.localeCompare(b.key));
}

export function calculateBudgetRemaining(
  budget: BudgetPolicy | undefined,
  usage: {
    app?: UsageSummary;
    task?: UsageSummary;
    user?: UsageSummary;
    org?: UsageSummary;
  },
): BudgetRemaining {
  return {
    dailyAppBudgetUsd: budget?.dailyAppBudgetUsd,
    dailyTaskBudgetUsd: budget?.dailyTaskBudgetUsd,
    dailyUserBudgetUsd: budget?.dailyUserBudgetUsd,
    dailyOrgBudgetUsd: budget?.dailyOrgBudgetUsd,
    appRemainingUsd: remaining(budget?.dailyAppBudgetUsd, usage.app?.actualCostUsd),
    taskRemainingUsd: remaining(budget?.dailyTaskBudgetUsd, usage.task?.actualCostUsd),
    userRemainingUsd: remaining(budget?.dailyUserBudgetUsd, usage.user?.actualCostUsd),
    orgRemainingUsd: remaining(budget?.dailyOrgBudgetUsd, usage.org?.actualCostUsd),
  };
}

export function detectSpendAnomalies(
  events: UsageEvent[],
  options: {
    groupBy?: UsageGroupBy;
    baselineUntil: Date;
    recentSince: Date;
    minRecentCostUsd?: number;
    multiplier?: number;
  },
): SpendAnomaly[] {
  const groupBy = options.groupBy ?? "app";
  const baseline = groupUsage(
    events.filter((event) => new Date(event.timestamp) < options.baselineUntil),
    groupBy,
  );
  const recent = groupUsage(
    events.filter((event) => new Date(event.timestamp) >= options.recentSince),
    groupBy,
  );
  const baselineByKey = new Map(baseline.map((row) => [row.key, row.actualCostUsd]));
  const multiplier = options.multiplier ?? 2;
  const minRecentCostUsd = options.minRecentCostUsd ?? 0;

  return recent
    .map((row) => {
      const baselineCostUsd = baselineByKey.get(row.key) ?? 0;
      const effectiveBaseline = baselineCostUsd || 0.000001;
      return {
        key: row.key,
        baselineCostUsd,
        recentCostUsd: row.actualCostUsd,
        multiplier: row.actualCostUsd / effectiveBaseline,
      };
    })
    .filter(
      (anomaly) =>
        anomaly.recentCostUsd >= minRecentCostUsd &&
        anomaly.multiplier >= multiplier,
    );
}

export function usageEventsToCsv(events: UsageEvent[]): string {
  const columns: Array<keyof UsageEvent> = [
    "id",
    "timestamp",
    "appId",
    "taskId",
    "userId",
    "requestId",
    "provider",
    "model",
    "status",
    "fallbackIndex",
    "inputTokensEstimated",
    "inputTokensActual",
    "outputTokensActual",
    "estimatedCostUsd",
    "actualCostUsd",
    "latencyMs",
    "errorCode",
    "errorMessage",
    "degradationUsed",
  ];

  return [
    columns.join(","),
    ...events.map((event) => columns.map((column) => csvCell(event[column])).join(",")),
  ].join("\n");
}

function toReportRow(key: string, events: UsageEvent[]): UsageReportRow {
  const summary = summarizeUsage(events);
  const fallbackCount = events.filter((event) => event.status === "success" && event.fallbackIndex > 0).length;
  const degradedCount = events.filter((event) => event.status === "degraded").length;
  const attempts = events.length || 1;
  return {
    key,
    ...summary,
    fallbackCount,
    degradedCount,
    fallbackRate: fallbackCount / attempts,
    failureRate: summary.failureCount / attempts,
    latencyP50Ms: percentile(events.map((event) => event.latencyMs), 0.5),
    latencyP95Ms: percentile(events.map((event) => event.latencyMs), 0.95),
  };
}

function groupKey(event: UsageEvent, by: UsageGroupBy): string {
  switch (by) {
    case "app":
      return event.appId;
    case "task":
      return event.taskId;
    case "provider":
      return event.provider ?? "unknown";
    case "model":
      return event.model ?? "unknown";
    case "user":
      return event.userId ?? "anonymous";
    case "org":
      return event.orgId ?? "unknown";
    case "project":
      return event.projectId ?? "unknown";
    case "environment":
      return event.environment ?? "unknown";
    case "day":
      return event.timestamp.slice(0, 10);
  }
}

function remaining(budget: number | undefined, spent = 0): number | undefined {
  if (budget === undefined) return undefined;
  return Math.max(0, budget - spent);
}

function percentile(values: number[], p: number): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const index = Math.min(sorted.length - 1, Math.ceil(sorted.length * p) - 1);
  return sorted[index] ?? 0;
}

function csvCell(value: unknown): string {
  if (value === undefined || value === null) return "";
  const text = String(value);
  if (!/[",\n]/.test(text)) return text;
  return `"${text.replaceAll('"', '""')}"`;
}
