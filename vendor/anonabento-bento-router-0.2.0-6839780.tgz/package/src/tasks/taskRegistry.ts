import type { TaskDefinition, TaskId } from "../types.js";

export class TaskRegistry {
  private readonly tasks = new Map<TaskId, TaskDefinition>();

  register(task: TaskDefinition): TaskDefinition {
    if (this.tasks.has(task.id)) {
      throw new Error(`AI task already registered: ${task.id}`);
    }

    this.tasks.set(task.id, task);
    return task;
  }

  upsert(task: TaskDefinition): TaskDefinition {
    this.tasks.set(task.id, task);
    return task;
  }

  get(taskId: TaskId): TaskDefinition | undefined {
    return this.tasks.get(taskId);
  }

  require(taskId: TaskId): TaskDefinition {
    const task = this.get(taskId);
    if (!task) {
      throw new Error(`Unknown AI task: ${taskId}`);
    }
    return task;
  }

  list(appId?: string): TaskDefinition[] {
    const tasks = [...this.tasks.values()];
    return appId ? tasks.filter((task) => task.appId === appId) : tasks;
  }
}

export const defaultTaskRegistry = new TaskRegistry();
