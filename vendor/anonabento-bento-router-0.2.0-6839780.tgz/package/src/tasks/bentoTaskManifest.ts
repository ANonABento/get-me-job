import type { ModelRegistry } from "../providers/modelRegistry.js";
import { resolvePolicy } from "../runtime/policy.js";
import type { PolicyOverrides, PromptMetadata, TaskDefinition, TaskPolicy } from "../types.js";
import type { TaskRegistry } from "./taskRegistry.js";

export type BentoTaskManifestEntry = {
  id: string;
  appId: string;
  name: string;
  category?: string;
  description?: string;
  prompt?: PromptMetadata;
  defaultPolicy: TaskPolicy;
  effectivePolicy: TaskPolicy;
};

export type BentoTaskManifest = {
  version: 1;
  generatedAt: string;
  apps: string[];
  tasks: BentoTaskManifestEntry[];
  models?: Array<ReturnType<ModelRegistry["list"]>[number]>;
};

export type CreateBentoTaskManifestOptions = {
  taskRegistry: TaskRegistry;
  modelRegistry?: ModelRegistry;
  policyOverrides?: PolicyOverrides;
  appId?: string;
  generatedAt?: Date;
};

export function createBentoTaskManifest({
  taskRegistry,
  modelRegistry,
  policyOverrides,
  appId,
  generatedAt = new Date(),
}: CreateBentoTaskManifestOptions): BentoTaskManifest {
  const tasks = taskRegistry.list(appId).map((task) => toManifestEntry(task, policyOverrides));

  return {
    version: 1,
    generatedAt: generatedAt.toISOString(),
    apps: [...new Set(tasks.map((task) => task.appId))].sort(),
    tasks,
    models: modelRegistry?.list(),
  };
}

function toManifestEntry(
  task: TaskDefinition,
  policyOverrides: PolicyOverrides | undefined,
): BentoTaskManifestEntry {
  return {
    id: task.id,
    appId: task.appId,
    name: task.name,
    category: task.category,
    description: task.description,
    prompt: task.prompt,
    defaultPolicy: task.defaultPolicy,
    effectivePolicy: resolvePolicy(task, policyOverrides),
  };
}
