import type { TaskDefinition } from "../types.js";
import { defaultTaskRegistry, type TaskRegistry } from "./taskRegistry.js";

export function defineBentoTask(
  task: TaskDefinition,
  registry: TaskRegistry = defaultTaskRegistry,
): TaskDefinition {
  return registry.register(task);
}
