import type { TaskDefinition } from "../types.js";
import type { TaskRegistry } from "./taskRegistry.js";

export type TaskDiscoverySummary = {
  apps: string[];
  taskIds: string[];
  tasksByApp: Record<string, string[]>;
};

export function discoverBentoTasks(tasksOrRegistry: TaskRegistry | TaskDefinition[]): TaskDiscoverySummary {
  const tasks = Array.isArray(tasksOrRegistry) ? tasksOrRegistry : tasksOrRegistry.list();
  const tasksByApp: Record<string, string[]> = {};

  for (const task of tasks) {
    tasksByApp[task.appId] = [...(tasksByApp[task.appId] ?? []), task.id].sort();
  }

  return {
    apps: Object.keys(tasksByApp).sort(),
    taskIds: tasks.map((task) => task.id).sort(),
    tasksByApp,
  };
}

export function generateTaskIdTypes(
  tasksOrRegistry: TaskRegistry | TaskDefinition[],
  typeName = "BentoTaskId",
): string {
  const taskIds = discoverBentoTasks(tasksOrRegistry).taskIds;
  const union = taskIds.length > 0
    ? taskIds.map((taskId) => `  | ${JSON.stringify(taskId)}`).join("\n")
    : "  | never";
  return `export type ${typeName} =\n${union};\n`;
}
