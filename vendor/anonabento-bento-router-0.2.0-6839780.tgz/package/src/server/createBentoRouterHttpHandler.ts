import type { BentoRouterApi } from "./createBentoRouterApi.js";
import type { TaskPolicy, UsageQuery } from "../types.js";
import type { AddProviderInput } from "./createBentoRouterApi.js";
import type { ProviderConfigPatch } from "../providers/providerConfigStore.js";
import type { ValidateProviderInput } from "../providers/providerValidation.js";

export type BentoRouterHttpHandlerOptions = {
  api: BentoRouterApi;
  basePath?: string;
};

export type BentoRouterHttpHandler = (request: Request) => Promise<Response>;

export function createBentoRouterHttpHandler({
  api,
  basePath = "/api/bento-router",
}: BentoRouterHttpHandlerOptions): BentoRouterHttpHandler {
  return async (request: Request): Promise<Response> => {
    const url = new URL(request.url);
    const path = stripBasePath(url.pathname, basePath);

    try {
      if (request.method === "GET" && path === "/tasks") {
        return json(await api.listTasks(url.searchParams.get("appId") ?? undefined));
      }

      if (request.method === "GET" && path === "/manifest") {
        return json(await api.manifest(url.searchParams.get("appId") ?? undefined));
      }

      if (request.method === "GET" && path === "/health") {
        return json(await api.health());
      }

      if (request.method === "POST" && path === "/run") {
        return json(await api.run(await request.json()));
      }

      const taskMatch = path.match(/^\/tasks\/([^/]+)$/);
      if (request.method === "GET" && taskMatch) {
        return json(await api.getTask(decodeURIComponent(taskMatch[1])));
      }

      const policyMatch = path.match(/^\/tasks\/([^/]+)\/policy$/);
      if (request.method === "PUT" && policyMatch) {
        const body = (await request.json()) as Partial<TaskPolicy>;
        return json(await api.updateTaskPolicy(decodeURIComponent(policyMatch[1]), body));
      }

      const testMatch = path.match(/^\/tasks\/([^/]+)\/test$/);
      if (request.method === "POST" && testMatch) {
        const body = (await request.json()) as {
          messages?: Array<{ role: "system" | "user" | "assistant"; content: string }>;
        };
        return json(await api.testTask(decodeURIComponent(testMatch[1]), body.messages ?? []));
      }

      if (request.method === "GET" && path === "/models") {
        return json(await api.listModels());
      }

      if (request.method === "GET" && path === "/providers") {
        const userId = url.searchParams.get("userId");
        if (userId) return json(await api.listConfiguredProviders(userId));
        return json(await api.listProviders());
      }

      if (request.method === "POST" && path === "/providers") {
        return json(await api.addConfiguredProvider((await request.json()) as AddProviderInput), 201);
      }

      if (request.method === "POST" && path === "/providers/validate") {
        return json(await api.validateProvider((await request.json()) as ValidateProviderInput));
      }

      const providerMatch = path.match(/^\/providers\/([^/]+)$/);
      if (request.method === "GET" && providerMatch) {
        return json(
          await api.getConfiguredProvider(
            requireQueryParam(url.searchParams, "userId"),
            decodeURIComponent(providerMatch[1]),
          ),
        );
      }

      if (request.method === "PUT" && providerMatch) {
        const body = (await request.json()) as ProviderConfigPatch & { userId?: string };
        const { userId, ...patch } = body;
        return json(
          await api.updateConfiguredProvider(
            userId ?? requireQueryParam(url.searchParams, "userId"),
            decodeURIComponent(providerMatch[1]),
            patch,
          ),
        );
      }

      if (request.method === "DELETE" && providerMatch) {
        await api.removeConfiguredProvider(
          requireQueryParam(url.searchParams, "userId"),
          decodeURIComponent(providerMatch[1]),
        );
        return json({ ok: true });
      }

      if (request.method === "GET" && path === "/usage/summary") {
        return json(await api.usageSummary(readUsageQuery(url.searchParams)));
      }

      const userUsageMatch = path.match(/^\/usage\/users\/([^/]+)\/summary$/);
      if (request.method === "GET" && userUsageMatch) {
        return json(
          await api.usageSummaryByUser(decodeURIComponent(userUsageMatch[1]), {
            from: url.searchParams.get("from") ?? "",
            to: url.searchParams.get("to") ?? "",
          }),
        );
      }

      if (request.method === "GET" && path === "/usage/events") {
        return json(await api.usageEvents(readUsageQuery(url.searchParams)));
      }

      if (request.method === "GET" && path === "/usage/report") {
        return json(await api.usageReport(readUsageQuery(url.searchParams), readGroupBy(url.searchParams)));
      }

      if (request.method === "GET" && path === "/usage/events.csv") {
        return text(await api.usageCsv(readUsageQuery(url.searchParams)), "text/csv; charset=utf-8");
      }

      return json({ error: "not_found" }, 404);
    } catch (error) {
      return json(
        {
          error: error instanceof Error ? error.name : "Error",
          message: error instanceof Error ? error.message : String(error),
        },
        500,
      );
    }
  };
}

function stripBasePath(pathname: string, basePath: string): string {
  if (pathname === basePath) return "/";
  if (!pathname.startsWith(`${basePath}/`)) return pathname;
  return pathname.slice(basePath.length);
}

function readUsageQuery(params: URLSearchParams): UsageQuery {
  return {
    appId: params.get("appId") ?? undefined,
    taskId: params.get("taskId") ?? undefined,
    userId: params.get("userId") ?? undefined,
    orgId: params.get("orgId") ?? undefined,
    projectId: params.get("projectId") ?? undefined,
    environment: params.get("environment") ?? undefined,
    since: parseDate(params.get("since")),
    until: parseDate(params.get("until")),
  };
}

function requireQueryParam(params: URLSearchParams, name: string): string {
  const value = params.get(name);
  if (!value) throw new Error(`${name} query parameter is required`);
  return value;
}

function parseDate(value: string | null): Date | undefined {
  if (!value) return undefined;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? undefined : date;
}

function readGroupBy(params: URLSearchParams) {
  const groupBy = params.get("groupBy");
  if (
    groupBy === "app" ||
    groupBy === "task" ||
    groupBy === "provider" ||
    groupBy === "model" ||
    groupBy === "user" ||
    groupBy === "org" ||
    groupBy === "project" ||
    groupBy === "environment" ||
    groupBy === "day"
  ) {
    return groupBy;
  }
  return undefined;
}

function json(value: unknown, status = 200): Response {
  return new Response(JSON.stringify(value), {
    status,
    headers: {
      "Content-Type": "application/json",
    },
  });
}

function text(value: string, contentType: string, status = 200): Response {
  return new Response(value, {
    status,
    headers: {
      "Content-Type": contentType,
    },
  });
}
