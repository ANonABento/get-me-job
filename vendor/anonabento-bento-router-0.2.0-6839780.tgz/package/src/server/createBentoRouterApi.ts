import type { BentoRouter } from "../runtime/bentoRouter.js";
import type { CircuitBreaker } from "../runtime/circuitBreaker.js";
import type { ModelRegistry } from "../providers/modelRegistry.js";
import type { ProviderRegistry } from "../providers/providerRegistry.js";
import type { TaskRegistry } from "../tasks/taskRegistry.js";
import type { BentoRouterInput, PolicyOverrides, TaskPolicy, UsageQuery } from "../types.js";
import type { UsageStore } from "../usage/usageStore.js";
import { groupUsage, usageEventsToCsv, type UsageGroupBy } from "../usage/usageReporting.js";
import type {
  ProviderConfig,
  ProviderConfigPatch,
  ProviderConfigStore,
  ProviderConfigType,
} from "../providers/providerConfigStore.js";
import {
  createProviderAdapterFromConfig,
  type EncryptionAdapter,
} from "../providers/runtimeProviderConfig.js";
import {
  validateProvider as validateProviderConfig,
  type ValidateProviderInput,
  type ValidateProviderResult,
} from "../providers/providerValidation.js";
import {
  mergePolicyOverrides,
  mergeTaskPolicyOverride,
  type PolicyStore,
} from "../policies/policyStore.js";
import { resolvePolicy } from "../runtime/policy.js";
import { createBentoTaskManifest } from "../tasks/bentoTaskManifest.js";
import type { UsageSummary } from "../types.js";

export type AddProviderInput = {
  type: ProviderConfigType;
  displayName: string;
  apiKey: string;
  baseUrl?: string;
  defaultModel?: string;
  userId: string;
  metadata?: Record<string, unknown>;
};

export type BentoRouterApi = {
  listTasks(appId?: string): Promise<Array<Record<string, unknown>>>;
  getTask(taskId: string): Promise<Record<string, unknown>>;
  updateTaskPolicy(taskId: string, policy: Partial<TaskPolicy>): Promise<Record<string, unknown>>;
  listModels(): Promise<Array<Record<string, unknown>>>;
  listProviders(): Promise<Array<Record<string, unknown>>>;
  listConfiguredProviders(userId: string): Promise<ProviderConfig[]>;
  getConfiguredProvider(userId: string, id: string): Promise<ProviderConfig | null>;
  addConfiguredProvider(input: AddProviderInput): Promise<ProviderConfig>;
  updateConfiguredProvider(userId: string, id: string, patch: ProviderConfigPatch): Promise<ProviderConfig>;
  removeConfiguredProvider(userId: string, id: string): Promise<void>;
  validateProvider(input: ValidateProviderInput): Promise<ValidateProviderResult>;
  refreshConfiguredProviders(): Promise<void>;
  usageSummary(query?: UsageQuery): Promise<Record<string, unknown>>;
  usageSummaryByUser(userId: string, range?: { from: string; to: string }): Promise<UsageSummary>;
  usageEvents(query?: UsageQuery): Promise<Array<Record<string, unknown>>>;
  usageReport(query?: UsageQuery, groupBy?: UsageGroupBy): Promise<Array<Record<string, unknown>>>;
  usageCsv(query?: UsageQuery): Promise<string>;
  health(): Promise<Record<string, unknown>>;
  testTask(taskId: string, messages: Array<{ role: "system" | "user" | "assistant"; content: string }>): Promise<Record<string, unknown>>;
  manifest(appId?: string): Promise<Record<string, unknown>>;
  run(input: BentoRouterInput): Promise<Record<string, unknown>>;
};

export type BentoRouterAdminOperation =
  | {
      type: "read";
      resource:
        | "tasks"
        | "task"
        | "models"
        | "providers"
        | "configuredProviders"
        | "configuredProvider"
        | "usageSummary"
        | "usageEvents"
        | "usageReport"
        | "usageCsv"
        | "manifest";
      taskId?: string;
    }
  | {
      type: "write";
      resource: "taskPolicy" | "configuredProvider";
      taskId?: string;
      policy: Partial<TaskPolicy>;
    }
  | {
      type: "execute";
      resource: "taskTest" | "taskRun" | "providerValidation";
      taskId?: string;
    };

export type BentoRouterAuditEvent = {
  type: "policy_update";
  taskId: string;
  before?: Partial<TaskPolicy>;
  after?: Partial<TaskPolicy>;
  timestamp: string;
};

export type BentoRouterApiOptions = {
  router: BentoRouter;
  taskRegistry: TaskRegistry;
  modelRegistry: ModelRegistry;
  providerRegistry: ProviderRegistry;
  usageStore: UsageStore;
  policyOverrides?: PolicyOverrides;
  policyStore?: PolicyStore;
  providerConfigStore?: ProviderConfigStore;
  encryption?: EncryptionAdapter;
  fetchImpl?: typeof fetch;
  providerValidationTimeoutMs?: number;
  circuitBreaker?: CircuitBreaker;
  readOnly?: boolean;
  authorize?: (operation: BentoRouterAdminOperation) => boolean | void | Promise<boolean | void>;
  audit?: (event: BentoRouterAuditEvent) => void | Promise<void>;
};

export function createBentoRouterApi(options: BentoRouterApiOptions): BentoRouterApi {
  const policyOverrides = options.policyOverrides ?? {};
  const validationRateLimiter = new ValidationRateLimiter();
  const providerTypeAliasOwners = new Map<ProviderConfigType, string>();

  if (options.encryption && !options.providerConfigStore) {
    throw new Error("BentoRouter encryption requires providerConfigStore");
  }
  if (options.providerConfigStore && !options.encryption) {
    console.warn(
      "[BentoRouter] providerConfigStore configured without an EncryptionAdapter. API keys will be stored as plaintext; this is acceptable only for local development.",
    );
  }

  return {
    async listTasks(appId?: string) {
      await authorize(options, { type: "read", resource: "tasks" });
      const effectiveOverrides = await readPolicyOverrides(options.policyStore, policyOverrides);
      return options.taskRegistry.list(appId).map((task) => ({
        ...task,
        effectivePolicy: resolvePolicy(task, effectiveOverrides),
      }));
    },

    async getTask(taskId: string) {
      await authorize(options, { type: "read", resource: "task", taskId });
      const task = options.taskRegistry.require(taskId);
      const effectiveOverrides = await readPolicyOverrides(options.policyStore, policyOverrides);
      return {
        ...task,
        effectivePolicy: resolvePolicy(task, effectiveOverrides),
      };
    },

    async updateTaskPolicy(taskId: string, policy: Partial<TaskPolicy>) {
      options.taskRegistry.require(taskId);
      if (options.readOnly) {
        throw new Error("BentoRouter admin API is read-only");
      }
      await authorize(options, { type: "write", resource: "taskPolicy", taskId, policy });
      validateKnownModels(options.modelRegistry, policy);
      const before = (await readPolicyOverrides(options.policyStore, policyOverrides)).task?.[taskId];
      if (options.policyStore) {
        const next = await options.policyStore.updateTaskPolicy(taskId, policy);
        await auditPolicyUpdate(options, taskId, before, next.task?.[taskId]);
        return this.getTask(taskId);
      }
      const next = mergeTaskPolicyOverride(policyOverrides, taskId, policy);
      policyOverrides.global = next.global;
      policyOverrides.app = next.app;
      policyOverrides.task = next.task;
      await auditPolicyUpdate(options, taskId, before, policyOverrides.task?.[taskId]);
      return this.getTask(taskId);
    },

    async listModels() {
      await authorize(options, { type: "read", resource: "models" });
      return options.modelRegistry.list();
    },

    async listProviders() {
      await authorize(options, { type: "read", resource: "providers" });
      return options.providerRegistry.list().map((provider) => ({ id: provider.id }));
    },

    async listConfiguredProviders(userId: string) {
      await authorize(options, { type: "read", resource: "configuredProviders" });
      return requireProviderConfigStore(options).list(requireUserId(userId));
    },

    async getConfiguredProvider(userId: string, id: string) {
      await authorize(options, { type: "read", resource: "configuredProvider" });
      return requireProviderConfigStore(options).get(requireUserId(userId), id);
    },

    async addConfiguredProvider(input: AddProviderInput) {
      if (options.readOnly) {
        throw new Error("BentoRouter admin API is read-only");
      }
      await authorize(options, {
        type: "write",
        resource: "configuredProvider",
        policy: {},
      });
      validateProviderInput(input);
      const store = requireProviderConfigStore(options);
      const id = providerConfigId(input.type, input.displayName);
      const userId = requireUserId(input.userId);
      if (await store.get(userId, id)) {
        throw new Error(`Configured provider already exists for user ${userId}: ${id}`);
      }
      const config = await store.upsert({
        id,
        type: input.type,
        displayName: input.displayName,
        encryptedApiKey: await encryptApiKey(input.apiKey, options.encryption),
        encryptionScheme: options.encryption?.scheme ?? "plaintext",
        baseUrl: input.baseUrl,
        defaultModel: input.defaultModel,
        createdAt: new Date().toISOString(),
        userId,
        metadata: input.metadata,
      });
      await registerConfiguredProvider(options, providerTypeAliasOwners, config);
      await maybePopulateFallbacks(options, config);
      return config;
    },

    async updateConfiguredProvider(userId: string, id: string, patch: ProviderConfigPatch) {
      if (options.readOnly) {
        throw new Error("BentoRouter admin API is read-only");
      }
      await authorize(options, {
        type: "write",
        resource: "configuredProvider",
        policy: {},
      });
      const store = requireProviderConfigStore(options);
      const existing = await store.get(requireUserId(userId), id);
      if (!existing) throw new Error(`Configured provider not found: ${id}`);
      const config = await store.upsert({
        ...existing,
        displayName: patch.displayName ?? existing.displayName,
        encryptedApiKey:
          patch.apiKey !== undefined
            ? await encryptApiKey(patch.apiKey, options.encryption)
            : existing.encryptedApiKey,
        encryptionScheme:
          patch.apiKey !== undefined ? options.encryption?.scheme ?? "plaintext" : existing.encryptionScheme,
        baseUrl: patch.baseUrl ?? existing.baseUrl,
        defaultModel: patch.defaultModel ?? existing.defaultModel,
        metadata: patch.metadata ?? existing.metadata,
      });
      await registerConfiguredProvider(options, providerTypeAliasOwners, config);
      return config;
    },

    async removeConfiguredProvider(userId: string, id: string) {
      if (options.readOnly) {
        throw new Error("BentoRouter admin API is read-only");
      }
      await authorize(options, {
        type: "write",
        resource: "configuredProvider",
        policy: {},
      });
      await requireProviderConfigStore(options).delete(requireUserId(userId), id);
      options.providerRegistry.unregister(id);
      for (const [type, ownerId] of providerTypeAliasOwners) {
        if (ownerId === id) {
          options.providerRegistry.unregister(type);
          providerTypeAliasOwners.delete(type);
        }
      }
      await this.refreshConfiguredProviders();
    },

    async validateProvider(input: ValidateProviderInput) {
      await authorize(options, { type: "execute", resource: "providerValidation" });
      const rateLimitKey = `${input.type}:${input.baseUrl ?? "default"}`;
      if (!validationRateLimiter.allow(rateLimitKey)) {
        return {
          ok: false,
          error: {
            code: "provider_validation_rate_limited",
            message: "Provider validation rate limit exceeded. Try again shortly.",
          },
        };
      }
      return validateProviderConfig(input, {
        fetchImpl: options.fetchImpl,
        timeoutMs: options.providerValidationTimeoutMs,
      });
    },

    async refreshConfiguredProviders() {
      const store = requireProviderConfigStore(options);
      for (const config of await store.listAll()) {
        await registerConfiguredProvider(options, providerTypeAliasOwners, config);
      }
    },

    async usageSummary(query?: UsageQuery) {
      await authorize(options, { type: "read", resource: "usageSummary" });
      return options.usageStore.summarize(query);
    },

    async usageSummaryByUser(userId: string, range?: { from: string; to: string }) {
      await authorize(options, { type: "read", resource: "usageSummary" });
      return options.usageStore.summarize({
        userId: requireUserId(userId),
        since: range?.from ? new Date(range.from) : undefined,
        until: range?.to ? new Date(range.to) : undefined,
      });
    },

    async usageEvents(query?: UsageQuery) {
      await authorize(options, { type: "read", resource: "usageEvents" });
      return options.usageStore.list(query);
    },

    async usageReport(query?: UsageQuery, groupBy: UsageGroupBy = "task") {
      await authorize(options, { type: "read", resource: "usageReport" });
      return groupUsage(await options.usageStore.list(query), groupBy);
    },

    async usageCsv(query?: UsageQuery) {
      await authorize(options, { type: "read", resource: "usageCsv" });
      return usageEventsToCsv(await options.usageStore.list(query));
    },

    async health() {
      return {
        ok: true,
        providers: await this.listProviders(),
        circuits: options.circuitBreaker?.snapshotAll() ?? {},
        checkedAt: new Date().toISOString(),
      };
    },

    async testTask(taskId, messages) {
      await authorize(options, { type: "execute", resource: "taskTest", taskId });
      return options.router.run({ task: taskId, messages });
    },

    async manifest(appId?: string) {
      await authorize(options, { type: "read", resource: "manifest" });
      const effectiveOverrides = await readPolicyOverrides(options.policyStore, policyOverrides);
      return createBentoTaskManifest({
        taskRegistry: options.taskRegistry,
        modelRegistry: options.modelRegistry,
        policyOverrides: effectiveOverrides,
        appId,
      });
    },

    async run(input) {
      await authorize(options, { type: "execute", resource: "taskRun", taskId: input.task });
      if (options.providerConfigStore) await this.refreshConfiguredProviders();
      return options.router.run(input);
    },
  };
}

async function encryptApiKey(apiKey: string, encryption?: EncryptionAdapter): Promise<string> {
  if (!encryption) return apiKey;
  return encryption.encrypt(apiKey);
}

async function registerConfiguredProvider(
  options: BentoRouterApiOptions,
  providerTypeAliasOwners: Map<ProviderConfigType, string>,
  config: ProviderConfig,
): Promise<void> {
  const typeAliasOwner = providerTypeAliasOwners.get(config.type);
  const adapters = await createProviderAdapterFromConfig(config, {
    encryption: options.encryption,
    fetchImpl: options.fetchImpl,
    registerTypeAlias:
      config.id === config.type ||
      typeAliasOwner === config.id ||
      (!typeAliasOwner && !options.providerRegistry.get(config.type)),
  });
  for (const adapter of adapters) {
    options.providerRegistry.register(adapter);
    if (adapter.id === config.type) providerTypeAliasOwners.set(config.type, config.id);
  }
}

async function maybePopulateFallbacks(
  options: BentoRouterApiOptions,
  config: ProviderConfig,
): Promise<void> {
  if (!options.policyStore || !config.defaultModel) return;
  const overrides = await readPolicyOverrides(options.policyStore, options.policyOverrides ?? {});
  for (const task of options.taskRegistry.list()) {
    const policy = resolvePolicy(task, overrides);
    if (policy.primaryModel === config.defaultModel || policy.fallbacks?.includes(config.defaultModel)) {
      continue;
    }
    await options.policyStore.updateTaskPolicy(task.id, {
      fallbacks: [...(policy.fallbacks ?? []), config.defaultModel],
    });
  }
}

function validateProviderInput(input: AddProviderInput): void {
  requireUserId(input.userId);
  if (!input.displayName.trim()) throw new Error("Provider displayName is required");
  if (!input.apiKey) throw new Error("Provider apiKey is required");
  if (input.type === "openai-compatible" && !input.baseUrl) {
    throw new Error("openai-compatible providers require baseUrl");
  }
}

function requireProviderConfigStore(options: BentoRouterApiOptions): ProviderConfigStore {
  if (!options.providerConfigStore) {
    throw new Error("BentoRouter providerConfigStore is required for runtime provider configuration");
  }
  return options.providerConfigStore;
}

function requireUserId(userId: string): string {
  if (!userId.trim()) throw new Error("userId is required");
  return userId;
}

function providerConfigId(type: ProviderConfigType, displayName: string): string {
  const slug = displayName
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
  return `${type}-${slug || "provider"}`;
}

class ValidationRateLimiter {
  private readonly hits = new Map<string, number[]>();

  allow(key: string): boolean {
    const now = Date.now();
    const windowMs = 60_000;
    const maxHits = 20;
    const hits = (this.hits.get(key) ?? []).filter((hit) => now - hit < windowMs);
    if (hits.length >= maxHits) {
      this.hits.set(key, hits);
      return false;
    }
    hits.push(now);
    this.hits.set(key, hits);
    return true;
  }
}

async function readPolicyOverrides(
  policyStore: PolicyStore | undefined,
  policyOverrides: PolicyOverrides,
): Promise<PolicyOverrides> {
  if (!policyStore) return policyOverrides;
  return mergePolicyOverrides(policyOverrides, await policyStore.read());
}

function validateKnownModels(modelRegistry: ModelRegistry, policy: Partial<TaskPolicy>): void {
  if (policy.primaryModel) modelRegistry.require(policy.primaryModel);
  for (const modelId of policy.fallbacks ?? []) {
    modelRegistry.require(modelId);
  }
  if (policy.routing?.canary?.model) {
    modelRegistry.require(policy.routing.canary.model);
  }
  for (const modelId of Object.keys(policy.routing?.weights ?? {})) {
    modelRegistry.require(modelId);
  }
}

async function authorize(
  options: BentoRouterApiOptions,
  operation: BentoRouterAdminOperation,
): Promise<void> {
  const allowed = await options.authorize?.(operation);
  if (allowed === false) throw new Error("BentoRouter admin operation is not authorized");
}

async function auditPolicyUpdate(
  options: BentoRouterApiOptions,
  taskId: string,
  before: Partial<TaskPolicy> | undefined,
  after: Partial<TaskPolicy> | undefined,
): Promise<void> {
  await options.audit?.({
    type: "policy_update",
    taskId,
    before,
    after,
    timestamp: new Date().toISOString(),
  });
}
