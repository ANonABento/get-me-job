import { createServer, type IncomingMessage, type Server, type ServerResponse } from "node:http";
import type { BentoRouterHttpHandler } from "./createBentoRouterHttpHandler.js";

export type BentoRouterServiceOptions = {
  handler: BentoRouterHttpHandler;
  host?: string;
  port?: number;
};

export type BentoRouterService = {
  server: Server;
  url: string;
  start(): Promise<string>;
  stop(): Promise<void>;
};

export function createBentoRouterService({
  handler,
  host = "127.0.0.1",
  port = 0,
}: BentoRouterServiceOptions): BentoRouterService {
  const server = createServer((request, response) => {
    void handleNodeRequest(handler, request, response);
  });

  return {
    server,
    get url() {
      return currentUrl(server, host);
    },
    async start() {
      if (server.listening) return currentUrl(server, host);
      await new Promise<void>((resolve, reject) => {
        server.once("error", reject);
        server.listen(port, host, () => {
          server.off("error", reject);
          resolve();
        });
      });
      return currentUrl(server, host);
    },
    async stop() {
      if (!server.listening) return;
      await new Promise<void>((resolve, reject) => {
        server.close((error) => (error ? reject(error) : resolve()));
      });
    },
  };
}

async function handleNodeRequest(
  handler: BentoRouterHttpHandler,
  request: IncomingMessage,
  response: ServerResponse,
): Promise<void> {
  const webRequest = await toWebRequest(request);
  const webResponse = await handler(webRequest);
  const headers: Record<string, string> = {};
  webResponse.headers.forEach((value, key) => {
    headers[key] = value;
  });
  response.writeHead(webResponse.status, headers);
  response.end(Buffer.from(await webResponse.arrayBuffer()));
}

async function toWebRequest(request: IncomingMessage): Promise<Request> {
  const body = await readBody(request);
  const host = request.headers.host ?? "localhost";
  const url = new URL(request.url ?? "/", `http://${host}`);
  return new Request(url, {
    method: request.method,
    headers: request.headers as HeadersInit,
    body: body.length > 0 ? body.toString("utf8") : undefined,
  });
}

async function readBody(request: IncomingMessage): Promise<Buffer> {
  const chunks: Buffer[] = [];
  for await (const chunk of request) {
    chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
  }
  return Buffer.concat(chunks);
}

function currentUrl(server: Server, host: string): string {
  const address = server.address();
  if (!address || typeof address === "string") return "";
  return `http://${host}:${address.port}`;
}
