import { mkdtemp, rm } from "node:fs/promises";
import { join } from "node:path";
import { tmpdir } from "node:os";
import { afterEach, describe, expect, it } from "vitest";
import { JsonFileUsageStore } from "../src/index.js";

let tempDir: string | undefined;

afterEach(async () => {
  if (tempDir) {
    await rm(tempDir, { recursive: true, force: true });
    tempDir = undefined;
  }
});

describe("JsonFileUsageStore", () => {
  it("persists and summarizes usage events", async () => {
    tempDir = await mkdtemp(join(tmpdir(), "bento-router-"));
    const filePath = join(tempDir, "usage.json");
    const store = new JsonFileUsageStore(filePath);

    await store.record({
      id: "evt-1",
      timestamp: new Date().toISOString(),
      appId: "slothing",
      taskId: "slothing.listing_description",
      requestId: "req-1",
      provider: "openrouter",
      model: "openrouter/openai/gpt-4.1-mini",
      status: "success",
      fallbackIndex: 0,
      inputTokensEstimated: 100,
      estimatedCostUsd: 0.001,
      actualCostUsd: 0.0012,
      latencyMs: 25,
    });

    const reloaded = new JsonFileUsageStore(filePath);
    const events = await reloaded.list({ appId: "slothing" });
    const summary = await reloaded.summarize({ appId: "slothing" });

    expect(events).toHaveLength(1);
    expect(summary.requestCount).toBe(1);
    expect(summary.successCount).toBe(1);
    expect(summary.actualCostUsd).toBe(0.0012);
  });
});
