import { mkdtemp, readFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import {
  JsonFileProviderConfigStore,
  MemoryProviderConfigStore,
  type ProviderConfig,
} from "../src/index.js";

const config: ProviderConfig = {
  id: "openai-personal",
  type: "openai",
  displayName: "Personal",
  encryptedApiKey: "ciphertext",
  encryptionScheme: "test-v1",
  createdAt: "2026-05-16T00:00:00.000Z",
  userId: "user-a",
};

describe("provider config stores", () => {
  it("isolates configs by user in memory", async () => {
    const store = new MemoryProviderConfigStore([
      config,
      { ...config, id: "openai-work", displayName: "Work", userId: "user-b" },
    ]);

    expect(await store.list("user-a")).toEqual([config]);
    expect(await store.get("user-b", "openai-personal")).toBeNull();
  });

  it("persists provider configs to JSON envelope", async () => {
    const tempDir = await mkdtemp(join(tmpdir(), "bento-router-providers-"));
    const filePath = join(tempDir, "providers.json");
    const store = new JsonFileProviderConfigStore(filePath);

    await store.upsert(config);
    await store.upsert({ ...config, displayName: "Personal Updated" });

    const reloaded = new JsonFileProviderConfigStore(filePath);
    expect(await reloaded.get("user-a", "openai-personal")).toMatchObject({
      displayName: "Personal Updated",
      encryptedApiKey: "ciphertext",
    });
    expect(JSON.parse(await readFile(filePath, "utf8"))).toMatchObject({
      version: 1,
      configs: [{ id: "openai-personal", userId: "user-a" }],
    });
  });
});
