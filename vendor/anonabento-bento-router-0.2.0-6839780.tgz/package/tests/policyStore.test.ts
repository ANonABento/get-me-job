import { mkdtemp, readFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import {
  JsonFilePolicyStore,
  MemoryPolicyStore,
  DatabasePolicyStore,
  RemotePolicyStore,
  mergePolicyOverrides,
  validatePolicyOverride,
} from "../src/index.js";

describe("policy stores", () => {
  it("persists task policy updates to JSON", async () => {
    const tempDir = await mkdtemp(join(tmpdir(), "bento-router-policy-"));
    const filePath = join(tempDir, "policies.json");
    const store = new JsonFilePolicyStore(filePath);

    await store.updateTaskPolicy("tomodachi.chat_reply", {
      primaryModel: "test/cheap",
      guardrails: { maxRetries: 2 },
    });

    const reloaded = new JsonFilePolicyStore(filePath);
    await reloaded.updateTaskPolicy("tomodachi.chat_reply", {
      guardrails: { timeoutMs: 5000 },
    });

    expect(await reloaded.read()).toEqual({
      task: {
        "tomodachi.chat_reply": {
          primaryModel: "test/cheap",
          guardrails: { maxRetries: 2, timeoutMs: 5000 },
        },
      },
    });
    expect(JSON.parse(await readFile(filePath, "utf8"))).toEqual(await reloaded.read());
  });

  it("returns cloned memory overrides so callers cannot mutate store state", async () => {
    const store = new MemoryPolicyStore({
      task: { "slothing.resume_parse": { guardrails: { maxRetries: 1 } } },
    });
    const overrides = await store.read();

    overrides.task!["slothing.resume_parse"].guardrails!.maxRetries = 99;

    expect((await store.read()).task?.["slothing.resume_parse"].guardrails?.maxRetries).toBe(1);
  });

  it("merges base and persisted policy overrides", () => {
    expect(
      mergePolicyOverrides(
        { global: { guardrails: { timeoutMs: 1000 } } },
        { task: { "app.task": { primaryModel: "test/cheap" } } },
      ),
    ).toEqual({
      global: { guardrails: { timeoutMs: 1000 } },
      task: { "app.task": { primaryModel: "test/cheap" } },
    });
  });

  it("rejects invalid policy patches", () => {
    expect(() => validatePolicyOverride({ fallbacks: ["a", "a"] })).toThrow("duplicated");
    expect(() => validatePolicyOverride({ guardrails: { maxRetries: -1 } })).toThrow(
      "non-negative",
    );
  });

  it("supports callback-backed database policy storage", async () => {
    let stored = {};
    const store = new DatabasePolicyStore({
      async read() {
        return stored;
      },
      async write(overrides) {
        stored = overrides;
      },
    });

    await store.updateTaskPolicy("app.task", { primaryModel: "test/model" });

    expect(await store.read()).toEqual({ task: { "app.task": { primaryModel: "test/model" } } });
  });

  it("supports remote policy storage", async () => {
    let stored = {};
    const store = new RemotePolicyStore({
      baseUrl: "https://router.test",
      fetchImpl: async (input, init) => {
        if (String(input).endsWith("/policies") && init?.method === "PUT") {
          stored = JSON.parse(String(init.body));
          return new Response(null, { status: 204 });
        }
        return Response.json(stored);
      },
    });

    await store.updateTaskPolicy("app.task", { primaryModel: "test/model" });

    expect(stored).toEqual({ task: { "app.task": { primaryModel: "test/model" } } });
  });
});
