import { describe, expect, it } from "vitest";
import {
  BentoRouter,
  MemoryProviderConfigStore,
  MemoryUsageStore,
  MemoryPolicyStore,
  ModelRegistry,
  ProviderRegistry,
  TaskRegistry,
  createBentoRouterApi,
  createBentoRouterHttpHandler,
  createBentoRouterService,
  defineBentoTask,
  type BentoRouterAuditEvent,
  type EncryptionAdapter,
  type ProviderAdapter,
} from "../src/index.js";

function setup(
  apiOptions: Partial<Parameters<typeof createBentoRouterApi>[0]> = {},
) {
  const taskRegistry = new TaskRegistry();
  const modelRegistry = new ModelRegistry();
  const providerRegistry = new ProviderRegistry();
  const usageStore = new MemoryUsageStore();
  const policyStore = new MemoryPolicyStore();
  const policyOverrides = {};

  defineBentoTask(
    {
      id: "slothing.listing_description",
      appId: "slothing",
      name: "Listing Description",
      defaultPolicy: {
        primaryModel: "test/cheap",
        guardrails: { maxOutputTokens: 50, maxRequestCostUsd: 0.01 },
      },
    },
    taskRegistry,
  );

  modelRegistry.register({
    id: "test/cheap",
    provider: "test",
    displayName: "Test Cheap",
    inputCostPerMillionTokens: 0.1,
    outputCostPerMillionTokens: 0.2,
    maxContextTokens: 10000,
    qualityTier: "cheap",
    caps: { json: true, vision: false, tools: false, streaming: false },
  });

  const provider: ProviderAdapter = {
    id: "test",
    async complete() {
      return { text: "generated listing", inputTokens: 10, outputTokens: 4 };
    },
  };
  providerRegistry.register(provider);

  const router = new BentoRouter({
    taskRegistry,
    modelRegistry,
    providerRegistry,
    usageStore,
    policyStore,
    policyOverrides,
  });
  const api = createBentoRouterApi({
    router,
    taskRegistry,
    modelRegistry,
    providerRegistry,
    usageStore,
    policyStore,
    policyOverrides,
    ...apiOptions,
  });

  return createBentoRouterHttpHandler({ api });
}

describe("createBentoRouterHttpHandler", () => {
  it("lists tasks and updates policy over fetch-compatible requests", async () => {
    const handler = setup();

    const tasksResponse = await handler(new Request("https://app.test/api/bento-router/tasks"));
    expect(tasksResponse.status).toBe(200);
    const tasks = (await tasksResponse.json()) as Array<{ id: string }>;
    expect(tasks[0]?.id).toBe("slothing.listing_description");

    const updateResponse = await handler(
      new Request("https://app.test/api/bento-router/tasks/slothing.listing_description/policy", {
        method: "PUT",
        body: JSON.stringify({ guardrails: { timeoutMs: 5000 } }),
      }),
    );
    expect(updateResponse.status).toBe(200);
    const task = (await updateResponse.json()) as {
      effectivePolicy: { guardrails: { timeoutMs?: number } };
    };
    expect(task.effectivePolicy.guardrails.timeoutMs).toBe(5000);

    const manifestResponse = await handler(new Request("https://app.test/api/bento-router/manifest"));
    const manifest = (await manifestResponse.json()) as {
      tasks: Array<{ effectivePolicy: { guardrails: { timeoutMs?: number } } }>;
    };
    expect(manifest.tasks[0]?.effectivePolicy.guardrails.timeoutMs).toBe(5000);
  });

  it("runs protected task tests through the API surface", async () => {
    const handler = setup();
    const response = await handler(
      new Request("https://app.test/api/bento-router/tasks/slothing.listing_description/test", {
        method: "POST",
        body: JSON.stringify({ messages: [{ role: "user", content: "shirt" }] }),
      }),
    );

    expect(response.status).toBe(200);
    const result = (await response.json()) as { status: string; text: string };
    expect(result.status).toBe("success");
    expect(result.text).toBe("generated listing");
  });

  it("rejects policy updates for unknown models", async () => {
    const handler = setup();
    const response = await handler(
      new Request("https://app.test/api/bento-router/tasks/slothing.listing_description/policy", {
        method: "PUT",
        body: JSON.stringify({ primaryModel: "missing/model" }),
      }),
    );

    expect(response.status).toBe(500);
    expect(await response.json()).toMatchObject({
      message: "Unknown AI model: missing/model",
    });
  });

  it("blocks policy writes in read-only mode", async () => {
    const handler = setup({ readOnly: true });
    const response = await handler(
      new Request("https://app.test/api/bento-router/tasks/slothing.listing_description/policy", {
        method: "PUT",
        body: JSON.stringify({ guardrails: { timeoutMs: 5000 } }),
      }),
    );

    expect(response.status).toBe(500);
    expect(await response.json()).toMatchObject({
      message: "BentoRouter admin API is read-only",
    });
  });

  it("authorizes and audits policy writes", async () => {
    const auditEvents: BentoRouterAuditEvent[] = [];
    const operations: string[] = [];
    const handler = setup({
      authorize(operation) {
        operations.push(`${operation.type}:${operation.resource}`);
        return true;
      },
      audit(event) {
        auditEvents.push(event);
      },
    });

    const response = await handler(
      new Request("https://app.test/api/bento-router/tasks/slothing.listing_description/policy", {
        method: "PUT",
        body: JSON.stringify({ guardrails: { timeoutMs: 5000 } }),
      }),
    );

    expect(response.status).toBe(200);
    expect(operations).toContain("write:taskPolicy");
    expect(auditEvents).toHaveLength(1);
    expect(auditEvents[0]?.taskId).toBe("slothing.listing_description");
    expect(auditEvents[0]?.after?.guardrails?.timeoutMs).toBe(5000);
  });

  it("runs tasks through the shared HTTP control plane", async () => {
    const handler = setup();
    const response = await handler(
      new Request("https://app.test/api/bento-router/run", {
        method: "POST",
        body: JSON.stringify({
          task: "slothing.listing_description",
          messages: [{ role: "user", content: "shirt" }],
        }),
      }),
    );

    expect(response.status).toBe(200);
    const result = (await response.json()) as { status: string; text: string; model: string };
    expect(result.status).toBe("success");
    expect(result.text).toBe("generated listing");
    expect(result.model).toBe("test/cheap");
  });

  it("reports usage summaries and exports CSV", async () => {
    const handler = setup();
    await handler(
      new Request("https://app.test/api/bento-router/run", {
        method: "POST",
        body: JSON.stringify({
          task: "slothing.listing_description",
          messages: [{ role: "user", content: "shirt" }],
        }),
      }),
    );

    const reportResponse = await handler(
      new Request("https://app.test/api/bento-router/usage/report?groupBy=task"),
    );
    expect(reportResponse.status).toBe(200);
    const report = (await reportResponse.json()) as Array<{ key: string; successCount: number }>;
    expect(report[0]).toMatchObject({ key: "slothing.listing_description", successCount: 1 });

    const csvResponse = await handler(new Request("https://app.test/api/bento-router/usage/events.csv"));
    expect(csvResponse.headers.get("Content-Type")).toContain("text/csv");
    expect(await csvResponse.text()).toContain("slothing.listing_description");
  });

  it("exposes a manifest for embeddable provider pages", async () => {
    const handler = setup();
    const response = await handler(new Request("https://app.test/api/bento-router/manifest"));

    expect(response.status).toBe(200);
    const manifest = (await response.json()) as {
      apps: string[];
      tasks: Array<{ id: string; effectivePolicy: { primaryModel: string } }>;
      models: Array<{ id: string }>;
    };
    expect(manifest.apps).toEqual(["slothing"]);
    expect(manifest.tasks[0]?.id).toBe("slothing.listing_description");
    expect(manifest.tasks[0]?.effectivePolicy.primaryModel).toBe("test/cheap");
    expect(manifest.models[0]?.id).toBe("test/cheap");
  });

  it("performs configured provider CRUD with user isolation over HTTP", async () => {
    const encryption: EncryptionAdapter = {
      scheme: "test-v1",
      async encrypt(plaintext) {
        return `test-v1:${plaintext}`;
      },
      async decrypt(stored) {
        return stored.replace(/^test-v1:/, "");
      },
    };
    const providerConfigStore = new MemoryProviderConfigStore();
    const handler = setup({ providerConfigStore, encryption });

    const addResponse = await handler(
      new Request("https://app.test/api/bento-router/providers", {
        method: "POST",
        body: JSON.stringify({
          type: "openai",
          displayName: "Personal",
          apiKey: "sk-test",
          defaultModel: "openai/gpt-4.1-mini",
          userId: "user-a",
        }),
      }),
    );

    expect(addResponse.status).toBe(201);
    const created = (await addResponse.json()) as { id: string; encryptedApiKey: string };
    expect(created).toMatchObject({
      id: "openai-personal",
      encryptedApiKey: "test-v1:sk-test",
    });

    const userAResponse = await handler(
      new Request("https://app.test/api/bento-router/providers?userId=user-a"),
    );
    expect(await userAResponse.json()).toHaveLength(1);

    const userBResponse = await handler(
      new Request("https://app.test/api/bento-router/providers?userId=user-b"),
    );
    expect(await userBResponse.json()).toEqual([]);

    const updateResponse = await handler(
      new Request("https://app.test/api/bento-router/providers/openai-personal?userId=user-a", {
        method: "PUT",
        body: JSON.stringify({ displayName: "Renamed" }),
      }),
    );
    expect(updateResponse.status).toBe(200);
    expect(await updateResponse.json()).toMatchObject({ displayName: "Renamed" });

    const deleteResponse = await handler(
      new Request("https://app.test/api/bento-router/providers/openai-personal?userId=user-a", {
        method: "DELETE",
      }),
    );
    expect(deleteResponse.status).toBe(200);
    expect(await providerConfigStore.list("user-a")).toEqual([]);
  });

  it("validates providers without persisting them", async () => {
    const providerConfigStore = new MemoryProviderConfigStore();
    const handler = setup({
      providerConfigStore,
      fetchImpl: async (input, init) => {
        expect(String(input)).toBe("https://api.openai.com/v1/models");
        expect((init?.headers as Record<string, string>).Authorization).toBe("Bearer sk-test");
        return Response.json({ data: [{ id: "gpt-4.1-mini" }] });
      },
    });

    const response = await handler(
      new Request("https://app.test/api/bento-router/providers/validate", {
        method: "POST",
        body: JSON.stringify({ type: "openai", apiKey: "sk-test" }),
      }),
    );

    expect(response.status).toBe(200);
    expect(await response.json()).toMatchObject({
      ok: true,
      modelsAvailable: ["gpt-4.1-mini"],
    });
    expect(await providerConfigStore.listAll()).toEqual([]);
  });

  it("exposes service health and can run as a Node HTTP service", async () => {
    const handler = setup();
    const health = await handler(new Request("https://app.test/api/bento-router/health"));
    expect(health.status).toBe(200);
    expect(await health.json()).toMatchObject({ ok: true, providers: [{ id: "test" }] });

    const service = createBentoRouterService({ handler });
    try {
      const url = await service.start();
      const response = await fetch(`${url}/api/bento-router/health`);
      expect(response.status).toBe(200);
      expect(await response.json()).toMatchObject({ ok: true });
    } finally {
      await service.stop();
    }
  });
});
