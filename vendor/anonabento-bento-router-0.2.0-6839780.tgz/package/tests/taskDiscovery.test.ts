import { describe, expect, it } from "vitest";
import { TaskRegistry, defineBentoTask, discoverBentoTasks, generateTaskIdTypes } from "../src/index.js";

describe("task discovery", () => {
  it("summarizes tasks and generates task ID types", () => {
    const registry = new TaskRegistry();
    defineBentoTask(
      {
        id: "app.one",
        appId: "app",
        name: "One",
        defaultPolicy: { primaryModel: "test/model" },
      },
      registry,
    );
    defineBentoTask(
      {
        id: "other.two",
        appId: "other",
        name: "Two",
        defaultPolicy: { primaryModel: "test/model" },
      },
      registry,
    );

    expect(discoverBentoTasks(registry)).toEqual({
      apps: ["app", "other"],
      taskIds: ["app.one", "other.two"],
      tasksByApp: { app: ["app.one"], other: ["other.two"] },
    });
    expect(generateTaskIdTypes(registry)).toContain('"app.one"');
  });
});
