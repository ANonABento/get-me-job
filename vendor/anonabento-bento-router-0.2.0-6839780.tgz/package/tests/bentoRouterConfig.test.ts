import { describe, expect, it } from "vitest";
import { createBentoRouterRuntimeFromConfig } from "../src/index.js";

describe("BentoRouter config runtime", () => {
  it("builds registries, API, and service handler from config", async () => {
    const runtime = createBentoRouterRuntimeFromConfig(
      {
        providers: [{ id: "openrouter", type: "openrouter" }],
        models: [
          {
            id: "test/model",
            provider: "openrouter",
            displayName: "Test Model",
            inputCostPerMillionTokens: 1,
            outputCostPerMillionTokens: 2,
            maxContextTokens: 1000,
            qualityTier: "standard",
            caps: { json: true, vision: false, tools: false, streaming: false },
          },
        ],
        tasks: [
          {
            id: "app.task",
            appId: "app",
            name: "Task",
            defaultPolicy: {
              primaryModel: "test/model",
              guardrails: { maxOutputTokens: 20 },
            },
          },
        ],
        usage: { type: "memory" },
        policies: { type: "memory" },
      },
      { OPENROUTER_API_KEY: "test-key" },
    );

    expect(runtime.taskRegistry.require("app.task").name).toBe("Task");
    expect(runtime.modelRegistry.require("test/model").displayName).toBe("Test Model");
    expect(runtime.providerRegistry.require("openrouter").id).toBe("openrouter");

    const manifest = await runtime.api.manifest();
    expect(manifest).toMatchObject({ apps: ["app"] });
  });
});
