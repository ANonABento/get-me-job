import { describe, expect, it } from "vitest";
import {
  BentoRouter,
  CircuitBreaker,
  MemoryUsageStore,
  ModelRegistry,
  ProviderRegistry,
  TaskRegistry,
  defineBentoTask,
  resolvePolicy,
  type ProviderAdapter,
  type ProviderResponse,
} from "../src/index.js";

function createModelRegistry(): ModelRegistry {
  const registry = new ModelRegistry();
  registry.register({
    id: "test/premium",
    provider: "test-premium",
    displayName: "Test Premium",
    inputCostPerMillionTokens: 10,
    outputCostPerMillionTokens: 30,
    maxContextTokens: 10000,
    qualityTier: "premium",
    caps: { json: true, vision: false, tools: false, streaming: false },
  });
  registry.register({
    id: "test/cheap",
    provider: "test-cheap",
    displayName: "Test Cheap",
    inputCostPerMillionTokens: 0.1,
    outputCostPerMillionTokens: 0.2,
    maxContextTokens: 10000,
    qualityTier: "cheap",
    caps: { json: true, vision: false, tools: false, streaming: false },
  });
  registry.register({
    id: "test/vision",
    provider: "test-cheap",
    displayName: "Test Vision",
    inputCostPerMillionTokens: 0.2,
    outputCostPerMillionTokens: 0.4,
    maxContextTokens: 10000,
    qualityTier: "cheap",
    caps: { json: true, vision: true, tools: false, streaming: false },
  });
  return registry;
}

function createTaskRegistry(): TaskRegistry {
  const registry = new TaskRegistry();
  defineBentoTask(
    {
      id: "tomodachi.chat_reply",
      appId: "tomodachi",
      name: "Character Chat Reply",
      prompt: { id: "chat-reply", version: "v1" },
      defaultPolicy: {
        primaryModel: "test/premium",
        fallbacks: ["test/cheap"],
        guardrails: {
          maxInputTokens: 1000,
          maxOutputTokens: 100,
          maxRetries: 0,
          maxRequestCostUsd: 1,
        },
        budget: {
          dailyAppBudgetUsd: 5,
        },
        circuitBreaker: {
          failureThreshold: 1,
          cooldownMs: 10000,
        },
        degradation: {
          mode: "short_response",
          message: "Limited mode.",
        },
      },
    },
    registry,
  );
  return registry;
}

function provider(id: string, handler: () => ProviderResponse | Promise<ProviderResponse>): ProviderAdapter {
  return {
    id,
    async complete() {
      return handler();
    },
  };
}

function createRouter(options: {
  premium?: ProviderAdapter;
  cheap?: ProviderAdapter;
  usageStore?: MemoryUsageStore;
  circuitBreaker?: CircuitBreaker;
  policyOverrides?: ConstructorParameters<typeof BentoRouter>[0]["policyOverrides"];
  random?: () => number;
  redactUsageEvent?: ConstructorParameters<typeof BentoRouter>[0]["redactUsageEvent"];
  outputValidators?: ConstructorParameters<typeof BentoRouter>[0]["outputValidators"];
  responseCache?: ConstructorParameters<typeof BentoRouter>[0]["responseCache"];
} = {}): BentoRouter {
  const providers = new ProviderRegistry();
  providers.register(options.premium ?? provider("test-premium", () => ({ text: "premium ok", inputTokens: 20, outputTokens: 5 })));
  providers.register(options.cheap ?? provider("test-cheap", () => ({ text: "cheap ok", inputTokens: 20, outputTokens: 5 })));

  return new BentoRouter({
    taskRegistry: createTaskRegistry(),
    modelRegistry: createModelRegistry(),
    providerRegistry: providers,
    usageStore: options.usageStore,
    circuitBreaker: options.circuitBreaker,
    policyOverrides: options.policyOverrides,
    random: options.random,
    redactUsageEvent: options.redactUsageEvent,
    outputValidators: options.outputValidators,
    responseCache: options.responseCache,
  });
}

describe("BentoRouter router", () => {
  it("resolves task policy overrides after defaults", () => {
    const task = createTaskRegistry().require("tomodachi.chat_reply");
    const policy = resolvePolicy(task, {
      app: {
        tomodachi: {
          guardrails: { timeoutMs: 5000 },
        },
      },
      task: {
        "tomodachi.chat_reply": {
          primaryModel: "test/cheap",
          guardrails: { maxRetries: 2 },
        },
      },
    });

    expect(policy.primaryModel).toBe("test/cheap");
    expect(policy.guardrails?.timeoutMs).toBe(5000);
    expect(policy.guardrails?.maxRetries).toBe(2);
    expect(policy.guardrails?.maxInputTokens).toBe(1000);
  });

  it("uses fallback when the primary provider fails", async () => {
    const usageStore = new MemoryUsageStore();
    const router = createRouter({
      usageStore,
      premium: provider("test-premium", () => {
        throw new Error("provider down");
      }),
    });

    const result = await router.run({
      task: "tomodachi.chat_reply",
      messages: [{ role: "user", content: "hello" }],
    });

    expect(result.status).toBe("degraded");
    expect(result.model).toBe("test/cheap");
    expect(result.text).toBe("cheap ok");
    expect(result.attempts.map((attempt) => attempt.status)).toEqual(["failure", "success"]);
    expect((await usageStore.list()).length).toBe(2);
  });

  it("blocks over-budget primary models and continues to cheaper fallback", async () => {
    const router = createRouter({
      policyOverrides: {
        task: {
          "tomodachi.chat_reply": {
            guardrails: { maxRequestCostUsd: 0.0001, maxOutputTokens: 100 },
          },
        },
      },
    });

    const result = await router.run({
      task: "tomodachi.chat_reply",
      messages: [{ role: "user", content: "hello" }],
    });

    expect(result.status).toBe("degraded");
    expect(result.model).toBe("test/cheap");
    expect(result.attempts[0].status).toBe("blocked");
    expect(result.attempts[0].errorCode).toBe("request_cost_ceiling");
  });

  it("skips a model when its circuit breaker is open", async () => {
    const circuitBreaker = new CircuitBreaker();
    const usageStore = new MemoryUsageStore();
    const failingRouter = createRouter({
      usageStore,
      circuitBreaker,
      premium: provider("test-premium", () => {
        throw new Error("first failure");
      }),
    });

    await failingRouter.run({
      task: "tomodachi.chat_reply",
      messages: [{ role: "user", content: "open circuit" }],
    });

    const fallbackRouter = createRouter({ usageStore, circuitBreaker });
    const result = await fallbackRouter.run({
      task: "tomodachi.chat_reply",
      messages: [{ role: "user", content: "second call" }],
    });

    expect(result.model).toBe("test/cheap");
    expect(result.attempts[0].status).toBe("skipped");
    expect(result.attempts[0].errorCode).toBe("circuit_open");
  });

  it("degrades without provider calls when daily app budget is exhausted", async () => {
    const usageStore = new MemoryUsageStore();
    await usageStore.record({
      id: "existing",
      timestamp: new Date().toISOString(),
      appId: "tomodachi",
      taskId: "tomodachi.chat_reply",
      requestId: "previous",
      status: "success",
      fallbackIndex: 0,
      inputTokensEstimated: 10,
      estimatedCostUsd: 5,
      actualCostUsd: 5,
      latencyMs: 10,
    });

    const router = createRouter({ usageStore });
    const result = await router.run({
      task: "tomodachi.chat_reply",
      messages: [{ role: "user", content: "budget?" }],
    });

    expect(result.status).toBe("degraded");
    expect(result.text).toBe("Limited mode.");
    expect(result.reason).toBe("daily_app_budget");
    expect(result.attempts[0].status).toBe("degraded");
  });

  it("returns a degraded response when every provider fails", async () => {
    const router = createRouter({
      premium: provider("test-premium", () => {
        throw new Error("premium down");
      }),
      cheap: provider("test-cheap", () => {
        throw new Error("cheap down");
      }),
    });

    const result = await router.run({
      task: "tomodachi.chat_reply",
      messages: [{ role: "user", content: "hello" }],
    });

    expect(result.status).toBe("degraded");
    expect(result.text).toBe("Limited mode.");
    expect(result.reason).toBe("all_models_unavailable");
  });

  it("skips models that do not satisfy task feature requirements", async () => {
    const router = createRouter({
      policyOverrides: {
        task: {
          "tomodachi.chat_reply": {
            primaryModel: "test/cheap",
            fallbacks: ["test/vision"],
            modelRequirements: {
              caps: { vision: true },
            },
          },
        },
      },
    });

    const result = await router.run({
      task: "tomodachi.chat_reply",
      messages: [{ role: "user", content: "describe this image" }],
    });

    expect(result.status).toBe("degraded");
    expect(result.model).toBe("test/vision");
    expect(result.attempts[0]?.status).toBe("skipped");
    expect(result.attempts[0]?.errorCode).toBe("model_vision_unsupported");
  });

  it("routes canary traffic to a configured model", async () => {
    const router = createRouter({
      random: () => 0.1,
      policyOverrides: {
        task: {
          "tomodachi.chat_reply": {
            routing: {
              canary: { model: "test/cheap", percentage: 0.2 },
            },
          },
        },
      },
    });

    const result = await router.run({
      task: "tomodachi.chat_reply",
      messages: [{ role: "user", content: "hello" }],
    });

    expect(result.model).toBe("test/cheap");
  });

  it("uses weighted routing to pick the first attempted model", async () => {
    const router = createRouter({
      random: () => 0.99,
      policyOverrides: {
        task: {
          "tomodachi.chat_reply": {
            routing: {
              weights: {
                "test/premium": 1,
                "test/cheap": 99,
              },
            },
          },
        },
      },
    });

    const result = await router.run({
      task: "tomodachi.chat_reply",
      messages: [{ role: "user", content: "hello" }],
    });

    expect(result.model).toBe("test/cheap");
  });

  it("blocks requests when a task rate limit is exceeded", async () => {
    const router = createRouter({
      policyOverrides: {
        task: {
          "tomodachi.chat_reply": {
            routing: {
              rateLimit: { maxRequests: 1, windowMs: 60000 },
            },
          },
        },
      },
    });

    await router.run({
      task: "tomodachi.chat_reply",
      messages: [{ role: "user", content: "first" }],
    });
    const result = await router.run({
      task: "tomodachi.chat_reply",
      messages: [{ role: "user", content: "second" }],
    });

    expect(result.status).toBe("degraded");
    expect(result.reason).toBe("task_rate_limited");
  });

  it("skips providers when concurrency limits are reached", async () => {
    let release: (() => void) | undefined;
    const firstProvider = provider(
      "test-premium",
      () =>
        new Promise<ProviderResponse>((resolve) => {
          release = () => resolve({ text: "premium ok", inputTokens: 20, outputTokens: 5 });
        }),
    );
    const router = createRouter({
      premium: firstProvider,
      policyOverrides: {
        task: {
          "tomodachi.chat_reply": {
            fallbacks: [],
            routing: {
              maxConcurrentProviderRequests: 1,
            },
            degradation: {
              mode: "short_response",
              message: "busy",
            },
          },
        },
      },
    });

    const first = router.run({
      task: "tomodachi.chat_reply",
      messages: [{ role: "user", content: "hold" }],
    });
    const second = await router.run({
      task: "tomodachi.chat_reply",
      messages: [{ role: "user", content: "blocked" }],
    });
    release?.();
    await first;

    expect(second.status).toBe("degraded");
    expect(second.attempts[0]?.errorCode).toBe("provider_concurrency_limited");
  });

  it("tracks prompt versions and redacts usage events", async () => {
    const usageStore = new MemoryUsageStore();
    const router = createRouter({
      usageStore,
      redactUsageEvent(event) {
        return { ...event, userId: event.userId ? "redacted" : undefined };
      },
    });

    await router.run({
      task: "tomodachi.chat_reply",
      userId: "user-1",
      messages: [{ role: "user", content: "hello" }],
    });

    const [event] = await usageStore.list();
    expect(event.userId).toBe("redacted");
    expect(event.promptId).toBe("chat-reply");
    expect(event.promptVersion).toBe("v1");
  });

  it("treats invalid output as a provider failure and uses fallback", async () => {
    const router = createRouter({
      premium: provider("test-premium", () => ({ text: "bad", inputTokens: 20, outputTokens: 5 })),
      outputValidators: {
        "tomodachi.chat_reply": ({ text }) => text === "bad" ? "bad output" : true,
      },
    });

    const result = await router.run({
      task: "tomodachi.chat_reply",
      messages: [{ role: "user", content: "hello" }],
    });

    expect(result.model).toBe("test/cheap");
    expect(result.attempts[0]?.status).toBe("failure");
    expect(result.attempts[0]?.errorMessage).toBe("bad output");
  });

  it("uses cached fallback responses when available", async () => {
    const cache = new Map<string, string>([["tomodachi.chat_reply:user-1", "cached ok"]]);
    const router = createRouter({
      premium: provider("test-premium", () => {
        throw new Error("down");
      }),
      cheap: provider("test-cheap", () => {
        throw new Error("down");
      }),
      policyOverrides: {
        task: {
          "tomodachi.chat_reply": {
            degradation: { mode: "cached_response" },
          },
        },
      },
      responseCache: {
        get(taskId, userId) {
          return cache.get(`${taskId}:${userId}`);
        },
        set(taskId, text, userId) {
          cache.set(`${taskId}:${userId}`, text);
        },
      },
    });

    const result = await router.run({
      task: "tomodachi.chat_reply",
      userId: "user-1",
      messages: [{ role: "user", content: "hello" }],
    });

    expect(result.text).toBe("cached ok");
    expect(result.status).toBe("degraded");
  });

  it("falls back to a single streamed chunk when provider streaming is unavailable", async () => {
    const router = createRouter();
    const chunks = [];

    for await (const chunk of router.stream({
      task: "tomodachi.chat_reply",
      messages: [{ role: "user", content: "hello" }],
    })) {
      chunks.push(chunk);
    }

    expect(chunks).toEqual([{ text: "premium ok", raw: undefined }]);
  });

  it("uses provider token counters when available", async () => {
    const usageStore = new MemoryUsageStore();
    const providers = new ProviderRegistry();
    providers.register({
      id: "test-premium",
      async complete() {
        return { text: "premium ok", outputTokens: 5 };
      },
      countTokens() {
        return 42;
      },
    });
    providers.register(provider("test-cheap", () => ({ text: "cheap ok" })));

    const router = new BentoRouter({
      taskRegistry: createTaskRegistry(),
      modelRegistry: createModelRegistry(),
      providerRegistry: providers,
      usageStore,
    });

    await router.run({
      task: "tomodachi.chat_reply",
      messages: [{ role: "user", content: "hello" }],
    });

    expect((await usageStore.list())[0]?.inputTokensEstimated).toBe(42);
  });

  it("runs embedding tasks through providers that support embeddings", async () => {
    const providers = new ProviderRegistry();
    providers.register({
      id: "test-premium",
      async complete() {
        return { text: "" };
      },
      async embed() {
        return { embeddings: [[0.1, 0.2]], inputTokens: 3 };
      },
    });
    providers.register(provider("test-cheap", () => ({ text: "cheap ok" })));

    const router = new BentoRouter({
      taskRegistry: createTaskRegistry(),
      modelRegistry: createModelRegistry(),
      providerRegistry: providers,
    });

    const result = await router.embed({
      task: "tomodachi.chat_reply",
      input: "hello",
    });

    expect(result.status).toBe("success");
    expect(result.embeddings).toEqual([[0.1, 0.2]]);
  });

  it("blocks premium models that require approval", async () => {
    const router = createRouter({
      policyOverrides: {
        task: {
          "tomodachi.chat_reply": {
            approval: {
              requireForQualityTiers: ["premium"],
              approved: false,
            },
          },
        },
      },
    });

    const result = await router.run({
      task: "tomodachi.chat_reply",
      messages: [{ role: "user", content: "hello" }],
    });

    expect(result.model).toBe("test/cheap");
    expect(result.attempts[0]?.errorCode).toBe("model_approval_required");
  });

  it("tracks org/project/environment usage and enforces org budgets", async () => {
    const usageStore = new MemoryUsageStore();
    await usageStore.record({
      id: "existing",
      timestamp: new Date().toISOString(),
      appId: "tomodachi",
      taskId: "tomodachi.chat_reply",
      orgId: "org-1",
      projectId: "proj-1",
      environment: "prod",
      requestId: "previous",
      status: "success",
      fallbackIndex: 0,
      inputTokensEstimated: 10,
      estimatedCostUsd: 5,
      actualCostUsd: 5,
      latencyMs: 10,
    });
    const router = createRouter({
      usageStore,
      policyOverrides: {
        task: {
          "tomodachi.chat_reply": {
            budget: { dailyAppBudgetUsd: 100, dailyOrgBudgetUsd: 5 },
          },
        },
      },
    });

    const result = await router.run({
      task: "tomodachi.chat_reply",
      orgId: "org-1",
      projectId: "proj-1",
      environment: "prod",
      messages: [{ role: "user", content: "hello" }],
    });

    expect(result.reason).toBe("daily_org_budget");
    expect((await usageStore.list({ orgId: "org-1" })).length).toBe(2);
    expect((await usageStore.list()).at(-1)?.environment).toBe("prod");
  });
});
