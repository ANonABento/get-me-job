import { describe, expect, it } from "vitest";
import { migrateLegacyLLMConfig } from "../src/index.js";

describe("migrateLegacyLLMConfig", () => {
  it("maps OpenAI legacy config into provider input and task policies", () => {
    expect(
      migrateLegacyLLMConfig(
        { provider: "openai", apiKey: "sk-test", model: "gpt-4.1-mini" },
        { userId: "default", taskIds: ["a", "b"], displayName: "Personal" },
      ),
    ).toEqual({
      provider: {
        type: "openai",
        displayName: "Personal",
        apiKey: "sk-test",
        baseUrl: undefined,
        defaultModel: "openai/gpt-4.1-mini",
        userId: "default",
      },
      taskPolicies: {
        a: { primaryModel: "openai/gpt-4.1-mini" },
        b: { primaryModel: "openai/gpt-4.1-mini" },
      },
    });
  });

  it("maps Anthropic, OpenRouter, and Ollama model ids", () => {
    expect(
      migrateLegacyLLMConfig(
        { provider: "anthropic", apiKey: "test", model: "claude-3-5-sonnet" },
        { userId: "default", taskIds: ["task"] },
      ).taskPolicies.task,
    ).toEqual({ primaryModel: "anthropic/claude-3-5-sonnet" });

    expect(
      migrateLegacyLLMConfig(
        { provider: "openrouter", apiKey: "test", model: "openai/gpt-4.1-mini" },
        { userId: "default", taskIds: ["task"] },
      ).taskPolicies.task,
    ).toEqual({ primaryModel: "openai/gpt-4.1-mini" });

    expect(
      migrateLegacyLLMConfig(
        { provider: "ollama", apiKey: "local", model: "llama3" },
        { userId: "default", taskIds: ["task"] },
      ).provider,
    ).toMatchObject({
      type: "openai-compatible",
      baseUrl: "http://localhost:11434",
      defaultModel: "local/llama3",
    });
  });

  it("omits provider registration when the legacy apiKey is missing", () => {
    expect(
      migrateLegacyLLMConfig(
        { provider: "openai", model: "gpt-4.1-mini" },
        { userId: "default", taskIds: ["task"] },
      ),
    ).toEqual({
      taskPolicies: {
        task: { primaryModel: "openai/gpt-4.1-mini" },
      },
    });
  });
});
