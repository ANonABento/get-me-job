import { describe, expect, it } from "vitest";
import {
  calculateBudgetRemaining,
  detectSpendAnomalies,
  groupUsage,
  usageEventsToCsv,
  type UsageEvent,
} from "../src/index.js";

const events: UsageEvent[] = [
  {
    id: "1",
    timestamp: "2026-05-08T10:00:00.000Z",
    appId: "slothing",
    taskId: "slothing.resume_parse",
    userId: "u1",
    requestId: "r1",
    provider: "openai",
    model: "openai/gpt-4.1-mini",
    status: "success",
    fallbackIndex: 0,
    inputTokensEstimated: 100,
    estimatedCostUsd: 0.01,
    actualCostUsd: 0.02,
    latencyMs: 100,
  },
  {
    id: "2",
    timestamp: "2026-05-08T10:01:00.000Z",
    appId: "slothing",
    taskId: "slothing.resume_parse",
    userId: "u1",
    requestId: "r2",
    provider: "openai",
    model: "openai/gpt-4.1-mini",
    status: "failure",
    fallbackIndex: 0,
    inputTokensEstimated: 100,
    estimatedCostUsd: 0.01,
    latencyMs: 300,
  },
  {
    id: "3",
    timestamp: "2026-05-08T10:01:01.000Z",
    appId: "slothing",
    taskId: "slothing.company_research",
    userId: "u2",
    requestId: "r2",
    provider: "anthropic",
    model: "anthropic/claude-3.5-sonnet",
    status: "success",
    fallbackIndex: 1,
    inputTokensEstimated: 100,
    estimatedCostUsd: 0.03,
    latencyMs: 500,
  },
];

describe("usage reporting", () => {
  it("groups usage and calculates rates and latency percentiles", () => {
    const [company, resume] = groupUsage(events, "task");

    expect(company.key).toBe("slothing.company_research");
    expect(company.fallbackRate).toBe(1);
    expect(resume.key).toBe("slothing.resume_parse");
    expect(resume.failureRate).toBe(0.5);
    expect(resume.latencyP95Ms).toBe(300);
  });

  it("calculates budget remaining", () => {
    expect(
      calculateBudgetRemaining(
        { dailyAppBudgetUsd: 1, dailyTaskBudgetUsd: 0.5 },
        { app: { requestCount: 1, successCount: 1, failureCount: 0, blockedCount: 0, estimatedCostUsd: 0, actualCostUsd: 0.25 } },
      ),
    ).toMatchObject({ appRemainingUsd: 0.75, taskRemainingUsd: 0.5 });
  });

  it("exports usage events as CSV", () => {
    const csv = usageEventsToCsv(events);

    expect(csv.split("\n")[0]).toContain("id,timestamp,appId");
    expect(csv).toContain("slothing.resume_parse");
  });

  it("detects spend anomalies", () => {
    const anomalies = detectSpendAnomalies(
      [
        { ...events[0], id: "old", timestamp: "2026-05-07T10:00:00.000Z", actualCostUsd: 1 },
        { ...events[0], id: "new", timestamp: "2026-05-08T10:00:00.000Z", actualCostUsd: 4 },
      ],
      {
        baselineUntil: new Date("2026-05-08T00:00:00.000Z"),
        recentSince: new Date("2026-05-08T00:00:00.000Z"),
        multiplier: 3,
      },
    );

    expect(anomalies).toEqual([
      { key: "slothing", baselineCostUsd: 1, recentCostUsd: 4, multiplier: 4 },
    ]);
  });
});
