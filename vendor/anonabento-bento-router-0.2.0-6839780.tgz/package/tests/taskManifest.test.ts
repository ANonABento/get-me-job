import { describe, expect, it } from "vitest";
import {
  ModelRegistry,
  TaskRegistry,
  createBentoTaskManifest,
  defineBentoTask,
} from "../src/index.js";

describe("createBentoTaskManifest", () => {
  it("exports registered tasks with effective policies and model metadata", () => {
    const taskRegistry = new TaskRegistry();
    const modelRegistry = new ModelRegistry();

    modelRegistry.register({
      id: "test/model",
      provider: "test",
      displayName: "Test Model",
      inputCostPerMillionTokens: 1,
      outputCostPerMillionTokens: 2,
      maxContextTokens: 1000,
      qualityTier: "cheap",
      caps: { json: true, vision: false, tools: false, streaming: false },
    });

    defineBentoTask(
      {
        id: "tomodachi.memory_summary",
        appId: "tomodachi",
        name: "Memory Summary",
        category: "Memory",
        defaultPolicy: {
          primaryModel: "test/model",
          guardrails: { maxOutputTokens: 200 },
        },
      },
      taskRegistry,
    );

    const manifest = createBentoTaskManifest({
      taskRegistry,
      modelRegistry,
      generatedAt: new Date("2026-05-08T00:00:00.000Z"),
      policyOverrides: {
        task: {
          "tomodachi.memory_summary": {
            guardrails: { maxRequestCostUsd: 0.01 },
          },
        },
      },
    });

    expect(manifest.version).toBe(1);
    expect(manifest.generatedAt).toBe("2026-05-08T00:00:00.000Z");
    expect(manifest.apps).toEqual(["tomodachi"]);
    expect(manifest.models?.[0]?.id).toBe("test/model");
    expect(manifest.tasks[0]).toMatchObject({
      id: "tomodachi.memory_summary",
      appId: "tomodachi",
      name: "Memory Summary",
      category: "Memory",
      effectivePolicy: {
        primaryModel: "test/model",
        guardrails: {
          maxOutputTokens: 200,
          maxRequestCostUsd: 0.01,
        },
      },
    });
  });
});
