import { describe, expect, it } from "vitest";
import {
  createAnthropicProvider,
  createOpenAICompatibleProvider,
  createOpenAIProvider,
} from "../src/index.js";

describe("direct provider adapters", () => {
  it("maps OpenAI chat completion responses into provider responses", async () => {
    const provider = createOpenAIProvider({
      apiKey: "test",
      fetchImpl: async (_input, init) => {
        expect(JSON.parse(String(init?.body)).model).toBe("gpt-4o-mini");
        return Response.json({
          choices: [{ message: { content: "hello" } }],
          usage: { prompt_tokens: 3, completion_tokens: 2 },
        });
      },
    });

    const result = await provider.complete({
      model: "openai/gpt-4o-mini",
      messages: [{ role: "user", content: "hi" }],
    });

    expect(result).toMatchObject({ text: "hello", inputTokens: 3, outputTokens: 2 });
  });

  it("maps Anthropic message responses into provider responses", async () => {
    const provider = createAnthropicProvider({
      apiKey: "test",
      fetchImpl: async (_input, init) => {
        const body = JSON.parse(String(init?.body));
        expect(body.model).toBe("claude-3-haiku");
        expect(body.system).toBe("be kind");
        return Response.json({
          content: [{ text: "hello" }],
          usage: { input_tokens: 5, output_tokens: 4 },
        });
      },
    });

    const result = await provider.complete({
      model: "anthropic/claude-3-haiku",
      messages: [
        { role: "system", content: "be kind" },
        { role: "user", content: "hi" },
      ],
    });

    expect(result).toMatchObject({ text: "hello", inputTokens: 5, outputTokens: 4 });
  });

  it("supports OpenAI-compatible local and hosted APIs", async () => {
    const provider = createOpenAICompatibleProvider({
      id: "local",
      baseUrl: "http://localhost:1234/v1/",
      fetchImpl: async (input, init) => {
        expect(String(input)).toBe("http://localhost:1234/v1/chat/completions");
        const body = JSON.parse(String(init?.body));
        expect(body.model).toBe("llama");
        return Response.json({
          choices: [{ message: { content: "local ok" } }],
          usage: { prompt_tokens: 1, completion_tokens: 2 },
        });
      },
    });

    const result = await provider.complete({
      model: "local/llama",
      messages: [{ role: "user", content: "hi" }],
    });

    expect(result).toMatchObject({ text: "local ok", inputTokens: 1, outputTokens: 2 });
  });
});
