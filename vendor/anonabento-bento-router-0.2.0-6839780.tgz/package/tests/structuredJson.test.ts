import { describe, expect, it } from "vitest";
import {
  BentoRouter,
  ModelRegistry,
  ProviderRegistry,
  TaskRegistry,
  defineBentoTask,
  runBentoJsonTask,
  type ProviderAdapter,
} from "../src/index.js";

describe("structured JSON helper", () => {
  it("retries when a provider returns invalid JSON", async () => {
    const taskRegistry = new TaskRegistry();
    defineBentoTask(
      {
        id: "app.json",
        appId: "app",
        name: "JSON Task",
        defaultPolicy: {
          primaryModel: "test/json",
          guardrails: { maxRetries: 0 },
        },
      },
      taskRegistry,
    );

    const modelRegistry = new ModelRegistry();
    modelRegistry.register({
      id: "test/json",
      provider: "test",
      displayName: "JSON",
      inputCostPerMillionTokens: 1,
      outputCostPerMillionTokens: 1,
      maxContextTokens: 10000,
      qualityTier: "cheap",
      caps: { json: true, vision: false, tools: false, streaming: false },
    });

    let calls = 0;
    const provider: ProviderAdapter = {
      id: "test",
      async complete() {
        calls += 1;
        return { text: calls === 1 ? "not json" : "{\"ok\":true}" };
      },
    };
    const providerRegistry = new ProviderRegistry();
    providerRegistry.register(provider);
    const router = new BentoRouter({ taskRegistry, modelRegistry, providerRegistry });

    const result = await runBentoJsonTask<{ ok: true }>({
      router,
      input: { task: "app.json", messages: [{ role: "user", content: "json" }] },
      validate(value): value is { ok: true } {
        return typeof value === "object" && value !== null && (value as { ok?: unknown }).ok === true;
      },
    });

    expect(result).toEqual({ ok: true });
    expect(calls).toBe(2);
  });
});
