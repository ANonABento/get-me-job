# BentoRouter TODOs

This is the working roadmap for turning BentoRouter from a reusable routing package into the shared AI control plane for ANonABento apps.

## P0 - Make Integrations Portable

- [x] Replace local `file:../bento-router` consumers with `@anonabento/bento-router` from GitHub or a package registry.
- [x] Add a migration note for apps that currently import a local package path.
- [x] Add a minimal Next.js route example that mounts `createBentoRouterHttpHandler`.
- [x] Add a minimal Flask/Python client example for `POST /api/bento-router/run`.
- [x] Decide whether the repo should publish to npm, GitHub Packages, or remain GitHub-install-only for now.

## P1 - Policy Persistence And Admin Safety

- [x] Persist task policy overrides instead of keeping them in memory.
- [x] Add a `PolicyStore` interface with memory and JSON-file adapters.
- [x] Add admin auth hooks for read/write operations.
- [x] Add read-only mode for provider pages embedded in apps.
- [x] Add audit events for policy changes: who changed what, before/after, and when.
- [x] Validate policy updates before accepting them, including unknown model IDs, duplicate fallbacks, and impossible budgets.
- [x] Add database and remote `PolicyStore` adapters.

## P1 - Service Mode

- [x] Add a small standalone HTTP server entrypoint.
- [x] Support loading tasks, providers, models, budgets, and policies from config files.
- [x] Add Dockerfile or deploy notes for running BentoRouter as a central service.
- [x] Add health endpoints for provider availability.
- [x] Add circuit breaker state to service health.
- [x] Add service-to-app compatibility docs for non-TypeScript apps.

## P1 - Better Usage Reporting

- [x] Add cost summary by app, task, provider, model, user, and day.
- [x] Add fallback-rate and failure-rate reporting.
- [x] Add latency percentiles.
- [x] Add budget remaining calculations.
- [x] Add CSV/JSON export for usage events.
- [x] Add dashboard props/components for usage charts without forcing a visual theme.

## P1 - Routing Features

- [x] Add task feature requirements: JSON, vision, tools, streaming, long-context, embeddings.
- [x] Filter model candidates by feature caps before cost/health checks.
- [x] Add quality tiers per task, such as cheap, standard, premium, and emergency.
- [x] Add canary routing percentages for trying new models safely.
- [x] Add weighted routing for A/B model comparison.
- [x] Add per-provider concurrency limits.
- [x] Add per-task rate limits.

## P2 - Provider Surface

- [x] Add first-class streaming support.
- [x] Add structured JSON mode helpers with validation and retry-on-invalid-output.
- [x] Add tool/function-call support.
- [x] Add embedding task support.
- [x] Add image/vision task support.
- [x] Add provider-specific token counting where available.
- [x] Add OpenAI-compatible provider adapter for local and hosted compatible APIs.

## P2 - Prompt And Output Governance

- [x] Add prompt template metadata per task.
- [x] Track prompt version in usage events.
- [x] Add redaction hooks before usage logging.
- [x] Add output validators per task.
- [x] Add cached fallback responses for tasks that can safely reuse previous output.
- [x] Add quality checks for high-risk tasks before returning output.

## P2 - Developer Experience

- [x] Add task discovery helpers for scanning app task definitions.
- [x] Add CLI commands:
  - `bento-router tasks`
  - `bento-router test <task-id>`
  - `bento-router usage`
  - `bento-router doctor`
- [x] Add generated TypeScript types for known task IDs.
- [x] Add richer examples for slothing and TomodachiAI.
- [x] Add release workflow and changelog.

## P3 - Multi-Tenant Controls

- [x] Add org/project/environment dimensions to policies and usage events.
- [x] Add per-customer budget policies.
- [x] Add per-user runtime provider key scoping for BYOK apps.
- [x] Add approval workflows for premium models.
- [x] Add spend anomaly detection and alert hooks.

## 0.2.0 - BYOK Runtime Provider Management

- [x] Move the BYOK provider management spec into `docs/byok-provider-management-spec.md`.
- [x] Add `ProviderConfigStore` with memory and JSON-file adapters.
- [x] Add `EncryptionAdapter` hooks with plaintext local-development warning.
- [x] Add runtime configured-provider CRUD to the API facade and HTTP handler.
- [x] Add non-persistent provider validation with timeout and rate limiting.
- [x] Add `migrateLegacyLLMConfig()` for `{ provider, apiKey, model }` migrations.
- [x] Extend `BentoRouterAdminPage` with an optional Providers section.
- [x] Refactor admin styles to honor documented `--bento-router-*` variables.
- [x] Add fallback auto-population from `defaultModel` on provider add.
- [x] Add `usageSummaryByUser()`.
- [x] Add BYOK, theming, architecture, README, and changelog docs.

## 0.3.0 - Direct Provider Candidates

- [ ] Add direct Gemini provider support.
- [ ] Add direct Groq provider support.
- [ ] Add direct Mistral provider support.
- [ ] Add direct DeepSeek provider support.
